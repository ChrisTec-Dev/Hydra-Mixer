# Hydra Mixer Potato: notes for whoever continues the development

Snapshot of **7 November 2026**. This file is meant to be read first (by the author, or by an AI assistant that is given
this zip in a new conversation and has no memory of the earlier ones). The user-facing description is in README.md, the
list of changes in CHANGELOG.md, the Voicemeeter comparison in docs/potato-comparison.md.

## 1. What this is

Hydra Mixer Potato = **Hydra Mixer** (github.com/TicT4x/Hydra-Mixer, a JUCE / C++20 virtual audio mixer for Windows,
alternative to Voicemeeter Potato; here: the 0.6 release plus Correction and Room Measurement, as in the author's repository at
commit `d95bdf0c7bead1f370675a42691ec23d454d93d9`) **plus** the changes in CHANGELOG.md:

1. the Voicemeeter Potato features that need no audio driver (internal reverb / delay with sends and returns, modulation,
   limiter, pitch shifter, 3D pan, VBAN-TEXT remote control), the Inno Setup installer and the GitHub Actions workflow;
2. copy / paste of a section, scenes that cover some sections / channels, the rename to *Hydra Mixer Potato*;
3. increase / decrease shortcuts for levels and global media / volume keys (the roller of a Logitech G610);
4. the **merge with the author's repository**: Correction and Room Measurement are in the processing chain next to the Potato
   stages, and Correction is a section for copy / paste and scenes (its profile travels as text).

Versions 1 to 3 were built one on top of the other (version 1 + patches `0004` and `0005` = version 3 byte for byte, checked).
Step 4 is a real three-way merge, described in section 6.

## 2. Read this before touching anything

**What could be checked, and what could not.** The assistant that wrote most of this code works in a sandbox with `g++` only:
no JUCE, no MSVC, no network, no Windows. Therefore:

- The pure C++ parts are really tested (section 3): 238 checks, all passing.
- **Everything that needs JUCE has never been compiled** (engine, inspector, settings, scene editor, main window,
  `Hotkeys.cpp` against the *real* JUCE and Windows headers). It was written by copying the patterns already used in the
  code base and, for the risky parts, run against fakes (`tests/standalone/fakes`). At the time of this snapshot no build log of
  this code had been seen. **The first real build is the real test**: expect a few compile errors and fix them from the log.
- When writing JUCE code without a compiler: copy an existing call site that does the same thing instead of recalling an API
  from memory; keep new UI code small; put logic in header-only modules that the standalone tests can run.

**How the author works.** Windows 10/11, writes in French, **no Git**: everything goes through the GitHub web pages. The sources are
uploaded as one zip to the root of the repository, the workflow builds them, the result is downloaded from the run's
*Artifacts*. So a delivery is always: a complete zip, plus a patch with the changes, and a unique file name per delivery (a
re-used name made an old download link serve the newer file once; this zip has a dated name for that reason).

**Upstream.** This tree now contains upstream as of the author's repository (commit above, 7 November 2026), so Correction,
Room Measurement, the AutoEq / Equalizer APO import and the German pages are here. Upstream will go on: the next merge needs the
**source** of the repository again (*Code → Download ZIP*; an exe is not enough), see section 6. The workflow step that unpacks an
uploaded zip refuses to run over a repository that has files the zip lacks, so an older zip can never silently overwrite a
fork that has moved on. Only **one** `Hydra-Mixer-*.zip` may be at the root of the repository: delete the old one before
uploading a new one.

## 3. Build, workflow, tests

- **CI**: `.github/workflows/build-windows.yml` (the author's repository also has upstream's `build.yml`, which builds
  what is committed on every push; the copy here is changed only for the new program name). *Actions → Windows build and installer → Run workflow*. Steps: checkout with the JUCE submodule,
  set up Python, **replace the sources with an uploaded `Hydra-Mixer-*.zip`** if there is one (inline Python; tested in
  isolation, 16 scenarios), MSVC + Ninja, Release build, **Tests** (`HydraTests.exe`, `continue-on-error`, the last 60 lines of
  `test-log.txt` are printed: read them), Inno Setup, installer + portable zip, artifacts `HydraMixerPotato-Windows`.
  The input *Replace even if files are removed* (`force_replace`) lets a zip delete files of the repository on purpose.
  The workflow file is never changed by the zip step: updating it is a manual paste.
- **Local**: `build.ps1` (CMake + Ninja, MSVC; JUCE in `external/JUCE` is a git submodule and is **not** in the zips),
  `installer/build-installer.ps1`. Targets: `HydraMixer` (the app) and `HydraTests` (JUCE console app, runs every suite).
- **Offline tests**: `sh tests/standalone/run.sh` (g++ or clang++, C++20, nothing else). Five suites:

  | Suite | Files | Checks | What it covers |
  |---|---|---|---|
  | FX | `tests/FxTest.cpp` | 26 | reverb, delay, chorus, binaural, pitch shifter DSP |
  | Remote | `tests/RemoteTest.cpp` | 45 | VBAN packet codec, script parser and translation |
  | Sections | `tests/SectionsTest.cpp` | 76 | parameter ids → sections (incl. Correction), section clipboard, state of a section, scope of a scene |
  | Hotkey steps | `tests/HotkeyStepsTest.cpp` | 23 | steps of level shortcuts, media key names |
  | Hotkeys (fakes) | `tests/standalone/hotkeys_fake_test.cpp` | 68 | the **real** `src/midi/Hotkeys.cpp` against `tests/standalone/fakes` (fake `windows.h`, JUCE, `Params.h`): hook swallowing, auto-repeat, capture, XML |

  Each pure suite is `tests/XxxTest.cpp` with `int runXxxTest()`, a wrapper in `tests/standalone/xxx_main.cpp`, a line in
  `run.sh`, a line in the `HydraTests` sources of `CMakeLists.txt`, and a call in the `main` of `tests/DenoiserTest.cpp`.
  `tests/SceneTest.cpp` (scenes, scope, Correction profiles in scenes, "sections cover every channel parameter of the engine"),
  `FxEngineTest.cpp` and upstream's tests (`CorrectionTest.cpp`, `RoomAnalysisTest.cpp`, ...) need JUCE and only run in CI.
- The sandbox shell is `sh` (dash): no bashisms in scripts that are run there.

## 4. Code map (`src/`)

| Path | What |
|---|---|
| `Common.h`, `Main.cpp` | slot constants (16 inputs; outputs A1..A8 and B1..B8; defaults 8 / 5 / 3), `busCode()`, `appDataDir()` (`%APPDATA%\HydraMixer`); application, main window, tray, startup wiring |
| `core/Params.h` | `Param` (lock-free value, version counter, `set(v, external)`: external = MIDI / remote, no undo step), `ParamRegistry` |
| `core/Dsp.h`, `ParamEq.h`, `Denoiser.*`, `Resampler.h`, `RingBuffer.h` | filters and dynamics, 8-band EQ bound to parameters, RNNoise (`external/rnnoise`), variable-ratio resampler, SPSC ring |
| `core/Reverb.h`, `MultiTapDelay.h`, `Chorus.h`, `Binaural.h`, `PitchShifter.h` | the Potato effects (no JUCE) |
| `core/Correction.*`, `core/RoomAnalysis.*`, `core/MicCalibrations.h` | upstream: Correction (profile of filter bands, zero latency, Equalizer APO / AutoEq import and export); analysis of a measured impulse response; microphone calibrations |
| `core/Sections.h` | sections of a channel as groups of parameter ids; `Clip` (copy / paste, with the state of a section), `Scope` (what a scene covers) |
| `core/HotkeySteps.h` | steps of level shortcuts, names of media keys |
| `engine/Engine.*` | `createParams` (every parameter id), the processing chain (`processStrip`, `processFx`), buses, latency |
| `engine/IoStreams.*`, `AsioSecondary.cpp`, `PluginChain.*`, `Recorder.*` | devices and streams, VST3 chains, recorder / player |
| `engine/RoomMeasure.h` | upstream: a measurement run (sweep out through a bus, microphone in) |
| `net/RemoteScript.h`, `RemoteControl.*`, `VbanProtocol.h` | Voicemeeter-style scripts → parameters, UDP VBAN-TEXT listener, VBAN codec |
| `midi/MidiMapper.*`, `Hotkeys.*` | MIDI learn / map; keyboard, mouse and media-key shortcuts (`RegisterHotKey`, low-level mouse and keyboard hooks) |
| `state/Session.*`, `Scenes.*`, `UndoHistory.*`, `Autostart.*`, `VoicemeeterImport.*` | session XML, scenes, undo, "start with Windows" task, import of Voicemeeter settings |
| `state/SectionState.*` | settings of a section that are not parameters (the Correction profile) as text, for copy / paste and scenes |
| `state/RoomMeasurements.*`, `ui/RoomView.*` | upstream: library of `.hydrameasure` files (`%APPDATA%\HydraMixer\Measurements`), microphone calibrations; the Room Measurement window |
| `ui/*` | JUCE components: `Strips` (mixer), `Inspector` (sections of the selected channel, FX panel, XY pad), `Widgets` (knob / fader / toggle with the MIDI and shortcut menu), `SceneEditor`, `Settings`, `MainComponent`, tool windows |

**Conventions.** JUCE style (4 spaces, braces on their own line, space before parentheses). Parameter ids: `in<N>.<name>`
(`in3.gate.thr`), `bus.<code>.<name>` (`bus.A1.lim.on`), global `fx.*`, `mon.*`, `scene.<n>`; every one is registered in
`Engine::createParams`. A new parameter then gets, without more code: the session file, undo, MIDI learn, scenes (all
persistent parameters), remote scripts (`Strip[0].<name>`, `Param[<id>]`), shortcuts. Two things stay manual: its widget in
`ui/`, and its section in `core/Sections.h` (the *"sections cover every channel parameter"* test in `SceneTest.cpp` fails
when a channel parameter belongs to no section and is not one of `active`, `fx.bypass`, `sel`).

## 5. How the Potato changes work

- **Effects**: reverb and delay run in `Engine::processFx`; inputs send (`in<N>.fxs.*`, pre / post fader), buses return
  (`bus.<code>.fxr.*`); settings `fx.rev.*`, `fx.dly.*`. Pitch shifter adds ≈ 18 ms while on (reported to the Latency Finder, used
  by Sync Delay).
- **Remote**: `Settings → Remote`, UDP port 6980, sub-protocol 0x40, local only unless allowed. `RemoteScript.h` parses
  (`Strip[0].Gain = -6;`, `Bus[0].Gain -= 3;`, `Scene[2].Recall = 1;`, `Param[in1.pitch.semi] = 3;`, `Command.Restart = 1;`) and
  translates to parameter changes; changes count as external (no undo step).
- **Sections / scenes**: `Sections::parse` splits an id into (kind, channel, name, section). `SceneBank::Scene` has a
  `Scope` (empty = everything); `snapshot`, `recall`, `countDifferences`, `fromXml` only look at covered parameters;
  `setScope` drops what is no longer covered and takes the current mixer value for what newly is.
- **Correction in sections and scenes**: the switch is the parameter `in<N>.corr.on` / `bus.<code>.corr.on` (section `corr`, so it
  is handled like every parameter); the profile (`CorrectionProfile`, bands and preamp) lives in the channel's `Correction` object
  and in the session as a `<CORRECTION>` child, outside the parameter registry. `sectionstate::capture / apply / same` read and
  write it as XML text for a channel (`selectIndex`: inputs, then buses). Copy / paste carries it in `Clip::states`; a scene
  carries it in `Scene::states` only when its scope **names** `corr` (a scene that covers everything leaves profiles alone,
  which is upstream's behaviour). An empty profile in the source clears the target. Room Measurement has no per-channel state.
- **Section copy / paste**: right-click on the title bar of a `Section` (`ui/Inspector.cpp`, `showSectionMenu`); the clipboard
  holds *names*, so it pastes into any channel of the same kind. One paste = one undo step (changes within 0.4 s are grouped).
- **Shortcuts**: `Hotkeys::Binding` has an `Action` (toggle / increase / decrease) and a step. Media keys are not delivered to
  JUCE components as distinct keys, hence a **low-level keyboard hook**, installed only while a media key is bound or a shortcut
  is being captured; it swallows the bound ones and posts the work to the message thread. Plain keys act only while the app
  has focus; Ctrl / Alt / F-keys use `RegisterHotKey` (with auto-repeat for increase / decrease).

## 6. Merging with upstream: how it was done, and how to do it next time

The merge of 7 November 2026 (done offline, by script):

1. **Base** = Hydra Mixer 0.6 as the Potato patches started from it. It was rebuilt by reverse-applying the patches `0002` and
   `0001` to version 1.
2. **Compare** the base with the author's repository: upstream had changed only `Inspector.cpp`, `Engine.cpp`, `Engine.h`,
   `README.md`, `MainComponent.{cpp,h}`, `Session.cpp`, `Widgets.h`, `CMakeLists.txt`, `DenoiserTest.cpp`, `.gitignore`, and added
   the Correction / Room Measurement files (new files are simply copied).
3. **Three-way merge** (`git merge-file --diff3`: ours = this tree, base, theirs = upstream) of those files: 16 conflicts, all
   compatible (both sides added next to each other, or changed the same list in a way that combines: members and includes of
   `Engine.h`, the sections of the inspector racks, the tests in `CMakeLists.txt` and `main`, the README paragraphs). `Engine.cpp`, `MainComponent.cpp`, `Session.cpp`, `Widgets.h`
   merged without a conflict and were read afterwards: the stages are in the right order (Correction right after Gain on an input,
   after the plugins on a bus), the FX returns are added before the bus is processed, a measurement run replaces the bus signal.
4. **By hand afterwards**: the rename of the new window; `installer/Output/` back in `.gitignore` (the base had it from the
   installer patch, upstream never did, so the merge dropped it); Correction as a section (`Sections.h`, `SectionState`, scenes,
   inspector menu); docs and workflows.

**Next time.** Give the new repository zip. The base is then **this tree minus the Potato changes**: reverse-apply
`docs/maintenance/potato-vs-upstream-d95bdf0.patch` (the diff between the author's repository at the commit above and this
tree) to this tree, compare with the new zip, three-way merge what both sides changed, copy what is new upstream. After
the merge, regenerate that patch against the new upstream snapshot so the next merge can do the same. Check: stage order in
`Engine::processStrip` / `processBus`, new parameters need a section in `core/Sections.h`, new windows need the rename,
`.gitignore` and the README, `build.yml`.

## 7. Backlog (from the author's list, with the design notes worked out so far)

1. **Macro Buttons.** A `MacroBank` like `SceneBank`: up to 32 buttons (name, colour, mode push / switch / trigger, an *on*
   and an *off* script, optional "lit while *param* ≥ *x*"). Triggered through non-persistent toggle parameters `macro.1..32`
   registered in `Engine` (as `scene.N` are), so shortcuts (incl. media keys), MIDI learn and remote scripts reach them for
   free. Scripts run through `RemoteScript.h` and the same applier as `RemoteControl`. Window in the Tools menu (grid; right-click
   to edit). Saved as `<MACROS>` in the session. Put the state machine in a header-only module with a standalone test.
2. **Color panel.** An X/Y pad in the EQ section writing to existing EQ bands (tilt dark ↔ bright, presence), so no new DSP;
   the mapping (x, y) → gains is pure and testable. Voicemeeter's panel is a quick pad over a small EQ.
3. **Internal clock.** Run the engine without a hardware master device: a `juce::AudioIODeviceType` "Internal clock" with one
   `AudioIODevice` driven by a high-resolution timer thread (waitable timer with high resolution), silent inputs, discarded
   outputs, chosen rate and block size; secondary devices keep being resampled to the master (the resampler already follows
   drift).
4. **External FX loop.** Send of chosen strips / buses to a device output pair, return from an input pair into a bus, with
   the round-trip latency from the Latency Finder compensated; build on `IoStreams` / `AsioSecondary`. Read those first.
5. **Remote API DLL.** A small DLL exporting the `VBVMR_*` functions of Voicemeeter's Remote API (login / logout, parameter
   get / set, `SetParameters` with scripts, dirty flag, levels) so existing tools work. Transport: shared memory with a
   parameter snapshot and level table refreshed by the app, plus a queue for scripts (or the existing VBAN-TEXT socket for
   writes). Third-party tools locate the DLL through a Voicemeeter registry key: whether the installer should write a
   compatible key is a decision for the author. Needs a new CMake target; the name mapping already exists in `RemoteScript.h`.
6. **Translations.** JUCE `TRANS("...")` + `juce::LocalisedStrings` (JUCE's own menus and dialogs then follow), language
   files in `resources/`, a language choice in Settings (applied at start). Wrap the UI literals mechanically
   (`setText`, `setButtonText`, `setTooltip`, `drawText`, `addItem`, window titles). The upstream merge is done, so the Room
   Measurement and Correction windows are included; do it right after the first successful build and before new UI work, or
   every new window adds literals to wrap. French first. A small script that lists the literals still untranslated keeps it honest.
7. **VBAN audio streams** (the codec is ready: `VbanProtocol.h`), **VBAN-MIDI / SERIAL / FRAME** (not planned).
8. Decisions still open: the version number (still `0.6.0` in `CMakeLists.txt`), whether Hydra Mixer Potato should get its own
   installer id so it can be installed next to the original (today it upgrades it in place).

## 8. Verification log of this snapshot

- `sh tests/standalone/run.sh`: FX 26, Remote 45, Sections 76, Hotkey steps 23, Hotkeys (fakes) 68 = 238 checks, no failure, no
  warning with `-Wall -Wextra`.
- The logic of the inspector's section menu, with the Correction profile (copy, paste, paste to all, copy all, reset, buses use
  indexes 16 and up), was run against fake JUCE classes: 14 checks, the harness is not kept in the repository.
- The merge: no conflict marker left anywhere; every `.cpp` of `src/` is either in the app's source glob or in the `HydraTests`
  list (`SectionState.cpp` was added there, the tests call `SceneBank`).
- Workflow zip step: 16 scenarios on throw-away repositories, and run on the author's real repository with this zip.
- Not run: any JUCE build, `HydraTests`, any Windows behaviour (hooks, installer, scheduled task), the new `SceneTest` blocks.

## 9. To resume in a new conversation

1. Unzip, run `sh tests/standalone/run.sh`: expect the five suites to pass (238 checks) with no warning.
2. If the author has a build log of the CI (the failing step, or the *Tests* output), fix that first: compile errors in the
   JUCE-dependent code are the most likely thing to find (section 2).
3. Then one backlog item at a time (section 7), or a new upstream merge (section 6) if a new repository zip is provided.
4. Deliver a complete zip with a **new** file name, plus a patch against the previous snapshot, and update CHANGELOG.md,
   README.md and docs/potato-comparison.md. Pure logic goes into header-only modules with a test in `tests/standalone`;
   say plainly what was verified and what was not.
