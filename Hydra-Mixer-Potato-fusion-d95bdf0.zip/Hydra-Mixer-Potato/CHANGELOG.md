# Hydra Mixer Potato: changes on top of upstream Hydra Mixer

Hydra Mixer Potato is Hydra Mixer (github.com/TicT4x/Hydra-Mixer: the 0.6 release of 18 October 2026 plus what upstream added
since, Correction and Room Measurement) with the changes below. Snapshot of 7 November 2026, newest first. Anything not
listed is the upstream behaviour.

## Merged with the author's repository (commit d95bdf0c7bead1f370675a42691ec23d454d93d9)

The sources of the repository, which follow upstream, were merged into the Potato version. What upstream had added since 0.6:
**Correction** (per input and per bus: a profile of up to 32 zero-latency filter bands, measured or imported from Equalizer APO /
AutoEq), **Room Measurement** (Tools → Room Measurement), a library of measurements and microphone calibrations, German
documentation, upstream's CI (`build.yml`). What the merge changes:

- Order of an input: Gain → **Correction** → Denoiser → Pitch shifter → EQ → Gate → Compressor → VST3 chain → Modulation →
  Limiter → Sync Delay → Mono → 3D pan / Fader / Pan. A bus: EQ → VST3 chain → **Correction** → Mono → Fader → Limiter, and it
  also receives its FX return.
- **Correction is a section** like the others: *copy / paste of a section* carries its profile with its switch, *Reset*
  clears it, and a scene that **names Correction** in *Covers...* stores and recalls the profiles of the channels it covers
  (a scene that covers everything keeps profiles as they are, as before: it only switches Correction on and off).
  The settings that are not parameters travel as text (`src/state/SectionState.*`); `core/Sections.h` says which sections have some.
- Room Measurement has no settings of its own per channel (what it designs is a Correction profile), so it needs nothing
  more in sections or scenes. Its window is titled "Hydra Mixer Potato - Room Measurement"; the files upstream writes
  (`.hydrameasure`, exported correction files) keep "Hydra Mixer" in their identifiers so they stay interchangeable.
- `.github/workflows/build.yml` (upstream's CI) names the program `Hydra Mixer Potato.exe`; `build-windows.yml` is the uploaded-zip workflow.

## Shortcuts for levels and media keys

- **Increase / decrease shortcuts for levels**: right-click a fader or knob → *Assign Shortcut: Increase / Decrease*. One key
  press moves the level by a step (0.5 / 1 / 2 / 3 / 6 dB, or 1 / 2 / 5 / 10 % of a knob; *Step per key press* in the same
  menu), kept in the session. Holding the key keeps stepping.
- **Media and volume keys as global shortcuts** (the volume roller of a Logitech G610: Volume Up / Down, Mute; also play /
  pause, next / previous, browser and launch keys). A low-level keyboard hook watches them, only while one is bound or a
  new shortcut is being captured; bound keys are swallowed so Windows does not also change its own volume.
- Saved as `media=` / `mods=` / `action=` / `amount=` on a shortcut; files from before still load.

## Copy / paste of sections, scenes by section

- **Copy / paste of a section**: right-click the title of a section in the inspector → copy, paste, paste to all inputs /
  outputs, copy / paste all sections of a channel, reset to defaults. One Ctrl+Z takes a paste back.
  `src/core/Sections.h` defines the sections (groups of parameter ids).
- **Scenes that cover only some sections and / or channels**: Scene Editor → right-click a scene → *Covers...*. Recall,
  save and the "edited" check only touch what the scene covers. Stored as `sections=` / `channels=` on the scene; scenes
  of older sessions cover everything.

## Rename

**Hydra Mixer Potato**: window titles, tray, installer, `Hydra Mixer Potato.exe`, `HydraMixerPotato-<version>-...` files.
What stays as it was, so that settings and installs carry over: the data folder `%APPDATA%\HydraMixer`, the installer id,
the name of the "Start with Windows" task, the project and target names (`HydraMixer`). The installer removes the old
`Hydra Mixer.exe` on an upgrade; the app points the "Start with Windows" entry at the new file the first time it starts.

## Voicemeeter Potato features (see docs/potato-comparison.md)

- Internal **reverb** and **multi-tap delay** with per-input FX sends (pre / post fader) and per-bus FX returns
  (Tools → Internal FX).
- Input strip: **Modulation** (chorus), **Limiter** (-40 to +12 dB), **Pitch shifter** (±12 semitones; about 18 ms of latency
  while on, shown in the Latency Finder and used by the automatic Sync Delay), **3D pan** (binaural, X/Y pad).
- **Remote control** by VBAN-TEXT scripts in the Voicemeeter syntax (Settings → Remote; off by default, this PC only), e.g.
  `Strip[0].Gain = -6; Bus[0].Mute = 1; Scene[2].Recall = 1;`. Works with VBAN-Buttons and the Stream Deck plugins for
  VBAN-TEXT; every Hydra parameter can be reached. The VBAN packet codec (`src/net/VbanProtocol.h`) is ready for the VBAN
  audio streams, which are still to come.
- The new parameters are saved with the session, recalled by scenes, undoable and learnable in MIDI like all the others.

## Installer and build

- Windows installer (Inno Setup: `installer/HydraMixer.iss`, `installer/build-installer.ps1`) and the GitHub Actions workflow
  `.github/workflows/build-windows.yml`: builds Release, runs HydraTests, makes `HydraMixerPotato-<version>-Setup.exe` and
  `HydraMixerPotato-<version>-win64.zip`, keeps them as artifacts (and attaches them to a release for tags `v*`).
- **Uploaded-zip step** (for working in the browser, without Git): a `Hydra-Mixer-*.zip` in the root of the repository
  replaces the sources before the build. The tree is *replaced*, not laid over the repository: `.git`, `.github` and the JUCE
  folder are never touched, and the step stops without changing anything when the zip would remove files of the repository
  (the zip is then older than the repository, e.g. a fork with newer files). *Run workflow* has a box *Replace even if
  files are removed* for the case where the removal is meant. The workflow file itself must be pasted into
  `.github/workflows/` by hand: the step never changes `.github`.

## Where the code is

- DSP, no JUCE needed: `src/core/Reverb.h`, `MultiTapDelay.h`, `Chorus.h`, `Binaural.h`, `PitchShifter.h`, `Sections.h`,
  `HotkeySteps.h`.
- `src/engine/Engine.h/.cpp`: parameters, processing (`processStrip`, `processFx`), latency of the pitch shifter.
- `src/ui/Inspector.cpp`: the new sections, the FX settings panel, the XY pad, the section copy / paste menu.
  `src/ui/Settings.cpp`: the Remote tab. `src/ui/SceneEditor.cpp`: the scope of a scene. `src/ui/Widgets.cpp`: the shortcut
  menu of a fader or knob.
- `src/net/RemoteScript.h` (parser and translation to Hydra parameters), `RemoteControl.h/.cpp` (UDP listener).
- `src/state/Scenes.h/.cpp`: scenes and their scope. `src/state/SectionState.h/.cpp`: settings of a section that are not
  parameters (the Correction profile). `src/midi/Hotkeys.h/.cpp`: shortcuts, media keys, hooks.

## Status of the verification

Checked offline with a standard C++ compiler (`tests/standalone/run.sh`, 238 checks): the DSP of the effects (26), the VBAN
codec and the script parser (45), the sections, the state of a section and the scope of a scene (76), the steps of the level
shortcuts (23), and the real `src/midi/Hotkeys.cpp` against small fakes of JUCE and Win32 (68: media key hook, steps,
capture, session file). The logic of the section menu (with the Correction profile) was also run against fakes (14 checks).

**Not compiled yet**: everything that needs JUCE (engine, inspector, settings, scene editor, main). It was written without
access to JUCE or a Windows compiler. Build it and run HydraTests (the *Tests* step of the workflow) first; compile errors
go back to the author of the change.
