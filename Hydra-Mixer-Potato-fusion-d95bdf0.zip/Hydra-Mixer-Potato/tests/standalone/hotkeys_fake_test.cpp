// Behaviour of the REAL midi/Hotkeys.cpp (increase / decrease shortcuts, media keys, hooks, XML) against the fake JUCE / Win32
// in tests/standalone/fakes. Run by tests/standalone/run.sh. What the fakes cannot show is whether Windows behaves the same.
#include <windows.h>
#include "midi/Hotkeys.h"
#include <cstdio>

using namespace hydra;
using Action = Hotkeys::Action;

static int fails = 0;
static void check (bool c, const char* what) { std::printf ("%s %s\n", c ? "ok:  " : "FAIL:", what); if (! c) ++fails; }

static juce::KeyPress media (unsigned vk, int mods = 0) { return juce::KeyPress (juce::KeyPress::extendedKeyModifier | (int) vk, juce::ModifierKeys (mods), 0); }
static juce::KeyPress key (int code, int mods = 0)      { return juce::KeyPress (code, juce::ModifierKeys (mods), 0); }
constexpr LRESULT notInstalled = -999;

static void resetFake()
{
    fakewin::posted.clear(); fakewin::registered.clear(); fakewin::refusedKeys.clear(); fakewin::down.clear();
    fakewin::keyboardHook = nullptr; fakewin::mouseHook = nullptr; fakewin::registerCalls = 0;
}

/** What Windows does when a media key goes down / up: asks the keyboard hook. */
static LRESULT pressMedia (unsigned vk, bool down = true)
{
    if (fakewin::keyboardHook == nullptr) return notInstalled;
    KBDLLHOOKSTRUCT k {};
    k.vkCode = vk;
    return fakewin::keyboardHook (HC_ACTION, down ? WM_KEYDOWN : WM_KEYUP, (LPARAM) &k);
}

static LRESULT pressMouse (int xbutton)   // 1 = thumb button 4, 2 = thumb button 5
{
    if (fakewin::mouseHook == nullptr) return notInstalled;
    MSLLHOOKSTRUCT m {};
    m.mouseData = (DWORD) xbutton << 16;
    return fakewin::mouseHook (HC_ACTION, WM_XBUTTONDOWN, (LPARAM) &m);
}

static int idForVk (UINT vk) { for (auto& [id, v] : fakewin::registered) if (v.second == vk) return id; return -1; }

int main()
{
    // ------------------------------------------------------------------ volume roller
    {
        resetFake();
        ParamRegistry reg;
        auto& gain = reg.addLevel ("bus.A1.gain", -60.0f, 12.0f, 0.0f, " dB");
        auto& mute = reg.addSwitch ("bus.A1.mute");
        Hotkeys hk (reg);
        std::printf ("\n--- Volume roller (media keys) ---\n");
        check (fakewin::windowProc != nullptr && fakewin::keyboardHook == nullptr, "no keyboard hook while no media key is bound");

        hk.assign (gain, media (0xAF), Action::increase);
        check (fakewin::keyboardHook != nullptr, "binding Volume Up installs the keyboard hook");
        hk.assign (gain, media (0xAE), Action::decrease);
        hk.assign (mute, media (0xAD));
        check (hk.getKeyFor (&gain, Action::increase) == media (0xAF) && hk.getKeyFor (&gain, Action::decrease) == media (0xAE) && hk.getKeyFor (&mute) == media (0xAD),
              "each direction and the toggle have their key");
        check (! hk.getKeyFor (&gain).isValid() && ! hk.getKeyFor (&mute, Action::increase).isValid(), "no toggle key on a level, no step key on a switch");
        bool allGlobal = true;
        for (auto& b : hk.getBindings()) allGlobal = allGlobal && b.global;
        check (allGlobal && fakewin::registerCalls == 0, "media keys are global but not registered with RegisterHotKey (the hook watches them)");

        gain.set (-10.0f);
        check (pressMedia (0xAF) == 1, "Volume Up is swallowed (Windows must not change its own volume)");
        check (fakewin::posted.size() == 1, "and handed to the message thread");
        check (gain.get() == -10.0f, "the level moves on the message thread, not inside the hook");
        fakewin::pump();
        check (gain.get() == -9.0f, "Volume Up: +1 dB");
        check (pressMedia (0xAF, false) == 1 && fakewin::posted.empty(), "the key up is swallowed too and does nothing");
        pressMedia (0xAE); fakewin::pump();
        check (gain.get() == -10.0f, "Volume Down: -1 dB");
        for (int i = 0; i < 5; ++i) { pressMedia (0xAF); fakewin::pump(); }
        check (gain.get() == -5.0f, "five presses (auto-repeat) = +5 dB");
        pressMedia (0xAD); fakewin::pump();
        check (mute.isOn(), "Volume Mute toggles the mute");
        pressMedia (0xAD); fakewin::pump();
        check (! mute.isOn(), "and back");
        check (pressMedia (0xB3) == 0 && fakewin::posted.empty(), "Play / Pause is not bound: passed on to Windows");
        check (pressMedia (0x41) == 0 && fakewin::posted.empty(), "an ordinary key is never touched");

        fakewin::down.insert (VK_CONTROL);
        check (pressMedia (0xAF) == 0 && fakewin::posted.empty(), "Ctrl + Volume Up is not the bound key: passed on");
        fakewin::down.clear();

        std::printf ("\n--- Step size ---\n");
        check (hk.stepOf (gain) == 1.0f, "default step of a level in dB: 1 dB");
        hk.setStep (gain, 3.0f);
        pressMedia (0xAF); fakewin::pump();
        check (gain.get() == -2.0f && hk.stepOf (gain) == 3.0f, "after choosing 3 dB one press is 3 dB");
        pressMedia (0xAE); fakewin::pump();
        check (gain.get() == -5.0f, "same step downwards");
        gain.set (11.0f);
        pressMedia (0xAF); fakewin::pump();
        check (gain.get() == 12.0f, "stops at the top of the fader");
        gain.set (-59.0f);
        pressMedia (0xAE); fakewin::pump();
        check (gain.get() == -60.0f, "and at the bottom");
        hk.assign (gain, media (0xAF, juce::ModifierKeys::shiftModifier), Action::increase, 0.5f);
        bool bothHalf = true; int steps = 0;
        for (auto& b : hk.getBindings()) if (b.param == &gain) { bothHalf = bothHalf && b.amount == 0.5f; ++steps; }
        check (bothHalf && steps == 2, "choosing a step while assigning applies to both directions (and replaces the old increase key)");
        check (! hk.getKeyFor (&gain, Action::increase).isValid() || hk.getKeyFor (&gain, Action::increase) == media (0xAF, juce::ModifierKeys::shiftModifier),
               "one increase key per level");

        std::printf ("\n--- While a shortcut is being captured ---\n");
        std::vector<juce::KeyPress> captured;
        gain.set (-20.0f);
        hk.setSuspended (true);
        check (pressMedia (0xAE) == 0, "suspended without capture: bound media keys go to Windows");
        hk.setMouseCapture ([&] (const juce::KeyPress& k) { captured.push_back (k); });
        check (pressMedia (0xB3) == 1 && pressMedia (0xAE) == 1, "capturing: every media key is swallowed, bound or not");
        fakewin::pump();
        check (captured.size() == 2 && captured[0] == media (0xB3) && captured[1] == media (0xAE), "and reaches the capture as a key press");
        check (gain.get() == -20.0f, "without triggering the shortcut");
        hk.setMouseCapture (nullptr);
        hk.setSuspended (false);
        check (pressMedia (0xAE) == 1 && (fakewin::pump(), gain.get() == -20.5f), "after the capture the shortcuts work again (0.5 dB steps now)");

        std::printf ("\n--- Removing ---\n");
        hk.remove (&gain);
        check (fakewin::keyboardHook != nullptr && pressMedia (0xAE) == 0, "the hook stays while Volume Mute is bound, Volume Down is free again");
        hk.remove (&mute);
        check (fakewin::keyboardHook == nullptr, "no media key left: the hook is removed");
    }
    check (fakewin::keyboardHook == nullptr && fakewin::mouseHook == nullptr, "destroying Hotkeys removes every hook");

    // ------------------------------------------------------------------ keys, mouse, global registration
    {
        resetFake();
        ParamRegistry reg;
        auto& gain = reg.addLevel ("bus.A1.gain", -60.0f, 12.0f, 0.0f, " dB");
        auto& knob = reg.addLevel ("in1.dn.amount", 0.0f, 10.0f, 5.0f);
        auto& freq = reg.addLevel ("in1.eq.b1.freq", 20.0f, 20000.0f, 1000.0f, " Hz", 0.3f);
        auto& mute = reg.addSwitch ("bus.A1.mute");
        auto& mode = reg.addChoice ("in1.dn.mode", 4);
        Hotkeys hk (reg);
        std::printf ("\n--- Keys, mouse, global registration ---\n");

        hk.assign (mute, key ('M', juce::ModifierKeys::ctrlModifier));
        const int idM = idForVk ('M');
        check (idM >= 0 && (fakewin::registered[idM].first & MOD_CONTROL) != 0 && (fakewin::registered[idM].first & MOD_NOREPEAT) != 0, "a switch on Ctrl+M: registered, without auto-repeat");
        fakewin::windowProc (fakewin::theWindow, WM_HOTKEY, (WPARAM) idM, 0);
        check (mute.isOn(), "WM_HOTKEY toggles it");

        hk.assign (gain, key (juce::KeyPress::F1Key + 4), Action::increase);
        hk.assign (gain, key (juce::KeyPress::F1Key + 5), Action::decrease);
        const int idF5 = idForVk (0x74), idF6 = idForVk (0x75);
        check (idF5 >= 0 && idF6 >= 0 && (fakewin::registered[idF5].first & MOD_NOREPEAT) == 0 && (fakewin::registered[idF6].first & MOD_NOREPEAT) == 0,
              "increase / decrease on F5 / F6: registered WITH auto-repeat (holding the key keeps stepping)");
        gain.set (0.0f);
        fakewin::windowProc (fakewin::theWindow, WM_HOTKEY, (WPARAM) idF5, 0);
        fakewin::windowProc (fakewin::theWindow, WM_HOTKEY, (WPARAM) idF5, 0);
        fakewin::windowProc (fakewin::theWindow, WM_HOTKEY, (WPARAM) idF6, 0);
        check (gain.get() == 1.0f, "F5, F5, F6 = +1 dB");

        fakewin::refusedKeys.insert (0x76);   // another program owns F7
        hk.assign (knob, key (juce::KeyPress::F1Key + 6), Action::increase);
        bool f7global = true;
        for (auto& b : hk.getBindings()) if (b.param == &knob) f7global = b.global;
        check (! f7global, "a key another program owns is not global");
        check (hk.handleLocalKey (key (juce::KeyPress::F1Key + 6)) && std::abs (knob.getNormalised() - 0.52f) < 1.0e-4f, "but it works while Hydra has focus: knob +2 % of its range");

        hk.assign (knob, key ('x'), Action::decrease);
        check (! hk.getBindings().back().global, "a plain key is local");
        check (hk.handleLocalKey (key ('x')) && std::abs (knob.getNormalised() - 0.50f) < 1.0e-4f, "plain key x: -2 %");
        check (! hk.handleLocalKey (key ('y')), "an unbound key does nothing");

        hk.assign (freq, key ('q'), Action::increase, 0.05f);
        const float before = freq.getNormalised();
        hk.handleLocalKey (key ('q'));
        check (std::abs (freq.getNormalised() - (before + 0.05f)) < 1.0e-4f, "a log-skewed knob moves by 5 % of the knob, not of the Hz");

        hk.assign (mode, key ('c'));
        hk.handleLocalKey (key ('c'));
        check (mode.get() == 1.0f, "a choice parameter still cycles");

        check (! Hotkeys::canAssignStep (mute) && ! Hotkeys::canAssignStep (mode) && Hotkeys::canAssignStep (gain) && Hotkeys::canAssignStep (freq), "levels only can have increase / decrease keys");
        Hotkeys::step (mute, +1, 1.0f);
        check (! mute.isOn() || mute.isOn(), "step() on a switch is ignored");   // the state itself is checked next
        const bool muteBefore = mute.isOn();
        Hotkeys::step (mute, +1, 1.0f);
        check (mute.isOn() == muteBefore, "step() on a switch changes nothing");

        hk.assign (gain, key (Hotkeys::kMouseCodeBase + 4), Action::decrease);
        check (fakewin::mouseHook != nullptr, "a mouse button binding installs the mouse hook");
        gain.set (0.0f);
        check (pressMouse (1) == 0, "the click is passed on to the other app");
        fakewin::pump();
        check (gain.get() == -1.0f, "thumb button 4: -1 dB");

        std::printf ("\n--- One key, one job ---\n");
        hk.assign (knob, key ('z'), Action::increase);
        hk.assign (gain, key ('z'), Action::increase);
        check (! hk.getKeyFor (&knob, Action::increase).isValid() && hk.getKeyFor (&gain, Action::increase) == key ('z'), "a key used again moves to the new parameter");
        hk.assign (gain, key ('w'), Action::increase);
        check (hk.getKeyFor (&gain, Action::increase) == key ('w') && ! hk.handleLocalKey (key ('z')), "a new key for the same job replaces the old one");
        const auto v0 = hk.version.load();
        hk.assign (gain, key ('v'), Action::decrease);
        check (hk.version.load() > v0, "every change bumps the version (UI refresh, autosave)");

        std::printf ("\n--- Channels reordered ---\n");
        auto& gain2 = reg.addLevel ("bus.A2.gain", -60.0f, 12.0f, 0.0f, " dB");
        const std::vector<std::pair<Param*, Param*>> moves { { &gain, &gain2 } };
        const int n = hk.countBindings (moves);
        hk.remapParams (moves);
        check (n == 2 && hk.getKeyFor (&gain2, Action::increase) == key ('w') && hk.getKeyFor (&gain2, Action::decrease).isValid() && ! hk.getKeyFor (&gain, Action::increase).isValid(),
              "shortcuts follow their level when channels move (every direction)");

        std::printf ("\n--- Names ---\n");
        check (Hotkeys::describe (media (0xAF)) == "Volume Up" && Hotkeys::describe (media (0xAE)) == "Volume Down" && Hotkeys::describe (media (0xAD)) == "Volume Mute", "the roller keys are named");
        check (Hotkeys::describe (media (0xAE, juce::ModifierKeys::ctrlModifier | juce::ModifierKeys::shiftModifier)) == "Ctrl + Shift + Volume Down", "with modifiers");
        check (Hotkeys::describe (key (Hotkeys::kMouseCodeBase + 4)) == "Mouse 4", "mouse buttons still described");
        check (Hotkeys::wantsGlobal (media (0xAF)) && ! Hotkeys::wantsGlobal (key ('x')) && Hotkeys::wantsGlobal (key ('x', juce::ModifierKeys::ctrlModifier)), "media keys are global, plain keys are not");
        check (Hotkeys::isMediaKey (media (0xAF)) && ! Hotkeys::isMediaKey (key ('A')) && ! Hotkeys::isMediaKey (key (juce::KeyPress::F1Key))
               && ! Hotkeys::isMediaKey (key (Hotkeys::kMouseCodeBase + 3)) && ! Hotkeys::isMediaKey (media (0x70)), "isMediaKey: not letters, F-keys, mouse");
        check (Hotkeys::stepText (gain, 1.0f) == "1.0 dB" && Hotkeys::stepText (knob, 0.02f) == "2 %" && Hotkeys::stepChoices (gain).size() == 5 && Hotkeys::stepChoices (knob).size() == 4,
               "step texts and menu choices");
    }

    // ------------------------------------------------------------------ XML
    {
        resetFake();
        ParamRegistry reg;
        auto& gain = reg.addLevel ("bus.A1.gain", -60.0f, 12.0f, 0.0f, " dB");
        auto& mute = reg.addSwitch ("bus.A1.mute");
        auto& knob = reg.addLevel ("in1.dn.amount", 0.0f, 10.0f, 5.0f);
        std::printf ("\n--- Saved with the session ---\n");
        std::unique_ptr<juce::XmlElement> xml;
        std::vector<Hotkeys::Binding> saved;
        {
            Hotkeys hk (reg);
            hk.assign (gain, media (0xAF), Action::increase, 3.0f);
            hk.assign (gain, media (0xAE, juce::ModifierKeys::shiftModifier), Action::decrease);
            hk.assign (mute, media (0xAD));
            hk.assign (knob, key ('k', juce::ModifierKeys::altModifier), Action::increase);
            hk.assign (knob, key (Hotkeys::kMouseCodeBase + 5), Action::decrease);
            xml = hk.toXml();
            saved = hk.getBindings();
        }
        auto keys = xml->getChildWithTagNameIterator ("KEY");
        check (keys.size() == 5, "five shortcuts saved");
        check (keys[0]->hasAttribute ("media") && ! keys[0]->hasAttribute ("key") && keys[0]->getStringAttribute ("action") == "up" && keys[0]->getDoubleAttribute ("amount") == 3.0,
              "a media key is saved by its code, with action and step");
        check (keys[1]->getIntAttribute ("mods") == juce::ModifierKeys::shiftModifier && keys[1]->getStringAttribute ("action") == "down", "modifiers of a media key");
        check (! keys[2]->hasAttribute ("action") && ! keys[2]->hasAttribute ("amount"), "a toggle has neither action nor step (same file as before)");
        {
            Hotkeys hk2 (reg);
            hk2.fromXml (*xml);
            const auto loaded = hk2.getBindings();
            bool same = loaded.size() == saved.size();
            for (size_t i = 0; same && i < loaded.size(); ++i)
                same = loaded[i].param == saved[i].param && loaded[i].key == saved[i].key && loaded[i].action == saved[i].action && loaded[i].amount == saved[i].amount;
            check (same, "loading gives back the same shortcuts (keys, actions, steps)");
            check (fakewin::keyboardHook != nullptr && fakewin::mouseHook != nullptr, "and the hooks they need");
            check (hk2.stepOf (gain) == 3.0f, "the step of a level survives");
        }

        juce::XmlElement old ("HOTKEYS");
        auto* e1 = old.createNewChildElement ("KEY");
        e1->setAttribute ("param", "bus.A1.mute"); e1->setAttribute ("key", key ('m', juce::ModifierKeys::ctrlModifier).getTextDescription());
        auto* e2 = old.createNewChildElement ("KEY");
        e2->setAttribute ("param", "bus.A1.mute"); e2->setAttribute ("key", key ('n').getTextDescription()); e2->setAttribute ("action", "up");   // a switch cannot step
        auto* e3 = old.createNewChildElement ("KEY");
        e3->setAttribute ("param", "no.such.param"); e3->setAttribute ("key", key ('p').getTextDescription());
        auto* e4 = old.createNewChildElement ("KEY");
        e4->setAttribute ("param", "bus.A1.gain");   // no key at all
        Hotkeys hk3 (reg);
        hk3.fromXml (old);
        const auto b = hk3.getBindings();
        check (b.size() == 1 && b[0].param == &mute && b[0].action == Action::toggle && b[0].amount == 0.0f, "a file from before this feature loads as toggles; impossible entries are dropped");
    }
    check (fakewin::keyboardHook == nullptr && fakewin::mouseHook == nullptr, "no hook is left behind");

    std::printf (fails == 0 ? "\nHotkeys tests passed\n" : "\nHotkeys tests FAILED (%d)\n", fails);
    return fails == 0 ? 0 : 1;
}
