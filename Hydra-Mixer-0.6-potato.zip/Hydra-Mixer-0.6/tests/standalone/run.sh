#!/bin/sh
# Runs the tests that need nothing but the standard library (DSP of the internal effects, VBAN codec, remote script
# parser) with g++ or clang++, without JUCE or Windows. The full suite is HydraTests (see CMakeLists.txt).
# Common.h here stands in for src/Common.h and only provides the few juce:: helpers the DSP headers touch.
set -e
cd "$(dirname "$0")/../.."
CXX=${CXX:-g++}
$CXX -std=c++20 -O2 -Wall -Wextra -I tests/standalone -I src tests/standalone/fx_main.cpp tests/FxTest.cpp -o /tmp/hydra_fx_test
$CXX -std=c++20 -O2 -Wall -Wextra -I tests/standalone -I src tests/standalone/remote_main.cpp tests/RemoteTest.cpp -o /tmp/hydra_remote_test
$CXX -std=c++20 -O2 -Wall -Wextra -I tests/standalone -I src tests/standalone/sections_main.cpp tests/SectionsTest.cpp -o /tmp/hydra_sections_test
/tmp/hydra_fx_test
/tmp/hydra_remote_test
/tmp/hydra_sections_test
