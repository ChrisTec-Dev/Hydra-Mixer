// Sections of a channel strip (Equalizer, Gate, Compressor, ...) as groups of parameter ids.
// Used by "copy / paste a section" between channels and by scenes that only cover some sections or channels.
// Only the standard library is used: tests/SectionsTest.cpp also runs without JUCE.
#pragma once
#include <algorithm>
#include <map>
#include <set>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace hydra::sections
{
enum class Kind { input, bus, global };

/** A section. A parameter belongs to it when its name (the id without the channel part, "gate.thr") is one of
    `names` or starts with "<name>.". Inputs and buses have their own list, the id is the same where the section
    exists on both (so a scene can say "the equalizer" for every kind of channel). */
struct Def
{
    const char* id;      // stable key, stored in scene files
    const char* title;   // shown in menus
    Kind kind;
    std::vector<const char*> names;
};

inline const std::vector<Def>& defs()
{
    static const std::vector<Def> d = {
        // Inputs ("in3.gate.thr")
        { "mix",     "Fader, pan, mute",    Kind::input,  { "gain", "trim", "pan", "mute", "solo", "mono", "phase" } },
        { "routing", "Routing and sends",   Kind::input,  { "route", "send" } },
        { "eq",      "Equalizer",           Kind::input,  { "eq" } },
        { "gate",    "Gate",                Kind::input,  { "gate" } },
        { "dn",      "Denoiser",            Kind::input,  { "dn" } },
        { "comp",    "Compressor",          Kind::input,  { "comp" } },
        { "fxs",     "FX Sends",            Kind::input,  { "fxs" } },
        { "mod",     "Modulation",          Kind::input,  { "mod" } },
        { "pitch",   "Pitch Shifter",       Kind::input,  { "pitch" } },
        { "pan3d",   "3D Pan",              Kind::input,  { "pan3d" } },
        { "lim",     "Limiter",             Kind::input,  { "lim" } },
        { "sync",    "Sync Delay",          Kind::input,  { "sync", "delay" } },
        // Buses ("bus.A1.lim.on")
        { "mix",     "Fader, mute, mono",   Kind::bus,    { "gain", "mute", "mono" } },
        { "eq",      "Equalizer",           Kind::bus,    { "eq" } },
        { "lim",     "Limiter",             Kind::bus,    { "lim" } },
        { "fxr",     "FX Return",           Kind::bus,    { "fxr" } },
        { "sync",    "Sync Delay",          Kind::bus,    { "sync", "delay" } },
        // Not tied to a channel ("fx.rev.size", "mon.on")
        { "fx",      "Internal FX settings", Kind::global, { "fx" } },
        { "monitor", "Monitor",             Kind::global, { "mon" } },
    };
    return d;
}

/** Sections that are the processing of a channel (what "copy all sections" takes): not the fader, the routing
    or the sync delay, which belong to the channel and its device rather than to its sound. */
inline bool isProcessingSection (std::string_view id)
{
    static const std::set<std::string, std::less<>> p = { "eq", "gate", "dn", "comp", "fxs", "mod", "pitch", "pan3d", "lim", "fxr" };
    return p.find (id) != p.end();
}

/** "*" as the section of a clip: all the processing sections. */
inline constexpr const char* kAllProcessing = "*";

namespace detail
{
inline bool isDigits (std::string_view s)
{
    return ! s.empty() && std::all_of (s.begin(), s.end(), [] (char c) { return c >= '0' && c <= '9'; });
}

inline bool nameMatches (std::string_view name, std::string_view prefix)
{
    return name == prefix || (name.size() > prefix.size() && name.substr (0, prefix.size()) == prefix && name[prefix.size()] == '.');
}
} // namespace detail

/** Section id of a parameter name for a kind of channel; empty if it belongs to none. */
inline std::string sectionOf (Kind kind, std::string_view name)
{
    for (auto& d : defs())
        if (d.kind == kind)
            for (auto* n : d.names)
                if (detail::nameMatches (name, n))
                    return d.id;
    return {};
}

/** A parameter id taken apart. */
struct Ref
{
    Kind kind = Kind::global;
    std::string channel;   // "in3" or "bus.A1" (the id up to the name); empty for global parameters
    std::string name;      // "gate.thr"; for global parameters the whole id
    std::string section;   // Def::id, empty if the parameter belongs to no section
};

/** Splits "in3.gate.thr", "bus.A1.lim.on", "fx.rev.size". Anything else is a global parameter. */
inline Ref parse (std::string_view id)
{
    Ref r;
    r.name = std::string (id);
    const auto first = id.find ('.');
    if (first != std::string_view::npos)
    {
        const auto head = id.substr (0, first);
        const auto rest = id.substr (first + 1);
        if (head.size() > 2 && head.substr (0, 2) == "in" && detail::isDigits (head.substr (2)) && ! rest.empty())
        {
            r.kind = Kind::input;
            r.channel = std::string (head);
            r.name = std::string (rest);
        }
        else if (head == "bus")
        {
            const auto second = rest.find ('.');
            if (second != std::string_view::npos && second > 0 && second + 1 < rest.size())
            {
                r.kind = Kind::bus;
                r.channel = "bus." + std::string (rest.substr (0, second));
                r.name = std::string (rest.substr (second + 1));
            }
        }
    }
    r.section = sectionOf (r.kind, r.name);
    return r;
}

inline std::string inputKey (int index)                { return "in" + std::to_string (index + 1); }
inline std::string busKey (const std::string& code)    { return "bus." + code; }

/** Section ids once each (in the order of defs()), with the title of the first kind that has it. */
inline std::vector<std::pair<std::string, std::string>> allSections()
{
    std::vector<std::pair<std::string, std::string>> out;
    for (auto& d : defs())
        if (std::none_of (out.begin(), out.end(), [&] (auto& o) { return o.first == d.id; }))
            out.emplace_back (d.id, d.title);
    return out;
}

inline std::string titleOf (std::string_view id)
{
    for (auto& d : defs())
        if (id == d.id)
            return d.title;
    return std::string (id);
}

//==============================================================================
/** What copy takes: the values of one section (or of all the processing sections) of one channel.
    Names, not ids, so it can be pasted into any other channel of the same kind. */
struct Clip
{
    Kind kind = Kind::input;
    std::string section;                   // Def::id or kAllProcessing
    std::map<std::string, float> values;   // name (id without the channel part) -> value

    bool valid() const noexcept { return ! values.empty(); }
};

/** Copies a section of a channel. `range` is every parameter, idOf (element) gives its id, valueOf (element) its value. */
template <class Range, class IdFn, class ValueFn>
Clip copyFrom (const Range& range, IdFn idOf, ValueFn valueOf, Kind kind, const std::string& channel, const std::string& section)
{
    Clip c;
    c.kind = kind;
    c.section = section;
    for (auto& e : range)
    {
        const std::string id = idOf (e);
        const Ref r = parse (id);
        if (r.kind != kind || r.channel != channel) continue;
        const bool take = section == kAllProcessing ? isProcessingSection (r.section) : (! r.section.empty() && r.section == section);
        if (take) c.values[r.name] = (float) valueOf (e);
    }
    return c;
}

/** The (name, value) pairs to write when the clip is pasted into a channel of `kind`. `section` limits the paste to
    one section (so one section can be taken out of a "copy all"); empty or kAllProcessing pastes everything the clip holds.
    Nothing if the clip comes from another kind of channel or does not hold that section. */
inline std::vector<std::pair<std::string, float>> valuesFor (const Clip& clip, Kind kind, const std::string& section = {})
{
    std::vector<std::pair<std::string, float>> out;
    if (clip.kind != kind) return out;
    const bool limit = ! section.empty() && section != kAllProcessing;
    if (limit && clip.section != kAllProcessing && clip.section != section) return out;
    for (auto& [name, v] : clip.values)
        if (! limit || sectionOf (kind, name) == section)
            out.emplace_back (name, v);
    return out;
}

//==============================================================================
/** What a scene covers. Everything that is not covered is left alone when the scene is recalled.
    Empty `sections` = every section, empty `channels` = every channel. */
struct Scope
{
    std::set<std::string> sections;   // Def ids; an id means that section on every kind of channel that has it
    std::set<std::string> channels;   // "in3", "bus.A1"

    bool isAll() const noexcept { return sections.empty() && channels.empty(); }

    bool covers (const Ref& r) const
    {
        if (isAll()) return true;
        if (r.kind == Kind::global)   // not tied to a channel: only when its section is asked for
            return ! sections.empty() && ! r.section.empty() && sections.count (r.section) > 0;
        if (! channels.empty() && channels.count (r.channel) == 0) return false;
        if (sections.empty()) return true;
        return ! r.section.empty() && sections.count (r.section) > 0;
    }
    bool covers (std::string_view id) const { return isAll() || covers (parse (id)); }

    bool operator== (const Scope& o) const noexcept { return sections == o.sections && channels == o.channels; }
};

inline std::string join (const std::set<std::string>& s, char sep = ',')
{
    std::string out;
    for (auto& x : s) { if (! out.empty()) out += sep; out += x; }
    return out;
}

inline std::set<std::string> split (std::string_view text, char sep = ',')
{
    std::set<std::string> out;
    size_t start = 0;
    while (start <= text.size())
    {
        auto end = text.find (sep, start);
        if (end == std::string_view::npos) end = text.size();
        auto part = text.substr (start, end - start);
        while (! part.empty() && part.front() == ' ') part.remove_prefix (1);
        while (! part.empty() && part.back() == ' ') part.remove_suffix (1);
        if (! part.empty()) out.insert (std::string (part));
        start = end + 1;
    }
    return out;
}

/** "Equalizer, Gate" for the sections of a scope (empty for "every section"). */
inline std::string describeSections (const Scope& s)
{
    std::string out;
    for (auto& d : allSections())
        if (s.sections.count (d.first))
            out += (out.empty() ? "" : ", ") + d.second;
    return out;
}
} // namespace hydra::sections
