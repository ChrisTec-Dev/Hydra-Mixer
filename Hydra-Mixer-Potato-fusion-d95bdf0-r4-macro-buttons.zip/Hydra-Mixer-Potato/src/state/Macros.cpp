#include "Macros.h"

namespace hydra
{
static_assert (macros::kSlots == kMaxMacros, "core/Macros.h and Common.h must agree on the number of Macro Button slots");

namespace
{
juce::String text (const std::string& s) { return juce::String::fromUTF8 (s.c_str()); }
} // namespace

MacroBank::MacroBank (Engine& e) : engine (e)
{
    for (auto& p : engine.params.all())
        byLowerId[p->id.toLowerCase().toStdString()] = p.get();

    io.triggerOn = [this] (int k) { return engine.macroTrigger[(size_t) k]->isOn(); };
    io.consume   = [this] (int k) { engine.macroTrigger[(size_t) k]->set (0.0f, true); };   // like MIDI: no undo step
    io.readParam = [this] (const std::string& id, double& value)
    {
        if (auto* p = findParam (id))
        {
            value = (double) p->get();
            return true;
        }
        return false;
    };
    io.run = [this] (const std::string& script) { if (runScript) runScript (text (script)); };
    io.dropped = [this] (int k)
    {
        logLine ("Macro Button " + juce::String (k + 1) + ": a press was ignored (macros that press each other went too deep)");
    };
    startTimerHz (50);   // MIDI / shortcut / remote triggers
}

MacroBank::~MacroBank() { stopTimer(); }

Param* MacroBank::findParam (const std::string& id) const
{
    const auto it = byLowerId.find (remote::detail::lower (id));
    return it != byLowerId.end() ? it->second : nullptr;
}

void MacroBank::poll()
{
    // Without a script runner the triggers wait. A script that somehow pumps messages must not poll again inside itself.
    if (! runScript || polling) return;
    struct Guard
    {
        explicit Guard (bool& flag) : f (flag) { f = true; }
        ~Guard() { f = false; }
        bool& f;
    } guard (polling);
    machine.poll (io);
}

void MacroBank::set (int slot, macros::Button b)
{
    if (! juce::isPositiveAndBelow (slot, kMaxMacros)) return;
    macros::sanitise (b);
    b.litParam = macros::resolveParamRef (b.litParam);
    if (! b.litParam.empty() && findParam (b.litParam) == nullptr) b.litParam.clear();   // a name that is no parameter
    if (! b.used) b = macros::Button();

    auto& current = machine.buttons[(size_t) slot];
    if (current == b) return;
    current = std::move (b);
    machine.resetSlot (slot);
    ++version;
}

void MacroBank::clearAll()
{
    for (int k = 0; k < kMaxMacros; ++k)
    {
        machine.buttons[(size_t) k] = macros::Button();
        machine.resetSlot (k);
    }
    ++version;
}

int MacroBank::countUsed() const noexcept
{
    int n = 0;
    for (const auto& b : machine.buttons) n += b.used ? 1 : 0;
    return n;
}

bool MacroBank::isLit (int slot) const
{
    if (! juce::isPositiveAndBelow (slot, kMaxMacros)) return false;
    const auto& b = machine.buttons[(size_t) slot];
    double value = 0.0;
    bool hasValue = false;
    if (! b.litParam.empty())
        if (auto* p = findParam (b.litParam))
        {
            value = (double) p->get();
            hasValue = true;
        }
    return macros::lit (b, engine.macroTrigger[(size_t) slot]->isOn(), machine.toggleState (slot), hasValue, value);
}

std::unique_ptr<juce::XmlElement> MacroBank::toXml() const
{
    auto xml = std::make_unique<juce::XmlElement> ("MACROS");
    for (int k = 0; k < kMaxMacros; ++k)
    {
        const auto& b = machine.buttons[(size_t) k];
        if (! b.used) continue;
        auto* e = xml->createNewChildElement ("MACRO");
        e->setAttribute ("n", k + 1);
        e->setAttribute ("name", text (b.name));
        e->setAttribute ("colour", text (macros::colourText (b.colour)));
        e->setAttribute ("mode", juce::String (macros::modeName (b.mode)));
        if (! b.litParam.empty())
        {
            e->setAttribute ("lit", text (b.litParam));
            e->setAttribute ("litAt", b.litAt);
        }
        // The scripts as text nodes (they have quotes, brackets and new lines), like the settings of a scene section.
        if (! b.onScript.empty())  e->createNewChildElement ("ON")->addTextElement (text (b.onScript));
        if (! b.offScript.empty()) e->createNewChildElement ("OFF")->addTextElement (text (b.offScript));
    }
    return xml;
}

void MacroBank::fromXml (const juce::XmlElement& xml)
{
    for (auto& b : machine.buttons) b = macros::Button();

    for (auto* e : xml.getChildWithTagNameIterator ("MACRO"))
    {
        const int slot = e->getIntAttribute ("n", 0) - 1;
        if (! juce::isPositiveAndBelow (slot, kMaxMacros) || machine.buttons[(size_t) slot].used) continue;

        macros::Button b;
        b.used = true;
        b.name = e->getStringAttribute ("name").toStdString();
        macros::parseColour (e->getStringAttribute ("colour").toStdString(), b.colour);   // unreadable: the default colour stays
        macros::modeFromName (e->getStringAttribute ("mode").toStdString(), b.mode);      // unknown: a trigger button
        if (auto* on = e->getChildByName ("ON"))   b.onScript = on->getAllSubText().toStdString();
        if (auto* off = e->getChildByName ("OFF")) b.offScript = off->getAllSubText().toStdString();
        b.litParam = macros::resolveParamRef (e->getStringAttribute ("lit").toStdString());
        b.litAt = e->getDoubleAttribute ("litAt", 0.5);
        macros::sanitise (b);
        machine.buttons[(size_t) slot] = std::move (b);
    }
    for (int k = 0; k < kMaxMacros; ++k) machine.resetSlot (k);
    ++version;
}
} // namespace hydra
