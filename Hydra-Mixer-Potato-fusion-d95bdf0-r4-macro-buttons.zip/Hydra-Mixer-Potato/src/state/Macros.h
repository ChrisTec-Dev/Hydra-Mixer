#pragma once
#include "engine/Engine.h"
#include "core/Macros.h"
#include <unordered_map>

namespace hydra
{
/** The Macro Buttons of the session. What a button does (modes, lit state, chains of macros) is in core/Macros.h.

    - 32 fixed slots. Slot k is pressed through Engine::macroTrigger[k] (the parameter "macro.<k+1>"), so MIDI learn,
      keyboard shortcuts (media keys too) and remote scripts (Param[macro.3] = 1) press buttons like any switch, and a
      button keeps its MIDI mapping and shortcut for as long as it stays in its slot.
    - The scripts run through the application's script runner (runScript, set in Main.cpp to the remote control's
      interpreter: the Voicemeeter syntax plus every Hydra parameter). Changes made by a script count like MIDI: no undo step.
    - Polled on the message thread; nothing here touches the audio thread.
    - Stored with the session as <MACROS>, one <MACRO n="3" ...> per used slot, the scripts as text. */
class MacroBank : private juce::Timer
{
public:
    explicit MacroBank (Engine& e);
    ~MacroBank() override;

    const macros::Button& get (int slot) const { return machine.buttons[(size_t) slot]; }
    /** Replaces the button of a slot (an unused button empties it). Text is brought within the limits first and the
        "lit while" parameter is reduced to its Hydra id (Strip[0].Mute -> in1.mute; unknown names are dropped). */
    void set (int slot, macros::Button b);
    void clear (int slot) { set (slot, macros::Button()); }
    void clearAll();
    int countUsed() const noexcept;
    Param* trigger (int slot) const { return juce::isPositiveAndBelow (slot, kMaxMacros) ? engine.macroTrigger[(size_t) slot] : nullptr; }

    /** Whether the button is lit (see macros::lit). */
    bool isLit (int slot) const;
    /** The parameter with this id (any case), or nullptr. */
    Param* findParam (const std::string& id) const;

    /** Runs a script. Set by the application; until it is, the triggers are left alone. */
    std::function<void (const juce::String&)> runScript;

    /** Looks at the triggers once. The timer does it 50 times a second; public so that tests can drive it. */
    void poll();

    std::unique_ptr<juce::XmlElement> toXml() const;
    /** Replaces every button with the ones of a <MACROS> element. */
    void fromXml (const juce::XmlElement&);

    /** Bumped on every change of the buttons (autosave, UI refresh). */
    std::atomic<uint32_t> version { 0 };

private:
    void timerCallback() override { poll(); }

    Engine& engine;
    macros::Machine machine;
    macros::Machine::Io io;
    std::unordered_map<std::string, Param*> byLowerId;
    bool polling = false;
};
} // namespace hydra
