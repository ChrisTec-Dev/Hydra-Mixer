#pragma once

#include "net/RemoteScript.h"

#include <algorithm>
#include <array>
#include <cctype>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <string>

/** Macro Buttons: buttons that run a script in the syntax of net/RemoteScript.h (the Voicemeeter syntax, plus every Hydra
    parameter) when they are pressed. This file is the logic only: no JUCE, no Engine, so it is tested offline
    (tests/MacrosTest.cpp). state/Macros.* connects it to the parameters, the session and the script runner.

    - A button lives in a fixed slot 0..kSlots-1. Slot k is triggered by the parameter "macro.<k+1>" (a switch that is not
      stored), so the mouse, MIDI learn, keyboard shortcuts (media keys too) and remote scripts (Param[macro.3] = 1) all reach
      it the same way. A *press* is the trigger going from off to on, a *release* the trigger going from on to off.
    - Modes: trigger = a press runs the ON script (the trigger is switched off again at once); push = a press runs the
      ON script and the release the OFF script (the trigger stays on while held); toggle = every press flips the button:
      ON script, then OFF script, then ON script ... (the trigger is switched off again at once).
    - A toggle button that names a parameter (litParam) decides from that parameter instead of from its own memory, so it
      stays right when the mixer is changed by hand: lit means "press = OFF script".
    - Lit: a button is lit while its parameter is >= litAt; without one, a push button is lit while it is held and a toggle
      button while it is "on"; a trigger button is never lit.
    - A script may press other buttons. A press that was started by a script that was started by a press ... may go at most
      kMaxChain deep, so a macro that starts itself (or two that start each other) runs a few times and stops.
    Everything here runs on the message thread. */
namespace hydra::macros
{
constexpr int kSlots = 32;                 // must equal kMaxMacros of Common.h (state/Macros.cpp checks it)
constexpr std::size_t kMaxName = 24;       // bytes
constexpr std::size_t kMaxScript = 2000;
constexpr std::size_t kMaxParamId = 80;

enum class Mode { trigger, push, toggle };

inline const char* modeName (Mode m) noexcept
{
    switch (m)
    {
        case Mode::push:    return "push";
        case Mode::toggle:  return "toggle";
        case Mode::trigger: break;
    }
    return "trigger";
}

inline bool modeFromName (const std::string& s, Mode& out) noexcept
{
    if (s == "trigger") { out = Mode::trigger; return true; }
    if (s == "push")    { out = Mode::push;    return true; }
    if (s == "toggle")  { out = Mode::toggle;  return true; }
    return false;
}

struct Button
{
    bool used = false;                       // false: an empty slot
    std::string name;                        // shown on the button
    std::uint32_t colour = 0xff3d8bd9;       // ARGB
    Mode mode = Mode::trigger;
    std::string onScript, offScript;         // see net/RemoteScript.h
    std::string litParam;                    // Hydra parameter id (lower case); empty: lit by the button's own state
    double litAt = 0.5;                      // lit while that parameter is >= this (in the parameter's own unit)

    bool operator== (const Button&) const = default;
};

/** Cuts a UTF-8 text to at most maxBytes without splitting a character. */
inline void truncateUtf8 (std::string& s, std::size_t maxBytes)
{
    if (s.size() <= maxBytes) return;
    std::size_t n = maxBytes;
    while (n > 0 && (static_cast<unsigned char> (s[n]) & 0xC0) == 0x80) --n;   // s[n] would be the first byte dropped
    s.resize (n);
}

/** Brings a button read from a file or typed by the user within the limits. */
inline void sanitise (Button& b)
{
    truncateUtf8 (b.name, kMaxName);
    truncateUtf8 (b.onScript, kMaxScript);
    truncateUtf8 (b.offScript, kMaxScript);
    truncateUtf8 (b.litParam, kMaxParamId);
    if (! std::isfinite (b.litAt)) b.litAt = 0.5;
    b.litAt = std::clamp (b.litAt, -1.0e6, 1.0e6);
    b.colour |= 0xff000000u;
}

/** "ff3d8bd9": the colour as the session file keeps it (8 hexadecimal digits, ARGB). */
inline std::string colourText (std::uint32_t argb)
{
    static const char digits[] = "0123456789abcdef";
    std::string s (8, '0');
    for (int i = 7; i >= 0; --i, argb >>= 4) s[(std::size_t) i] = digits[argb & 0xF];
    return s;
}

inline bool parseColour (const std::string& s, std::uint32_t& out)
{
    if (s.size() != 8) return false;
    std::uint32_t v = 0;
    for (const char c : s)
    {
        const int d = std::isdigit (static_cast<unsigned char> (c)) ? c - '0'
                    : (c >= 'a' && c <= 'f') ? c - 'a' + 10
                    : (c >= 'A' && c <= 'F') ? c - 'A' + 10 : -1;
        if (d < 0) return false;
        v = (v << 4) | (std::uint32_t) d;
    }
    out = v;
    return true;
}

/** The Hydra parameter id for what a user typed: an id ("in1.mute", "bus.A1.gain") or a Voicemeeter name ("Strip[0].Mute",
    "Param[in1.mute]"). Lower case; empty if it is neither. Whether the parameter exists is checked where the engine is known. */
inline std::string resolveParamRef (const std::string& text)
{
    const std::string t = remote::detail::trim (text);
    if (t.empty() || t.find_first_of (";=\"\r\n") != std::string::npos) return {};   // one name, not a script
    if (t.find_first_of ("[(") == std::string::npos)
    {
        for (const char c : t)
            if (! std::isalnum (static_cast<unsigned char> (c)) && c != '.' && c != '_') return {};
        return remote::detail::lower (t);
    }
    const auto actions = remote::actionsFor (t + " = 0");
    if (actions.size() == 1 && actions[0].kind == remote::Action::Kind::param) return actions[0].id;
    return {};
}

/** Whether a button is lit. mixerValue is the value of its litParam when hasMixerValue (the parameter exists). */
inline bool lit (const Button& b, bool triggerOn, bool toggleState, bool hasMixerValue, double mixerValue)
{
    if (! b.used) return false;
    if (! b.litParam.empty() && hasMixerValue) return mixerValue >= b.litAt;
    switch (b.mode)
    {
        case Mode::push:    return triggerOn;
        case Mode::toggle:  return toggleState;
        case Mode::trigger: break;
    }
    return false;
}

/** The state of all buttons and what a poll of the triggers does. */
class Machine
{
public:
    static constexpr int kMaxChain = 8;

    std::array<Button, (std::size_t) kSlots> buttons;

    /** What the machine needs from its surroundings. triggerOn, consume and run are required. */
    struct Io
    {
        std::function<bool (int slot)> triggerOn;                              // the trigger parameter of the slot is on
        std::function<void (int slot)> consume;                                // switches it off (not an undo step)
        std::function<bool (const std::string& id, double& value)> readParam;  // any parameter by id; false if there is none
        std::function<void (const std::string& script)> run;                   // runs a script (it may press other buttons)
        std::function<void (int slot)> dropped;                                // optional: a press was ignored (chain too deep)
    };

    /** Looks at every trigger once: runs the scripts of the presses and releases it finds. */
    void poll (const Io& io)
    {
        for (int k = 0; k < kSlots; ++k)
        {
            const auto i = (std::size_t) k;
            const bool on = io.triggerOn (k);
            const bool rose = on && ! wasOn[i];
            const bool fell = ! on && wasOn[i];
            wasOn[i] = on;
            if (! rose && ! fell) continue;

            const int depth = std::max (1, chain[i]);   // how many presses led to this one (1 = a person, MIDI, a shortcut)
            chain[i] = 0;
            const Button& b = buttons[i];

            if (! b.used || depth > kMaxChain)
            {
                if (on) { io.consume (k); wasOn[i] = false; }
                if (b.used && io.dropped) io.dropped (k);
                continue;
            }

            enum class Run { none, on, off } what = Run::none;
            bool consumeIt = false;
            switch (b.mode)
            {
                case Mode::trigger:
                    if (rose) { what = Run::on; consumeIt = true; }
                    break;
                case Mode::push:
                    what = rose ? Run::on : Run::off;
                    break;
                case Mode::toggle:
                    if (rose)
                    {
                        double v = 0.0;
                        const bool known = ! b.litParam.empty() && io.readParam && io.readParam (b.litParam, v);
                        const bool current = known ? v >= b.litAt : toggled[i];
                        toggled[i] = ! current;
                        what = toggled[i] ? Run::on : Run::off;
                        consumeIt = true;
                    }
                    break;
            }

            // Switched off before the script runs, so that the script may press the same button again.
            if (consumeIt) { io.consume (k); wasOn[i] = false; }

            const std::string& script = what == Run::on ? b.onScript : b.offScript;
            if (what == Run::none || script.empty()) continue;

            std::array<bool, (std::size_t) kSlots> before {};
            for (int j = 0; j < kSlots; ++j) before[(std::size_t) j] = io.triggerOn (j);
            io.run (script);
            for (int j = 0; j < kSlots; ++j)
                if (io.triggerOn (j) != before[(std::size_t) j]) chain[(std::size_t) j] = depth + 1;
        }
    }

    /** The "on" state of a toggle button that has no parameter to follow. */
    bool toggleState (int slot) const noexcept { return toggled[(std::size_t) slot]; }

    /** After the button of a slot was replaced: its memory starts again (a press that is under way is not lost). */
    void resetSlot (int slot) noexcept
    {
        toggled[(std::size_t) slot] = false;
        chain[(std::size_t) slot] = 0;
    }

private:
    std::array<bool, (std::size_t) kSlots> wasOn {}, toggled {};
    std::array<int, (std::size_t) kSlots> chain {};
};
} // namespace hydra::macros
