#pragma once
#include "Widgets.h"
#include "state/Macros.h"

namespace hydra
{
class MacroEditor;

/** One slot of the Macro Buttons window. A press with the mouse sets the trigger parameter of the slot, like MIDI or a
    keyboard shortcut would; a push button is released again when the mouse button goes up. Right-click: edit, delete,
    MIDI learn, keyboard shortcut (the menu of every control, plus the entries below). An empty slot opens the editor. */
class MacroButton final : public ParamControl
{
public:
    MacroButton (UiContext& c, MacroBank& b, int slotIndex);

    /** The slot should be edited (an empty slot was clicked, or Edit... was picked) / deleted (picked in the menu). */
    std::function<void (int)> onEdit, onDelete;

    void paint (juce::Graphics&) override;
    void pollParams() override;
    void mouseEnter (const juce::MouseEvent&) override { hover = true; repaint(); }
    void mouseExit (const juce::MouseEvent&) override  { hover = false; repaint(); }

private:
    void press (const juce::MouseEvent&) override;
    void release (const juce::MouseEvent&) override;
    bool addExtraMenuItems (juce::PopupMenu&) override;
    void extraMenuChosen (int id) override;

    MacroBank& bank;
    const int slot;
    bool hover = false, shownLit = false;
    uint32_t seenBank = ~0u;
};

/** Tools > Macro Buttons: the 32 slots as a grid. Click a button to run it; the editor covers the grid while it is open. */
class MacroPanel final : public juce::Component
{
public:
    MacroPanel (UiContext& c, MacroBank& b);
    ~MacroPanel() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void edit (int slot);
    void closeEditor();
    void confirmDelete (int slot);

    UiContext& ctx;
    MacroBank& bank;
    juce::Label title { {}, "MACRO BUTTONS" }, hint;
    std::vector<std::unique_ptr<MacroButton>> buttons;
    std::unique_ptr<MacroEditor> editor;
};
} // namespace hydra
