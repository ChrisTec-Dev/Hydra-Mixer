#include "MacroPanel.h"

namespace hydra
{
namespace
{
juce::String text (const std::string& s) { return juce::String::fromUTF8 (s.c_str()); }

void styleLabel (juce::Label& l, bool dim = true, float size = 13.0f)
{
    l.setFont (theme::font (size));
    l.setColour (juce::Label::textColourId, dim ? theme::textDim : theme::text);
}

/** What a button is called on screen: its name, or "Macro 3" while it has none. */
juce::String shownName (const macros::Button& b, int slot)
{
    return b.name.empty() ? "Macro " + juce::String (slot + 1) : text (b.name);
}

constexpr std::uint32_t kPalette[] = { 0xff3d8bd9, 0xff35d0f4, 0xff3ee08f, 0xffffc23f, 0xffffa53d, 0xffff4d5e, 0xffff6aa6, 0xff8d6cff };
constexpr size_t kNumColours = sizeof (kPalette) / sizeof (kPalette[0]);
} // namespace

//==============================================================================
MacroButton::MacroButton (UiContext& c, MacroBank& b, int slotIndex)
    : ParamControl (c, *b.trigger (slotIndex)), bank (b), slot (slotIndex) {}

void MacroButton::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat().reduced (3.0f);
    const auto& b = bank.get (slot);
    if (! b.used)
    {
        g.setColour (theme::panel);
        g.fillRoundedRectangle (r, 6.0f);
        g.setColour (hover ? theme::textDim : theme::outline);
        g.drawRoundedRectangle (r, 6.0f, 1.0f);
        g.setColour (hover ? theme::textDim : theme::textFaint);
        g.setFont (theme::font (24.0f));
        g.drawText ("+", r, juce::Justification::centred);
        g.setFont (theme::font (10.0f));
        g.drawText (juce::String (slot + 1), r.reduced (6.0f, 4.0f), juce::Justification::topLeft);
        return;
    }

    const juce::Colour colour (b.colour);
    const bool lit = bank.isLit (slot);
    g.setColour (lit ? colour : (hover ? theme::raised.brighter (0.08f) : theme::raised));
    g.fillRoundedRectangle (r, 6.0f);
    if (! lit)
    {
        g.setColour (colour.withAlpha (0.85f));
        g.drawRoundedRectangle (r, 6.0f, 1.5f);
    }
    g.setColour (lit ? theme::bg : theme::text);
    g.setFont (theme::font (13.0f, true));
    g.drawFittedText (shownName (b, slot), r.toNearestInt().reduced (8, 12), juce::Justification::centred, 2);
    g.setFont (theme::font (9.5f));
    g.setColour (lit ? theme::bg.withAlpha (0.7f) : theme::textFaint);
    g.drawText (juce::String (slot + 1), r.reduced (6.0f, 4.0f), juce::Justification::topLeft);
    g.drawText (juce::String (macros::modeName (b.mode)).toUpperCase(), r.reduced (6.0f, 4.0f), juce::Justification::centredBottom);
}

void MacroButton::pollParams()
{
    ParamControl::pollParams();
    const bool lit = bank.isLit (slot);
    const auto v = bank.version.load();
    if (lit != shownLit || v != seenBank)
    {
        shownLit = lit;
        seenBank = v;
        repaint();
    }
}

void MacroButton::press (const juce::MouseEvent&)
{
    if (! bank.get (slot).used)
    {
        if (onEdit) onEdit (slot);
        return;
    }
    param.set (1.0f);
}

void MacroButton::release (const juce::MouseEvent&)
{
    const auto& b = bank.get (slot);
    if (b.used && b.mode != macros::Mode::push) return;   // trigger and toggle buttons are switched off by the bank itself
    // The bank looks at the triggers 50 times a second: even a very short click must be seen as a press before it is released.
    juce::Component::SafePointer<MacroButton> safe (this);
    juce::Timer::callAfterDelay (40, [safe] { if (safe != nullptr && safe->param.isOn()) safe->param.set (0.0f); });
}

bool MacroButton::addExtraMenuItems (juce::PopupMenu& m)
{
    const bool used = bank.get (slot).used;
    m.addItem (100, used ? "Edit Macro Button..." : "Create Macro Button...");
    m.addItem (101, "Delete Macro Button", used);
    return true;
}

void MacroButton::extraMenuChosen (int id)
{
    if (id == 100 && onEdit) onEdit (slot);
    if (id == 101 && onDelete) onDelete (slot);
}

//==============================================================================
/** A colour to pick in the editor. */
class MacroColourSwatch final : public juce::Component
{
public:
    std::function<void()> onClick;
    juce::Colour colour;
    bool selected = false;

    void paint (juce::Graphics& g) override
    {
        auto r = getLocalBounds().toFloat().reduced (3.0f);
        g.setColour (colour);
        g.fillRoundedRectangle (r, 5.0f);
        if (selected)
        {
            g.setColour (theme::text);
            g.drawRoundedRectangle (r.expanded (1.5f), 6.0f, 2.0f);
        }
    }
    void mouseUp (const juce::MouseEvent& e) override { if (e.mouseWasClicked() && onClick) onClick(); }
};

/** The form that covers the grid while one button is edited: name, mode, colour, the two scripts and the optional
    "lit while" parameter. Save writes the button into the bank; Delete asks the panel; Cancel changes nothing. */
class MacroEditor final : public juce::Component
{
public:
    /** Called after Save or Cancel; the panel then closes the editor (asynchronously: the button that was clicked belongs to it). */
    std::function<void()> onClose;
    std::function<void()> onDelete;

    MacroEditor (MacroBank& b, int slotIndex) : bank (b), slot (slotIndex)
    {
        const bool existing = bank.get (slot).used;
        const macros::Button cur = existing ? bank.get (slot) : macros::Button();
        colour = cur.colour;

        addAndMakeVisible (title);
        styleLabel (title, false, 15.0f);
        title.setText ((existing ? "EDIT MACRO BUTTON " : "NEW MACRO BUTTON ") + juce::String (slot + 1), juce::dontSendNotification);

        for (auto* l : { &nameL, &modeL, &colourL, &onL, &offL, &litL, &atL })
        {
            addAndMakeVisible (l);
            styleLabel (*l);
        }
        nameL.setText ("Name", juce::dontSendNotification);
        modeL.setText ("Mode", juce::dontSendNotification);
        colourL.setText ("Colour", juce::dontSendNotification);
        onL.setText ("ON script  -  runs when the button is pressed", juce::dontSendNotification);
        litL.setText ("Lit while", juce::dontSendNotification);
        atL.setText (">=", juce::dontSendNotification);
        atL.setJustificationType (juce::Justification::centred);

        addAndMakeVisible (name);
        name.setInputRestrictions ((int) macros::kMaxName);
        name.setText (text (cur.name), false);
        name.setTextToShowWhenEmpty ("Macro " + juce::String (slot + 1), theme::textFaint);

        addAndMakeVisible (mode);
        mode.addItem ("Trigger  -  a press runs the ON script", 1);
        mode.addItem ("Push  -  ON script while held, OFF script on release", 2);
        mode.addItem ("Toggle  -  every press alternates the ON and OFF scripts", 3);
        mode.setSelectedId (cur.mode == macros::Mode::push ? 2 : cur.mode == macros::Mode::toggle ? 3 : 1, juce::dontSendNotification);
        mode.onChange = [this] { updateMode(); refreshStatus(); };

        for (size_t k = 0; k < kNumColours; ++k)
        {
            swatches[k].colour = juce::Colour (kPalette[k]);
            swatches[k].onClick = [this, k] { colour = kPalette[k]; updateSwatches(); };
            addAndMakeVisible (swatches[k]);
        }
        updateSwatches();

        for (auto* e : { &onScript, &offScript })
        {
            addAndMakeVisible (e);
            e->setMultiLine (true);
            e->setReturnKeyStartsNewLine (true);
            e->setFont (theme::mono (12.5f));
            e->setInputRestrictions ((int) macros::kMaxScript);
            e->onTextChange = [this] { refreshStatus(); };
        }
        onScript.setText (text (cur.onScript), false);
        offScript.setText (text (cur.offScript), false);

        addAndMakeVisible (litParam);
        litParam.setInputRestrictions ((int) macros::kMaxParamId);
        litParam.setText (text (cur.litParam), false);
        litParam.setTextToShowWhenEmpty ("optional:  in1.mute   or   Strip[0].Mute", theme::textFaint);
        litParam.onTextChange = [this] { refreshStatus(); };
        addAndMakeVisible (litAt);
        litAt.setInputRestrictions (12, "0123456789.-");
        litAt.setText (juce::String (cur.litAt), false);
        litAt.onTextChange = [this] { refreshStatus(); };

        addAndMakeVisible (status);
        styleLabel (status);
        addAndMakeVisible (help);
        styleLabel (help);
        help.setJustificationType (juce::Justification::topLeft);
        help.setFont (theme::mono (11.5f));
        help.setText ("Strip[0].Mute = 1;          mute input 1               Bus[0].Gain -= 3;        A1 fader down by 3 dB\n"
                      "Strip[1].A1 = 1;            route input 2 to A1        Scene[2].Recall = 1;     recall scene 2\n"
                      "Param[macro.5] = 1;         press Macro Button 5       Command.Restart = 1;     restart the audio engine\n"
                      "Param[in1.pitch.semi] = 3;  any Hydra parameter, by its id\n"
                      "Several commands: separate them with ; or a new line. \"Lit while\" lights the button while that parameter is at or above the value.",
                      juce::dontSendNotification);

        addAndMakeVisible (saveBtn);
        addAndMakeVisible (deleteBtn);
        addAndMakeVisible (cancelBtn);
        saveBtn.onClick = [this] { save(); };
        cancelBtn.onClick = [this] { if (onClose) onClose(); };
        deleteBtn.setEnabled (existing);
        deleteBtn.onClick = [this] { if (onDelete) onDelete(); };

        updateMode();
        refreshStatus();
    }

    void paint (juce::Graphics& g) override { g.fillAll (theme::bg); }

    void resized() override
    {
        auto r = getLocalBounds().reduced (20, 14);
        title.setBounds (r.removeFromTop (26));
        r.removeFromTop (6);

        auto row = r.removeFromTop (28);
        nameL.setBounds (row.removeFromLeft (70));
        name.setBounds (row.removeFromLeft (220));
        row.removeFromLeft (24);
        modeL.setBounds (row.removeFromLeft (50));
        mode.setBounds (row.removeFromLeft (440));
        r.removeFromTop (8);

        row = r.removeFromTop (28);
        colourL.setBounds (row.removeFromLeft (70));
        for (auto& s : swatches) s.setBounds (row.removeFromLeft (32));
        r.removeFromTop (8);

        // The bottom part, from the bottom up; the two scripts share what is left.
        auto buttonRow = r.removeFromBottom (32);
        r.removeFromBottom (10);
        help.setBounds (r.removeFromBottom (96));
        r.removeFromBottom (6);
        status.setBounds (r.removeFromBottom (22));
        r.removeFromBottom (8);
        row = r.removeFromBottom (28);
        litL.setBounds (row.removeFromLeft (90));
        litParam.setBounds (row.removeFromLeft (300));
        atL.setBounds (row.removeFromLeft (40));
        litAt.setBounds (row.removeFromLeft (90));
        r.removeFromBottom (8);

        const int labelHeight = 20;
        onL.setBounds (r.removeFromTop (labelHeight));
        const int onHeight = juce::jmax (60, (r.getHeight() - labelHeight - 8) * 2 / 3);
        onScript.setBounds (r.removeFromTop (onHeight));
        r.removeFromTop (8);
        offL.setBounds (r.removeFromTop (labelHeight));
        offScript.setBounds (r);

        saveBtn.setBounds (buttonRow.removeFromRight (110));
        buttonRow.removeFromRight (8);
        cancelBtn.setBounds (buttonRow.removeFromRight (110));
        deleteBtn.setBounds (buttonRow.removeFromLeft (110));
    }

private:
    macros::Mode selectedMode() const
    {
        const int id = mode.getSelectedId();
        return id == 2 ? macros::Mode::push : id == 3 ? macros::Mode::toggle : macros::Mode::trigger;
    }

    void updateSwatches()
    {
        for (size_t k = 0; k < kNumColours; ++k)
            swatches[k].selected = kPalette[k] == colour;
        for (auto& s : swatches) s.repaint();
    }

    /** The OFF script is used by Push and Toggle buttons only. */
    void updateMode()
    {
        const auto m = selectedMode();
        const bool usesOff = m != macros::Mode::trigger;
        offL.setText (m == macros::Mode::push   ? "OFF script  -  runs when the button is released"
                    : m == macros::Mode::toggle ? "OFF script  -  runs on every second press (when the button goes off)"
                                                : "OFF script  -  not used by a Trigger button", juce::dontSendNotification);
        offL.setAlpha (usesOff ? 1.0f : 0.45f);
        offScript.setEnabled (usesOff);
        offScript.setAlpha (usesOff ? 1.0f : 0.45f);
    }

    /** What the parameter field means, as the bank will read it (id of an existing parameter), or "" if it does not. */
    std::string litId() const
    {
        const auto typed = litParam.getText().trim().toStdString();
        const auto id = macros::resolveParamRef (typed);
        return (id.empty() || bank.findParam (id) == nullptr) ? std::string() : id;
    }

    double litThreshold() const
    {
        const auto t = litAt.getText().trim();
        return t.isEmpty() ? 0.5 : t.getDoubleValue();
    }

    /** One line under the form: how many commands each script holds, and what the "lit while" field refers to. */
    void refreshStatus()
    {
        juce::StringArray parts;
        bool problem = false;
        auto script = [&] (const juce::String& which, const juce::String& source, bool used)
        {
            if (! used || source.trim().isEmpty()) return;
            const auto n = remote::actionsFor (source.toStdString()).size();
            if (n == 0)
            {
                parts.add (which + ": nothing understood, check the syntax");
                problem = true;
            }
            else
                parts.add (which + ": " + juce::String ((int) n) + (n == 1 ? " command" : " commands"));
        };
        script ("ON", onScript.getText(), true);
        script ("OFF", offScript.getText(), selectedMode() != macros::Mode::trigger);

        if (litParam.getText().trim().isNotEmpty())
        {
            const auto id = litId();
            if (id.empty())
            {
                parts.add ("Lit while: unknown parameter");
                problem = true;
            }
            else
                parts.add ("Lit while " + text (id) + " >= " + juce::String (litThreshold()));
        }
        status.setText (parts.joinIntoString ("        "), juce::dontSendNotification);
        status.setColour (juce::Label::textColourId, problem ? theme::warn : theme::textDim);
    }

    void save()
    {
        macros::Button b;
        b.used = true;
        b.name = name.getText().trim().toStdString();
        b.colour = colour;
        b.mode = selectedMode();
        b.onScript = onScript.getText().trim().toStdString();
        b.offScript = offScript.getText().trim().toStdString();
        if (litParam.getText().trim().isNotEmpty())
        {
            b.litParam = litId();
            if (b.litParam.empty())
            {
                // Better to say so than to drop the setting silently.
                status.setText ("Lit while: unknown parameter. Use an id such as in1.mute or a name such as Strip[0].Mute, or leave the field empty.",
                                juce::dontSendNotification);
                status.setColour (juce::Label::textColourId, theme::warn);
                return;
            }
            b.litAt = litThreshold();
        }
        bank.set (slot, b);
        if (onClose) onClose();
    }

    MacroBank& bank;
    const int slot;
    std::uint32_t colour = 0xff3d8bd9;
    juce::Label title, nameL, modeL, colourL, onL, offL, litL, atL, status, help;
    juce::TextEditor name, onScript, offScript, litParam, litAt;
    juce::ComboBox mode;
    std::array<MacroColourSwatch, kNumColours> swatches;
    juce::TextButton saveBtn { "Save" }, deleteBtn { "Delete" }, cancelBtn { "Cancel" };
};

//==============================================================================
MacroPanel::MacroPanel (UiContext& c, MacroBank& b) : ctx (c), bank (b)
{
    addAndMakeVisible (title);
    styleLabel (title, false, 15.0f);
    addAndMakeVisible (hint);
    styleLabel (hint);
    hint.setJustificationType (juce::Justification::topLeft);
    hint.setText ("Click a button to run its script. Right-click a button to edit it, give it a MIDI control (MIDI Learn; use the Momentary mode for a "
                  "Push button) or a keyboard shortcut (media keys work too). Click an empty slot to create a button. A script can press other buttons "
                  "(Param[macro.3] = 1), and remote scripts can press them as well.", juce::dontSendNotification);

    for (int k = 0; k < kMaxMacros; ++k)
    {
        auto button = std::make_unique<MacroButton> (ctx, bank, k);
        button->onEdit = [this] (int slot) { edit (slot); };
        button->onDelete = [this] (int slot) { confirmDelete (slot); };
        addAndMakeVisible (*button);
        buttons.push_back (std::move (button));
    }
}

MacroPanel::~MacroPanel() = default;

void MacroPanel::paint (juce::Graphics& g) { g.fillAll (theme::bg); }

void MacroPanel::resized()
{
    auto r = getLocalBounds().reduced (16, 12);
    title.setBounds (r.removeFromTop (24));
    hint.setBounds (r.removeFromTop (48));
    r.removeFromTop (6);

    constexpr int columns = 8;
    constexpr int rows = kMaxMacros / columns;
    for (int k = 0; k < (int) buttons.size(); ++k)
    {
        const int col = k % columns, row = k / columns;
        const int x0 = r.getX() + col * r.getWidth() / columns, x1 = r.getX() + (col + 1) * r.getWidth() / columns;
        const int y0 = r.getY() + row * r.getHeight() / rows,   y1 = r.getY() + (row + 1) * r.getHeight() / rows;
        buttons[(size_t) k]->setBounds (x0, y0, x1 - x0, y1 - y0);
    }
    if (editor != nullptr) editor->setBounds (getLocalBounds());
}

void MacroPanel::edit (int slot)
{
    if (editor != nullptr || ! juce::isPositiveAndBelow (slot, kMaxMacros)) return;
    editor = std::make_unique<MacroEditor> (bank, slot);
    juce::Component::SafePointer<MacroPanel> safe (this);
    // Async: Save / Cancel are buttons of the editor, which is destroyed by closeEditor().
    editor->onClose = [safe] { juce::MessageManager::callAsync ([safe] { if (safe != nullptr) safe->closeEditor(); }); };
    editor->onDelete = [safe, slot] { if (safe != nullptr) safe->confirmDelete (slot); };
    addAndMakeVisible (*editor);
    editor->setBounds (getLocalBounds());
}

void MacroPanel::closeEditor() { editor.reset(); }

void MacroPanel::confirmDelete (int slot)
{
    if (! juce::isPositiveAndBelow (slot, kMaxMacros) || ! bank.get (slot).used) return;
    juce::Component::SafePointer<MacroPanel> safe (this);
    dialog::confirm (this, dialog::Kind::danger, "Delete Macro Button \"" + shownName (bank.get (slot), slot) + "\"?",
                     "Its MIDI assignment and shortcut are removed too.",
                     "Delete", [safe, slot]
                               {
                                   if (safe == nullptr) return;
                                   if (auto* trigger = safe->bank.trigger (slot))
                                   {
                                       safe->ctx.midi.removeMappingsFor (trigger);
                                       safe->ctx.hotkeys.remove (trigger);
                                   }
                                   safe->bank.clear (slot);
                                   safe->closeEditor();
                               });
}
} // namespace hydra
