# Hydra Mixer Potato compared with Voicemeeter Potato

Status of every Voicemeeter Potato feature (from [vb-audio.com/Voicemeeter/potato.htm](https://vb-audio.com/Voicemeeter/potato.htm)).
"New" = added in this fork on top of 0.6.

| Voicemeeter Potato | Hydra |
|---|---|
| 5 hardware + 3 virtual inputs, 5 hardware + 3 virtual outputs | **More**: 16 inputs, 8 A and 8 B outputs (default 8 / 5 / 3), channels can be added, removed, renamed, reordered |
| MME / WDM / KS / WASAPI / ASIO devices | WASAPI (low latency, exclusive, shared), several ASIO drivers at the same time, loopback, per-app capture |
| Virtual audio devices (WDM, KS, MME, WASAPI) | **Missing.** Needs a signed kernel-mode audio driver, see the README. Virtual cables (VB-Cable etc.) work as inputs / outputs |
| Virtual ASIO driver | **Missing** (same reason) |
| 6-band parametric EQ per bus, 3-band graphic EQ on inputs | **More**: 8 bands on every input and bus |
| Color panel (EQ pad) | Not implemented (the 8-band EQ covers it) |
| Compressor, gate | Yes. The gate has a Voice Key (opens only on speech) |
| Denoiser | Yes (RNNoise, four latency modes) |
| Modulation (chorus) | **New**: Modulation section in every input |
| 3D panoramic control | **New**: 3D Pan section (X/Y pad, binaural) |
| Pitch shifter / voice modeler | **New**: Pitch Shifter section. Pitch only, no formant control; about 18 ms latency while on |
| Strip limiter (-40…+12 dB) | **New**: Limiter section in every input |
| Internal FX: reverb and delay, Send / Return / Post | **New**: FX Sends in every input (pre / post fader), FX Return in every bus, Tools → Internal FX |
| External FX loop (ASIO AUX / RETURN) | Not implemented |
| Bus limiter, Sync Delay | Yes (Sync Delay also computes the delay automatically) |
| Mix Down / Stereo Repeat (5.1 / 7.1 buses) | Not applicable: Hydra buses are stereo |
| Internal clock (run without a hardware device) | Not implemented |
| MIDI mapping | Yes, more (LED feedback, motor faders, APC mini presets) |
| Recorder / player | Yes (WAV recording of a B bus, playback of WAV / AIFF / FLAC / Ogg / MP3) |
| Import of Voicemeeter settings | Yes |
| VBAN-TEXT (remote control) | **New**, see below |
| VBAN audio streams in and out | **Not yet.** The packet codec is in `src/net/VbanProtocol.h` (tested), the streams are the next step |
| VBAN-MIDI, VBAN-SERIAL, VBAN-FRAME | Not implemented |
| Macro Buttons | **New**: Tools → Macro Buttons...: 32 buttons (no pages) with Trigger / Push / Toggle modes, an ON and an OFF script in the syntax below, an optional lit state; pressed by mouse, MIDI, shortcut or remote script (`Param[macro.3] = 1`); scripts can press other buttons |
| Remote API (VoicemeeterRemote DLL) | Not implemented (VBAN-TEXT is the way to control Hydra from other programs) |

## Beyond Voicemeeter

- **Scenes that cover only some sections and / or channels** (Scene Editor → right-click a scene → *Covers...*): recalling
  such a scene changes, for example, only the Equalizer and the Gate of input 1 and leaves every fader where it is. A scene
  that names Correction also carries the correction profiles.
- **Copy / paste of a section** between channels (right-click the title of a section), also all sections at once;
  the Correction profile goes with the Correction section.
- **Increase / decrease shortcuts for any fader or knob**, including the **volume keys** of a keyboard (the roller of a
  Logitech G610), global and with a choosable step.

## Remote control (VBAN-TEXT)

Settings → Remote. Off by default, listens on this PC only (127.0.0.1) unless you allow the network, because anyone
who can reach the port can change the mixer. A VBAN-TEXT packet (UDP, default port 6980, sub-protocol 0x40, any stream
name unless you set one) holds a script. Statements end with `;` or a new line, names are not case sensitive,
`[n]` may be written `(n)`. Parameter changes count like MIDI (no undo step).

```
Strip[0].Gain = -6;           input 1 fader to -6 dB (Strip[0..15] = inputs 1..16)
Strip[1].Mute = 1;            Mute, Solo, Mono: 0 / 1
Strip[0].A1 = 1;              routing: A1..A8, B1..B8
Bus[0].Gain -= 3;             relative change; Bus[0..4] = A1..A5, Bus[5..7] = B1..B3 as in Voicemeeter,
                              Bus[8..10] = A6..A8 and Bus[11..15] = B4..B8 (extra Hydra outputs)
Strip[0].Pan_x = 0.25;        -0.5 .. 0.5
Strip[0].Reverb = 4;          FX send knobs 0..10 (-60 .. 0 dB); Strip[n].Delay, PostReverb, PostDelay
Bus[0].ReturnReverb = 10;     FX return knobs 0..10; ReturnDelay
Strip[0].Limit = -12;         -40 .. 12 dB, 12 = off
Strip[0].Denoiser = 5;        knob 0..10
Strip[0].Comp.Threshold = -20; Comp.GainIn, Ratio, Attack, Release, Knee (0..1), GainOut; Gate.Threshold, Damping, ...
Strip[3].Label = "Mic";       rename (Bus[n].Label too)
Scene[2].Recall = 1;          recall scene 2 (scenes are numbered from 1)
Strip[0].pan3d.x = 0.5;       any other Hydra parameter of the channel, by its id without the prefix
Param[in1.pitch.semi] = 3;    any Hydra parameter by its complete id (not case sensitive)
Param[macro.3] = 1;           press Macro Button 3 (Push buttons: 1 = pressed, 0 = released)
Command.Restart = 1;          restart the audio engine; Command.Show = 1 shows the window
```

Parameter ids of the new features: `in<N>.fxs.rev|dly|post` (FX sends), `in<N>.lim.on|thr`, `in<N>.mod.amount|rate|depth`,
`in<N>.pan3d.on|x|y`, `in<N>.pitch.on|semi|mix`, `bus.<A1..B8>.fxr.rev|dly` (FX returns),
`fx.rev.pre|size|decay|damp|width` and `fx.dly.time|taps|step|fb|damp|spread` (the two effects).
All of them are saved with the session, recalled by scenes, undoable and MIDI-learnable like every other parameter.
