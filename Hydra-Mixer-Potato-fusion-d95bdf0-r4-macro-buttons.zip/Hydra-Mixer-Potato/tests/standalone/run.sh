#!/bin/sh
# Runs the tests that need nothing but the standard library (DSP of the internal effects, VBAN codec, remote script
# parser, sections, shortcut steps) with g++ or clang++, without JUCE or Windows. The keyboard shortcuts (midi/Hotkeys.cpp,
# with its Windows hooks) run against small fakes of JUCE and Win32 in tests/standalone/fakes. The full suite is HydraTests (see CMakeLists.txt).
# Common.h here stands in for src/Common.h and only provides the few juce:: helpers the DSP headers touch.
set -e
cd "$(dirname "$0")/../.."
CXX=${CXX:-g++}
$CXX -std=c++20 -O2 -Wall -Wextra -I tests/standalone -I src tests/standalone/fx_main.cpp tests/FxTest.cpp -o /tmp/hydra_fx_test
$CXX -std=c++20 -O2 -Wall -Wextra -I tests/standalone -I src tests/standalone/remote_main.cpp tests/RemoteTest.cpp -o /tmp/hydra_remote_test
$CXX -std=c++20 -O2 -Wall -Wextra -I tests/standalone -I src tests/standalone/sections_main.cpp tests/SectionsTest.cpp -o /tmp/hydra_sections_test
$CXX -std=c++20 -O2 -Wall -Wextra -I tests/standalone -I src tests/standalone/hotkeysteps_main.cpp tests/HotkeyStepsTest.cpp -o /tmp/hydra_hotkeysteps_test
$CXX -std=c++20 -O2 -Wall -Wextra -I tests/standalone -I src tests/standalone/macros_main.cpp tests/MacrosTest.cpp -o /tmp/hydra_macros_test
$CXX -std=c++20 -O0 -Wall -Wextra -I tests/standalone/fakes -I src tests/standalone/hotkeys_fake_test.cpp src/midi/Hotkeys.cpp -o /tmp/hydra_hotkeys_fake_test
/tmp/hydra_fx_test
/tmp/hydra_remote_test
/tmp/hydra_sections_test
/tmp/hydra_hotkeysteps_test
/tmp/hydra_macros_test
/tmp/hydra_hotkeys_fake_test
