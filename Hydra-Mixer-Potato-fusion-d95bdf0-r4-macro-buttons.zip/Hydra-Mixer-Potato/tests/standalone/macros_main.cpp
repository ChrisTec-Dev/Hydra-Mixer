int runMacrosTest();
int main() { return runMacrosTest() == 0 ? 0 : 1; }
