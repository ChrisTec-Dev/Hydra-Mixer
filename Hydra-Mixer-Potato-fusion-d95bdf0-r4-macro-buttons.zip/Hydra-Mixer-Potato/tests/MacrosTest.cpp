// Macro Buttons (core/Macros.h): trigger / push / toggle, the lit state, macros that start macros, limits, names of parameters.
// Standard library only (tests/standalone/run.sh). Scripts are interpreted with the real parser of net/RemoteScript.h.
#include "core/Macros.h"

#include <cstdio>
#include <limits>
#include <map>
#include <string>
#include <vector>

namespace
{
using namespace hydra;

/** A little world of parameters for the machine: the 32 triggers and any other parameter by id. */
struct World
{
    std::array<double, (size_t) macros::kSlots> trigger {};
    std::map<std::string, double> params;
    std::vector<std::string> ran;   // the scripts that were run, in order
    std::vector<int> dropped;
    int consumed = 0;

    macros::Machine::Io io()
    {
        macros::Machine::Io io;
        io.triggerOn = [this] (int k) { return trigger[(size_t) k] >= 0.5; };
        io.consume = [this] (int k) { trigger[(size_t) k] = 0.0; ++consumed; };
        io.readParam = [this] (const std::string& id, double& v)
        {
            const auto it = params.find (id);
            if (it == params.end()) return false;
            v = it->second;
            return true;
        };
        io.run = [this] (const std::string& script)
        {
            ran.push_back (script);
            for (const auto& a : remote::actionsFor (script))
            {
                if (a.kind != remote::Action::Kind::param) continue;
                double* target = nullptr;
                if (a.id.rfind ("macro.", 0) == 0)
                {
                    const int n = std::atoi (a.id.c_str() + 6);
                    if (n >= 1 && n <= macros::kSlots) target = &trigger[(size_t) (n - 1)];
                }
                else target = &params[a.id];
                if (target != nullptr) *target = a.op == '+' ? *target + a.value : a.value;
            }
        };
        io.dropped = [this] (int k) { dropped.push_back (k); };
        return io;
    }
};

macros::Button make (const char* name, macros::Mode mode, const char* on, const char* off = "")
{
    macros::Button b;
    b.used = true;
    b.name = name;
    b.mode = mode;
    b.onScript = on;
    b.offScript = off;
    return b;
}
} // namespace

int runMacrosTest()
{
    int fails = 0;
    auto check = [&] (bool c, const char* what) { std::printf ("%s %s\n", c ? "ok:  " : "FAIL:", what); if (! c) ++fails; };
    using macros::Mode;
    using macros::Machine;

    std::printf ("\n--- Trigger ---\n");
    {
        Machine m;
        World w;
        m.buttons[0] = make ("Mute mic", Mode::trigger, "Strip[0].Mute = 1", "Strip[0].Mute = 0");
        const auto io = w.io();
        m.poll (io);
        check (w.ran.empty(), "nothing happens until the trigger is switched on");
        w.trigger[0] = 1.0;
        m.poll (io);
        check (w.ran.size() == 1 && w.ran[0] == "Strip[0].Mute = 1", "a press runs the ON script");
        check (w.trigger[0] == 0.0, "and switches the trigger off again");
        m.poll (io);
        check (w.ran.size() == 1, "the next poll does not run it again");
        w.trigger[0] = 1.0;
        m.poll (io);
        check (w.ran.size() == 2 && w.ran[1] == "Strip[0].Mute = 1", "a second press runs it again, never the OFF script");
        check (w.params["in1.mute"] == 1.0, "the script reached the parameter through the real parser");
    }

    std::printf("\n--- Push ---\n");
    {
        Machine m;
        World w;
        m.buttons[2] = make ("Talk", Mode::push, "Strip[0].Mute = 0", "Strip[0].Mute = 1");
        const auto io = w.io();
        w.trigger[2] = 1.0;
        m.poll (io);
        check (w.ran.size() == 1 && w.ran[0] == "Strip[0].Mute = 0", "pressing runs the ON script");
        check (w.trigger[2] == 1.0 && w.consumed == 0, "the trigger stays on while the button is held");
        m.poll (io); m.poll (io);
        check (w.ran.size() == 1, "holding it runs nothing more");
        w.trigger[2] = 0.0;
        m.poll (io);
        check (w.ran.size() == 2 && w.ran[1] == "Strip[0].Mute = 1", "releasing runs the OFF script");
        m.poll (io);
        check (w.ran.size() == 2, "once");
    }

    std::printf("\n--- Toggle ---\n");
    {
        Machine m;
        World w;
        m.buttons[1] = make ("Music", Mode::toggle, "Bus[0].Mute = 1", "Bus[0].Mute = 0");
        const auto io = w.io();
        auto press = [&] { w.trigger[1] = 1.0; m.poll (io); };
        press();
        check (w.ran.size() == 1 && w.ran[0] == "Bus[0].Mute = 1" && m.toggleState (1), "the first press runs ON");
        check (w.trigger[1] == 0.0, "and the trigger is switched off again");
        press();
        check (w.ran.size() == 2 && w.ran[1] == "Bus[0].Mute = 0" && ! m.toggleState (1), "the second press runs OFF");
        press();
        check (w.ran.size() == 3 && w.ran[2] == "Bus[0].Mute = 1", "the third runs ON again");

        m.resetSlot (1);
        check (! m.toggleState (1), "resetSlot: the memory starts again");
        press();
        check (w.ran.back() == "Bus[0].Mute = 1", "the next press is an ON");
    }
    {
        // A toggle that follows a parameter: it stays right when the mixer is changed by hand.
        Machine m;
        World w;
        auto b = make ("Mic", Mode::toggle, "Strip[0].Mute = 1", "Strip[0].Mute = 0");
        b.litParam = "in1.mute";
        m.buttons[0] = b;
        const auto io = w.io();
        auto press = [&] { w.trigger[0] = 1.0; m.poll (io); };
        w.params["in1.mute"] = 1.0;   // muted by hand
        press();
        check (w.ran.size() == 1 && w.ran[0] == "Strip[0].Mute = 0", "already lit (muted): the press runs OFF, not ON again");
        check (w.params["in1.mute"] == 0.0, "so the mic is unmuted");
        press();
        check (w.ran.back() == "Strip[0].Mute = 1", "now not lit: the press runs ON");
        w.params["in1.mute"] = 0.0;   // unmuted by hand
        press();
        check (w.ran.back() == "Strip[0].Mute = 1", "the button follows the parameter, not its own memory");

        // The parameter does not exist: the button falls back on its own memory.
        Machine m2;
        World w2;
        auto b2 = make ("Ghost", Mode::toggle, "A", "B");
        b2.litParam = "in9.nothing";
        m2.buttons[0] = b2;
        const auto io2 = w2.io();
        w2.trigger[0] = 1.0; m2.poll (io2);
        w2.trigger[0] = 1.0; m2.poll (io2);
        check (w2.ran.size() == 2 && w2.ran[0] == "A" && w2.ran[1] == "B", "unknown parameter: it alternates on its own");
    }

    std::printf("\n--- Lit ---\n");
    {
        macros::Button trig = make ("T", Mode::trigger, "x"), push = make ("P", Mode::push, "x"), tog = make ("G", Mode::toggle, "x");
        check (! macros::lit (trig, true, true, false, 0.0), "a trigger button is never lit by itself");
        check (macros::lit (push, true, false, false, 0.0) && ! macros::lit (push, false, true, false, 0.0), "a push button: lit while held");
        check (macros::lit (tog, false, true, false, 0.0) && ! macros::lit (tog, true, false, false, 0.0), "a toggle button: lit while on");
        tog.litParam = "in1.gain";
        tog.litAt = -20.0;
        check (macros::lit (tog, false, false, true, -10.0) && ! macros::lit (tog, false, true, true, -30.0), "with a parameter: lit while it is >= the threshold");
        check (macros::lit (tog, false, false, true, -20.0), "the threshold itself counts");
        check (macros::lit (tog, false, true, false, 0.0), "parameter not found: its own state again");
        macros::Button empty;
        check (! macros::lit (empty, true, true, true, 1.0), "an empty slot is never lit");
    }

    std::printf("\n--- Empty slots and empty scripts ---\n");
    {
        Machine m;
        World w;
        const auto io = w.io();
        w.trigger[5] = 1.0;
        m.poll (io);
        check (w.ran.empty() && w.trigger[5] == 0.0, "an empty slot runs nothing, and the stray trigger is switched off");
        m.buttons[6] = make ("Nothing yet", Mode::toggle, "", "");
        w.trigger[6] = 1.0;
        m.poll (io);
        check (w.ran.empty() && w.trigger[6] == 0.0, "a button without script runs nothing and the trigger goes off");
        m.buttons[7] = make ("Half", Mode::toggle, "Strip[1].Mute = 1", "");
        w.trigger[7] = 1.0; m.poll (io);
        w.trigger[7] = 1.0; m.poll (io);
        check (w.ran.size() == 1 && w.params["in2.mute"] == 1.0, "ON without OFF: only the first press does something");
        check (m.toggleState (7) == false, "and the button still alternates");
    }

    std::printf("\n--- Macros that press macros ---\n");
    {
        Machine m;
        World w;
        m.buttons[0] = make ("Start", Mode::trigger, "Param[macro.2] = 1; Param[macro.3] = 1");
        m.buttons[1] = make ("Second", Mode::trigger, "Strip[0].Gain = -6");
        m.buttons[2] = make ("Third", Mode::trigger, "Bus[0].Gain = -3");
        const auto io = w.io();
        w.trigger[0] = 1.0;
        m.poll (io);
        check (w.ran.size() == 3, "one press runs the macro and the two it presses (in the same poll)");
        check (w.params["in1.gain"] == -6.0 && w.params["bus.a1.gain"] == -3.0, "both did their work");
    }
    {
        // Two macros that start each other: a bounded number of runs, then it stops.
        Machine m;
        World w;
        m.buttons[0] = make ("Ping", Mode::trigger, "Param[macro.2] = 1");
        m.buttons[1] = make ("Pong", Mode::trigger, "Param[macro.1] = 1");
        const auto io = w.io();
        w.trigger[0] = 1.0;
        for (int i = 0; i < 100; ++i) m.poll (io);
        check ((int) w.ran.size() == Machine::kMaxChain, "a loop of two macros runs kMaxChain times");
        check (w.dropped.size() == 1, "and the press that went too deep is reported once");
        check (w.trigger[0] == 0.0 && w.trigger[1] == 0.0, "no trigger is left on");

        const auto before = w.ran.size();
        w.trigger[0] = 1.0;
        for (int i = 0; i < 100; ++i) m.poll (io);
        check (w.ran.size() == before + (size_t) Machine::kMaxChain, "a new press by a person starts again from depth 1");
    }
    {
        Machine m;
        World w;
        m.buttons[4] = make ("Itself", Mode::trigger, "Param[macro.5] = 1");
        const auto io = w.io();
        w.trigger[4] = 1.0;
        for (int i = 0; i < 100; ++i) m.poll (io);
        check ((int) w.ran.size() == Machine::kMaxChain && w.trigger[4] == 0.0, "a macro that presses itself is bounded too");
    }
    {
        // A toggle that presses itself: still bounded.
        Machine m;
        World w;
        m.buttons[3] = make ("Flip", Mode::toggle, "Param[macro.4] = 1", "Param[macro.4] = 1");
        const auto io = w.io();
        w.trigger[3] = 1.0;
        for (int i = 0; i < 100; ++i) m.poll (io);
        check ((int) w.ran.size() == Machine::kMaxChain, "a toggle that presses itself is bounded");
    }
    {
        // A push button whose scripts press each other's release: chain depth follows both edges.
        Machine m;
        World w;
        m.buttons[0] = make ("A", Mode::push, "Param[macro.2] = 1", "Param[macro.2] = 0");
        m.buttons[1] = make ("B", Mode::push, "Param[macro.1] = 0", "Param[macro.1] = 1");
        const auto io = w.io();
        w.trigger[0] = 1.0;
        for (int i = 0; i < 200; ++i) m.poll (io);
        check ((int) w.ran.size() <= 2 * Machine::kMaxChain + 2, "push buttons that release and press each other stop too");
    }
    {
        // A script that leaves a trigger as it found it creates no chain.
        Machine m;
        World w;
        m.buttons[0] = make ("Blink", Mode::trigger, "Param[macro.2] = 1; Param[macro.2] = 0");
        m.buttons[1] = make ("Other", Mode::trigger, "Strip[0].Gain = 1");
        const auto io = w.io();
        w.trigger[0] = 1.0;
        m.poll (io);
        check (w.ran.size() == 1, "on and off again within one script does not press the other button");
    }

    std::printf("\n--- Limits and text ---\n");
    {
        std::string s = "abcdef";
        macros::truncateUtf8 (s, 4);
        check (s == "abcd", "truncate: plain text");
        s = "ab\xC3\xA9" "cd";   // ab + e acute (2 bytes) + cd
        macros::truncateUtf8 (s, 3);
        check (s == "ab", "truncate: a two-byte character is not split");
        s = "ab\xC3\xA9" "cd";
        macros::truncateUtf8 (s, 4);
        check (s == "ab\xC3\xA9", "truncate: and kept when it fits");
        s = "\xE2\x82\xAC" "uro";   // euro sign, 3 bytes
        macros::truncateUtf8 (s, 2);
        check (s.empty(), "truncate: a character that does not fit is dropped whole");
        s = "short";
        macros::truncateUtf8 (s, 100);
        check (s == "short", "truncate: short text untouched");

        macros::Button b;
        b.name = std::string (100, 'n');
        b.onScript = std::string (5000, 's');
        b.litParam = std::string (500, 'p');
        b.litAt = std::numeric_limits<double>::quiet_NaN();
        b.colour = 0x00112233;
        macros::sanitise (b);
        check (b.name.size() == macros::kMaxName && b.onScript.size() == macros::kMaxScript && b.litParam.size() == macros::kMaxParamId, "sanitise: lengths");
        check (b.litAt == 0.5 && (b.colour >> 24) == 0xff, "sanitise: NaN threshold, opaque colour");
        b.litAt = 1.0e12;
        macros::sanitise (b);
        check (b.litAt == 1.0e6, "sanitise: a huge threshold is limited");

        std::uint32_t c = 0;
        check (macros::colourText (0xff3d8bd9) == "ff3d8bd9" && macros::colourText (0x0000000a) == "0000000a", "colour text: 8 digits");
        check (macros::parseColour ("ff3d8bd9", c) && c == 0xff3d8bd9 && macros::parseColour ("FF3D8BD9", c) && c == 0xff3d8bd9, "colour parse: both cases");
        check (! macros::parseColour ("3d8bd9", c) && ! macros::parseColour ("zz3d8bd9", c) && ! macros::parseColour ("", c), "colour parse: refuses what is not 8 hex digits");

        Mode md = Mode::push;
        check (macros::modeFromName ("trigger", md) && md == Mode::trigger && macros::modeFromName ("toggle", md) && md == Mode::toggle
               && macros::modeFromName ("push", md) && md == Mode::push && ! macros::modeFromName ("Push", md) && ! macros::modeFromName ("", md), "mode names");
        check (std::string (macros::modeName (Mode::trigger)) == "trigger" && std::string (macros::modeName (Mode::push)) == "push"
               && std::string (macros::modeName (Mode::toggle)) == "toggle", "mode names round trip");

        macros::Button a = make ("x", Mode::push, "s", "t"), a2 = a;
        check (a == a2, "buttons compare");
        a2.litAt = 0.6;
        check (! (a == a2), "and differ");
    }

    std::printf("\n--- Names of parameters ---\n");
    {
        using macros::resolveParamRef;
        check (resolveParamRef ("in1.mute") == "in1.mute", "a Hydra id");
        check (resolveParamRef ("  Bus.A1.Gain ") == "bus.a1.gain", "trimmed and in lower case");
        check (resolveParamRef ("Strip[0].Mute") == "in1.mute", "a Voicemeeter name: Strip[0].Mute");
        check (resolveParamRef ("Bus[1].Gain") == "bus.a2.gain", "Bus[1].Gain");
        check (resolveParamRef ("Strip[2].Comp.Threshold") == "in3.comp.thr", "a name that Hydra spells differently");
        check (resolveParamRef ("Strip[0].A1") == "in1.route.a1", "a routing switch");
        check (resolveParamRef ("Param[in1.pitch.semi]") == "in1.pitch.semi", "Param[...]");
        check (resolveParamRef ("Strip[99].Mute").empty(), "a strip that does not exist");
        check (resolveParamRef ("Scene[1].Recall").empty() && resolveParamRef ("Strip[0].Label").empty(), "a scene recall or a label is not a state a button can follow");
        check (resolveParamRef ("").empty() && resolveParamRef ("   ").empty(), "nothing typed");
        check (resolveParamRef ("in1.mute; Bus[0].Mute").empty() && resolveParamRef ("in1 mute").empty() && resolveParamRef ("a=b").empty(), "no script, no spaces");
    }

    std::printf("\n%s\n", fails == 0 ? "Macros tests passed" : "Macros tests FAILED");
    return fails;
}
