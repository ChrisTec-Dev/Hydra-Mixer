// Macro Buttons in the application (state/Macros): triggers press buttons, scripts reach the parameters, the lit state,
// macros that press macros, persistence in the session file. The logic of the modes is in MacrosTest.cpp.
#include "state/Session.h"
#include <cstdio>

int runMacroBankTest()
{
    juce::ScopedJuceInitialiser_GUI juceInit;
    hydra::ParamPoller poller;
    int fails = 0;
    auto check = [&] (bool c, const char* what) { std::printf ("%s %s\n", c ? "ok:  " : "FAIL:", what); if (! c) ++fails; };
    namespace macros = hydra::macros;

    hydra::Engine engine;
    hydra::MidiMapper midi (engine.params);
    hydra::Session session (engine, midi);
    auto& bank = session.macros;

    // What the application does with a script, for the parameters (the remote control does the same, plus commands and labels).
    std::vector<juce::String> ran;
    auto runner = [&] (const juce::String& script)
    {
        ran.push_back (script);
        for (const auto& a : hydra::remote::actionsFor (script.toStdString()))
            if (a.kind == hydra::remote::Action::Kind::param)
                if (auto* p = bank.findParam (a.id))
                    p->set (a.op == '+' ? p->get() + (float) a.value : (float) a.value, true);
    };
    bank.runScript = runner;
    auto settle = [] (int ms = 150) { juce::MessageManager::getInstance()->runDispatchLoopUntil (ms); };

    // The triggers.
    check (engine.params.find ("macro.1") == engine.macroTrigger[0] && engine.params.find ("macro.32") == engine.macroTrigger[31]
               && engine.params.find ("macro.33") == nullptr,
           "32 trigger parameters: macro.1 to macro.32");
    check (! engine.macroTrigger[0]->persistent && ! hydra::SceneBank::captures (*engine.macroTrigger[0]),
           "triggers are not stored with the parameters and no scene captures them");
    check (bank.countUsed() == 0 && ! bank.isLit (0), "a new session has no buttons");

    // A toggle button.
    macros::Button mic;
    mic.used = true;
    mic.name = "Mute mic";
    mic.mode = macros::Mode::toggle;
    mic.onScript = "Strip[0].Mute = 1";
    mic.offScript = "Strip[0].Mute = 0";
    bank.set (0, mic);
    check (bank.countUsed() == 1 && bank.get (0).name == "Mute mic", "a button is kept in its slot");

    auto& mute = engine.params.get ("in1.mute");
    engine.macroTrigger[0]->set (1.0f, true);
    settle();
    check (mute.isOn() && ! engine.macroTrigger[0]->isOn() && ran.size() == 1, "a press runs the ON script and the trigger is switched off again");
    check (bank.isLit (0), "a toggle button is lit while it is on");
    engine.macroTrigger[0]->set (1.0f, true);
    settle();
    check (! mute.isOn() && ran.size() == 2 && ! bank.isLit (0), "the second press runs the OFF script");

    // A toggle button that follows a parameter, named the Voicemeeter way.
    mic.litParam = "Strip[0].Mute";
    bank.set (0, mic);
    check (bank.get (0).litParam == "in1.mute", "a Voicemeeter name for the lit parameter is reduced to the Hydra id");
    mute.set (1.0f);   // by hand, not by the button
    check (bank.isLit (0), "lit while the parameter is at or above the threshold");
    engine.macroTrigger[0]->set (1.0f, true);
    settle();
    check (! mute.isOn() && ! bank.isLit (0), "pressing a lit toggle button runs OFF, whatever the button remembers");

    macros::Button ghost = mic;
    ghost.litParam = "in99.nothing";
    bank.set (1, ghost);
    check (bank.get (1).litParam.empty(), "a parameter that does not exist is dropped from the button");

    // A push button.
    macros::Button talk;
    talk.used = true;
    talk.mode = macros::Mode::push;
    talk.onScript = "Strip[1].Mute = 1";
    talk.offScript = "Strip[1].Mute = 0";
    bank.set (2, talk);
    auto& mute2 = engine.params.get ("in2.mute");
    engine.macroTrigger[2]->set (1.0f);
    settle();
    check (mute2.isOn() && engine.macroTrigger[2]->isOn() && bank.isLit (2), "push: pressed, the ON script ran, the trigger stays on, the button is lit");
    engine.macroTrigger[2]->set (0.0f);
    settle();
    check (! mute2.isOn() && ! bank.isLit (2), "push: released, the OFF script ran");

    // Without a script runner the triggers wait.
    bank.runScript = nullptr;
    const auto waiting = ran.size();
    mute.set (0.0f);
    engine.macroTrigger[0]->set (1.0f, true);
    settle();
    check (engine.macroTrigger[0]->isOn() && ran.size() == waiting, "without a script runner a press waits");
    bank.runScript = runner;
    settle();
    check (! engine.macroTrigger[0]->isOn() && ran.size() == waiting + 1 && mute.isOn(), "and it runs as soon as there is one");
    mute.set (0.0f);

    // Two macros that press each other stop after a few rounds.
    macros::Button ping, pong;
    ping.used = pong.used = true;
    ping.onScript = "Param[macro.10] = 1";
    pong.onScript = "Param[macro.9] = 1";
    bank.set (8, ping);
    bank.set (9, pong);
    const auto beforeLoop = ran.size();
    engine.macroTrigger[8]->set (1.0f, true);
    settle (600);
    check ((int) (ran.size() - beforeLoop) == macros::Machine::kMaxChain, "macros that press each other run kMaxChain times, then stop");
    check (! engine.macroTrigger[8]->isOn() && ! engine.macroTrigger[9]->isOn(), "and leave no trigger on");

    // Scripts and names that are awkward in a file.
    macros::Button odd;
    odd.used = true;
    odd.name = "Caf\xC3\xA9 \"1\" <&>";
    odd.colour = 0xffff4d5e;
    odd.mode = macros::Mode::push;
    odd.onScript = "Strip[1].Label = \"Mic\";\nBus[0].Gain -= 3";
    odd.offScript = "Scene[2].Recall = 1";
    odd.litParam = "bus.a1.gain";
    odd.litAt = -12.5;
    bank.set (20, odd);
    check (bank.get (20).litParam == "bus.a1.gain", "a bus fader can be the lit parameter");

    const auto first = bank.get (0), second = bank.get (20);
    {
        const auto xml = bank.toXml();
        const auto parsed = juce::XmlDocument::parse (xml->toString());   // through the text, as a file would be
        check (parsed != nullptr, "the MACROS element is well-formed XML");
        bank.clearAll();
        if (parsed != nullptr) bank.fromXml (*parsed);
        check (bank.get (0) == first && bank.get (20) == second && bank.countUsed() == 6,
               "buttons come back as they were: quotes, a new line, accents, a colour, a threshold");
    }

    // The session file.
    auto f = juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("hydra_macros_test.xml");
    f.deleteFile();
    const bool saved = session.save (f);
    const auto fileText = f.loadFileAsString();
    check (saved && fileText.contains ("<MACROS>") && fileText.contains ("<MACRO n=\"21\""), "the session file holds a MACRO element per used slot");
    bank.clearAll();
    check (session.load (f) && bank.get (0) == first && bank.get (20) == second && bank.countUsed() == 6, "a saved session brings the buttons back");

    {   // a session file from before Macro Buttons: no MACROS element, no buttons
        if (auto xml = juce::XmlDocument::parse (f))
        {
            if (auto* element = xml->getChildByName ("MACROS")) xml->removeChildElement (element, true);
            xml->writeTo (f);
        }
        check (session.load (f) && bank.countUsed() == 0, "a session without MACROS loads with no buttons");
    }
    f.deleteFile();

    {   // a damaged file does not hurt
        auto xml = juce::parseXML ("<MACROS>"
                                   "<MACRO n=\"0\" name=\"zero\"/>"
                                   "<MACRO n=\"33\" name=\"too high\"/>"
                                   "<MACRO n=\"4\" name=\"first\" colour=\"nonsense\" mode=\"sideways\" lit=\"in1.mute\" litAt=\"99999999\"/>"
                                   "<MACRO n=\"4\" name=\"duplicate\"/>"
                                   "</MACROS>");
        bank.fromXml (*xml);
        check (bank.countUsed() == 1 && bank.get (3).name == "first", "slots out of range and duplicates are ignored");
        check (bank.get (3).colour == macros::Button().colour && bank.get (3).mode == macros::Mode::trigger,
               "an unreadable colour or mode falls back on the default");
        check (bank.get (3).litAt == 1.0e6 && bank.get (3).litParam == "in1.mute", "a huge threshold is limited");
    }

    bank.clearAll();
    bank.runScript = nullptr;
    std::printf ("\n%s\n", fails == 0 ? "Macro bank tests passed" : "Macro bank tests FAILED");
    return fails;
}
