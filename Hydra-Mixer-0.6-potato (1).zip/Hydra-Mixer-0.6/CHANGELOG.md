# Changes on top of 0.6

Added (Voicemeeter Potato features, see docs/potato-comparison.md):

- Internal **reverb** and **multi-tap delay** with per-input FX sends (pre / post fader) and per-bus FX returns.
- Input strip: **Modulation** (chorus), **Limiter**, **Pitch shifter** (reported in the Latency Finder and used by the
  automatic Sync Delay), **3D pan** (binaural, X/Y pad).
- **Remote control** by VBAN-TEXT scripts in the Voicemeeter syntax (Settings → Remote), plus the VBAN packet codec
  (`src/net/VbanProtocol.h`) for the VBAN audio streams that are still to come.
- Tests: `tests/FxTest.cpp`, `tests/RemoteTest.cpp` (standard library only), `tests/FxEngineTest.cpp`.

Where the code is:

- `src/core/Reverb.h`, `MultiTapDelay.h`, `Chorus.h`, `Binaural.h`, `PitchShifter.h`: the DSP (no JUCE needed).
- `src/engine/Engine.h/.cpp`: parameters, processing (`processStrip`, `processFx`), latency of the pitch shifter.
- `src/ui/Inspector.cpp`: the new sections, the FX settings panel, the XY pad. `src/ui/Settings.cpp`: the Remote tab.
- `src/net/RemoteScript.h` (parser and translation to Hydra parameters), `RemoteControl.h/.cpp` (UDP listener).

Status of the verification: the DSP, the VBAN codec and the script parser are checked by offline tests that were run
with a standard C++ compiler. The integration (engine, inspector, settings, main) was written without access to JUCE or
a Windows compiler, so it has **not been compiled yet**: build it and run HydraTests first.
