#pragma once

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

/** VBAN, the network protocol of VB-Audio (Voicemeeter, VBAN Receptor / Talkie, VBAN-Buttons ...): packets of
    one 28 byte header and a payload, sent as UDP datagrams (default port 6980). This file only packs and
    unpacks packets, it has no sockets, so it can be tested offline. All multi-byte values are little endian.

    Header: "VBAN" | format_SR (sub-protocol in the top 3 bits, sample rate index in the low 5) | samples per
    frame - 1 | channels - 1 | format_bit (data type in the low 3 bits, codec in the top nibble) |
    stream name (16 bytes, zero padded) | frame counter (uint32). */
namespace hydra::vban
{
constexpr int kHeaderSize = 28;
constexpr int kMaxDataSize = 1436;
constexpr int kMaxPacketSize = kHeaderSize + kMaxDataSize;   // 1464, fits one Ethernet frame
constexpr int kMaxSamplesPerFrame = 256;
constexpr int kStreamNameSize = 16;

enum SubProtocol : int { kAudio = 0x00, kSerial = 0x20, kText = 0x40, kService = 0x60 };
enum DataFormat : int { kUint8 = 0, kInt16 = 1, kInt24 = 2, kInt32 = 3, kFloat32 = 4, kFloat64 = 5, kInt12 = 6, kInt10 = 7 };
enum Codec : int { kPcm = 0x00 };                            // audio: 0x00 = PCM. Text: 0x00 ASCII, 0x10 UTF-8

constexpr int kSampleRates[21] = { 6000, 12000, 24000, 48000, 96000, 192000, 384000, 8000, 16000, 32000, 64000,
                                   128000, 256000, 512000, 11025, 22050, 44100, 88200, 176400, 352800, 705600 };

inline int sampleRateFromIndex (int index) noexcept { return index >= 0 && index < 21 ? kSampleRates[index] : 0; }

/** Index of a sample rate in the table above, -1 if VBAN has no such rate. */
inline int indexFromSampleRate (int rate) noexcept
{
    for (int i = 0; i < 21; ++i) if (kSampleRates[i] == rate) return i;
    return -1;
}

/** Bytes of one sample, 0 for the packed 12 / 10 bit formats (not supported). */
inline int bytesPerSample (int format) noexcept
{
    switch (format)
    {
        case kUint8:   return 1;
        case kInt16:   return 2;
        case kInt24:   return 3;
        case kInt32:   return 4;
        case kFloat32: return 4;
        case kFloat64: return 8;
        default:       return 0;
    }
}

struct Header
{
    int subProtocol = kAudio;
    int rateIndex = 3;           // audio: index in kSampleRates; text / serial: bit rate index
    int samplesPerFrame = 1;     // audio: 1..256 (the field holds the value - 1)
    int channels = 1;            // audio: 1..256 (the field holds the value - 1)
    int format = kInt16;         // data type
    int codec = kPcm;
    std::string streamName;      // at most 16 characters
    std::uint32_t frame = 0;     // counts the packets of a stream
};

inline void put32 (std::uint8_t* p, std::uint32_t v) noexcept
{
    p[0] = (std::uint8_t) (v & 0xff); p[1] = (std::uint8_t) ((v >> 8) & 0xff);
    p[2] = (std::uint8_t) ((v >> 16) & 0xff); p[3] = (std::uint8_t) ((v >> 24) & 0xff);
}

inline std::uint32_t get32 (const std::uint8_t* p) noexcept
{
    return (std::uint32_t) p[0] | ((std::uint32_t) p[1] << 8) | ((std::uint32_t) p[2] << 16) | ((std::uint32_t) p[3] << 24);
}

/** Reads the header of a packet. False if it is too short or does not start with "VBAN". */
inline bool parseHeader (const std::uint8_t* data, int size, Header& h)
{
    if (data == nullptr || size < kHeaderSize || get32 (data) != 0x4E414256u)   // 'V' 'B' 'A' 'N'
        return false;
    h.subProtocol = data[4] & 0xE0;
    h.rateIndex = data[4] & 0x1F;
    h.samplesPerFrame = (int) data[5] + 1;
    h.channels = (int) data[6] + 1;
    h.format = data[7] & 0x07;
    h.codec = data[7] & 0xF0;
    int len = 0;
    while (len < kStreamNameSize && data[8 + len] != 0) ++len;
    h.streamName.assign (reinterpret_cast<const char*> (data + 8), (size_t) len);
    h.frame = get32 (data + 24);
    return true;
}

/** Writes the 28 byte header, returns kHeaderSize. */
inline int writeHeader (const Header& h, std::uint8_t* out)
{
    out[0] = 'V'; out[1] = 'B'; out[2] = 'A'; out[3] = 'N';
    out[4] = (std::uint8_t) ((h.subProtocol & 0xE0) | (h.rateIndex & 0x1F));
    out[5] = (std::uint8_t) std::clamp (h.samplesPerFrame - 1, 0, 255);
    out[6] = (std::uint8_t) std::clamp (h.channels - 1, 0, 255);
    out[7] = (std::uint8_t) ((h.format & 0x07) | (h.codec & 0xF0));
    std::memset (out + 8, 0, kStreamNameSize);
    std::memcpy (out + 8, h.streamName.data(), std::min (h.streamName.size(), (size_t) kStreamNameSize));
    put32 (out + 24, h.frame);
    return kHeaderSize;
}

/** Number of samples per channel that fit one packet for this layout (at most 256). */
inline int maxSamplesPerPacket (int channels, int format) noexcept
{
    const int perSample = std::max (1, channels) * bytesPerSample (format);
    return perSample <= 0 ? 0 : std::min (kMaxSamplesPerFrame, kMaxDataSize / perSample);
}

/** Converts interleaved samples of a VBAN payload to float (-1..1). `count` = samples * channels.
    False if the format is not supported or the payload is too short. */
inline bool decodeSamples (const std::uint8_t* src, int size, int format, int count, float* dst) noexcept
{
    const int bps = bytesPerSample (format);
    if (bps == 0 || count < 0 || size < count * bps) return false;
    switch (format)
    {
        case kUint8:
            for (int i = 0; i < count; ++i) dst[i] = ((float) src[i] - 128.0f) * (1.0f / 128.0f);
            break;
        case kInt16:
            for (int i = 0; i < count; ++i)
                dst[i] = (float) (std::int16_t) ((std::uint16_t) src[2 * i] | ((std::uint16_t) src[2 * i + 1] << 8)) * (1.0f / 32768.0f);
            break;
        case kInt24:
            for (int i = 0; i < count; ++i)
            {
                std::int32_t v = (std::int32_t) ((std::uint32_t) src[3 * i] | ((std::uint32_t) src[3 * i + 1] << 8) | ((std::uint32_t) src[3 * i + 2] << 16));
                if (v & 0x800000) v -= 0x1000000;
                dst[i] = (float) v * (1.0f / 8388608.0f);
            }
            break;
        case kInt32:
            for (int i = 0; i < count; ++i)
                dst[i] = (float) ((double) (std::int32_t) get32 (src + 4 * i) * (1.0 / 2147483648.0));
            break;
        case kFloat32:
            for (int i = 0; i < count; ++i) { float v; std::memcpy (&v, src + 4 * i, 4); dst[i] = std::isfinite (v) ? v : 0.0f; }
            break;
        case kFloat64:
            for (int i = 0; i < count; ++i) { double v; std::memcpy (&v, src + 8 * i, 8); dst[i] = std::isfinite (v) ? (float) v : 0.0f; }
            break;
        default:
            return false;
    }
    return true;
}

/** Converts float samples to the payload format (clipped to full scale). Returns the bytes written, 0 if the
    format is not supported. */
inline int encodeSamples (const float* src, int count, int format, std::uint8_t* dst) noexcept
{
    const int bps = bytesPerSample (format);
    if (bps == 0) return 0;
    for (int i = 0; i < count; ++i)
    {
        const float v = std::clamp (src[i], -1.0f, 1.0f);
        switch (format)
        {
            case kUint8:   dst[i] = (std::uint8_t) std::lrint (v * 127.0f + 128.0f); break;
            case kInt16:
            {
                const auto s = (std::uint16_t) (std::int16_t) std::lrint (v * 32767.0f);
                dst[2 * i] = (std::uint8_t) (s & 0xff); dst[2 * i + 1] = (std::uint8_t) (s >> 8);
                break;
            }
            case kInt24:
            {
                const auto s = (std::uint32_t) (std::int32_t) std::lrint (v * 8388607.0f);
                dst[3 * i] = (std::uint8_t) (s & 0xff); dst[3 * i + 1] = (std::uint8_t) ((s >> 8) & 0xff); dst[3 * i + 2] = (std::uint8_t) ((s >> 16) & 0xff);
                break;
            }
            case kInt32:   put32 (dst + 4 * i, (std::uint32_t) (std::int32_t) std::llround ((double) v * 2147483647.0)); break;
            case kFloat32: std::memcpy (dst + 4 * i, &v, 4); break;
            case kFloat64: { const double d = v; std::memcpy (dst + 8 * i, &d, 8); break; }
            default: return 0;
        }
    }
    return count * bps;
}

/** A complete audio packet: header + `samples` frames of interleaved float audio. Returns the packet size,
    0 if the layout does not fit one packet or the format is not supported. */
inline int buildAudioPacket (Header h, const float* interleaved, int samples, std::uint8_t* out)
{
    if (samples < 1 || samples > maxSamplesPerPacket (h.channels, h.format)) return 0;
    h.subProtocol = kAudio;
    h.codec = kPcm;
    h.samplesPerFrame = samples;
    writeHeader (h, out);
    const int bytes = encodeSamples (interleaved, samples * h.channels, h.format, out + kHeaderSize);
    return bytes > 0 ? kHeaderSize + bytes : 0;
}

/** Text of a VBAN-TEXT packet (ASCII or UTF-8; trailing zero bytes are dropped). */
inline std::string decodeText (const std::uint8_t* data, int size)
{
    if (size <= kHeaderSize) return {};
    std::string s (reinterpret_cast<const char*> (data + kHeaderSize), (size_t) (size - kHeaderSize));
    while (! s.empty() && s.back() == '\0') s.pop_back();
    return s;
}

/** A VBAN-TEXT packet (UTF-8, 256000 baud index as VB-Audio's own tools send). Returns the packet size, 0 if the
    text does not fit one packet. */
inline int buildTextPacket (const std::string& streamName, std::uint32_t frame, const std::string& text, std::uint8_t* out)
{
    if ((int) text.size() > kMaxDataSize) return 0;
    Header h;
    h.subProtocol = kText;
    h.rateIndex = 0;
    h.samplesPerFrame = 1;
    h.channels = 1;
    h.format = kUint8;
    h.codec = 0x10;   // UTF-8
    h.streamName = streamName;
    h.frame = frame;
    writeHeader (h, out);
    std::memcpy (out + kHeaderSize, text.data(), text.size());
    return kHeaderSize + (int) text.size();
}
} // namespace hydra::vban
