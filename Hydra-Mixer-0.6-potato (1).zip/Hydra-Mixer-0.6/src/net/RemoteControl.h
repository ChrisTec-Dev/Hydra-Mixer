#pragma once
#include "engine/Engine.h"
#include "net/RemoteScript.h"
#include "net/VbanProtocol.h"

namespace hydra
{
/** Remote control over the network, like Voicemeeter's VBAN-TEXT: UDP packets (default port 6980) carry a script in
    the Voicemeeter syntax (see net/RemoteScript.h, e.g. "Strip[0].Gain = -6; Bus[0].Mute = 1;") that sets Hydra
    parameters. Works with VBAN-Buttons, Stream Deck / Companion VBAN-TEXT plugins and any program that can send
    a VBAN-TEXT packet.

    Off by default. It listens on this PC only (127.0.0.1) unless the network is allowed, because anyone who can
    reach the port can change the mixer. Parameter changes count like MIDI (no undo step). Everything is applied on
    the message thread. */
class RemoteControl final : private juce::Thread
{
public:
    struct Settings
    {
        bool enabled = false;
        int port = 6980;
        bool allowNetwork = false;   // false: 127.0.0.1 only; true: every network interface
        juce::String streamName;     // empty: any stream name is accepted
        bool operator== (const Settings&) const = default;
    };

    explicit RemoteControl (Engine&);
    ~RemoteControl() override;

    /** Starts, restarts or stops the listener to match the settings. Returns {} or an error message.
        Message thread. */
    juce::String apply (const Settings&);

    /** For the settings page: "Off", "Listening on 127.0.0.1:6980 - 12 scripts received", "Cannot listen: ...". */
    juce::String getStatus() const;

    /** Runs a script as if it had arrived in a packet. Returns the number of parameters changed. Message thread. */
    int runScript (const juce::String& script);

    /** Commands that need the application ("restart", "show"); called on the message thread. */
    std::function<void (const juce::String& name, double value)> onCommand;

private:
    void run() override;
    int execute (const std::vector<remote::Action>& actions);
    Param* findParam (const std::string& lowerId) const;

    Engine& engine;
    std::unordered_map<std::string, Param*> byLowerId;
    std::unique_ptr<juce::DatagramSocket> socket;
    Settings active;
    juce::String error;
    juce::String streamFilter;
    std::atomic<int> received { 0 }, pending { 0 };

    JUCE_DECLARE_WEAK_REFERENCEABLE (RemoteControl)
};
} // namespace hydra
