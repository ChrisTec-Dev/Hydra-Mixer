#pragma once

#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <string>
#include <vector>

/** Remote control scripts in the syntax of Voicemeeter (VBAN-TEXT, Macro Buttons, the Remote API):

        Strip[0].Gain = -6; Strip[1].Mute = 1; Bus[2].Gain=0;
        Strip[0].A1 = 1; Strip[3].Label = "Mic"; Command.Restart = 1;

    Statements end with ';' or a new line, names are not case sensitive, [n] may also be written (n), "+=" and
    "-=" change a value relative to its current one. Apart from the Voicemeeter names the scripts also reach
    everything Hydra has: Strip[n].<parameter> and Bus[n].<parameter> take any Hydra parameter id without its
    channel prefix (Strip[0].pan3d.x = 0.5), Param[in1.pitch.semi] = 3 takes the complete id, and
    Scene[2].Recall = 1 recalls scene 2 (scenes are numbered from 1, as in the app).

    Channel numbers are 0 based like in Voicemeeter Potato: Strip[0..15] are the inputs, Bus[0..4] = A1..A5,
    Bus[5..7] = B1..B3 as in Voicemeeter, Bus[8..10] = A6..A8, Bus[11..15] = B4..B8 for the extra Hydra outputs.

    This file only parses and translates (no JUCE, no Engine), so it is tested offline. */
namespace hydra::remote
{
struct Statement
{
    std::string target;        // lower case: "strip", "bus", "command", "scene", "param"
    int index = -1;            // Strip[3] -> 3, Scene[2] -> 2, -1 if there is no [n]
    std::string key;           // Param[in1.gain] -> "in1.gain"
    std::string property;      // lower case, no spaces: "gain", "comp.threshold", "recall"
    char op = '=';             // '=' set, '+' add (+=), '-' subtract (-=)
    bool isText = false;       // the value is a quoted string
    double number = 0.0;
    std::string text;
};

struct Action
{
    enum class Kind { param, label, command } kind = Kind::param;
    std::string id;            // param: parameter id (lower case); command: its name (lower case)
    double value = 0.0;        // param: the Hydra value to set, or the amount to add when op is '+'
    char op = '=';             // '=' or '+' (a subtraction is a negative amount)
    std::string text;          // label: the new name
    bool isInput = true;       // label: input strip (index) or bus (busCode)
    int index = 0;
    std::string busCode;       // label of a bus: "A1" ...
};

namespace detail
{
inline std::string trim (const std::string& s)
{
    size_t a = 0, b = s.size();
    while (a < b && std::isspace ((unsigned char) s[a])) ++a;
    while (b > a && std::isspace ((unsigned char) s[b - 1])) --b;
    return s.substr (a, b - a);
}

inline std::string lower (std::string s)
{
    for (auto& c : s) c = (char) std::tolower ((unsigned char) c);
    return s;
}

inline std::vector<std::string> splitStatements (const std::string& s)
{
    std::vector<std::string> out;
    std::string cur;
    bool quote = false;
    for (const char c : s)
    {
        if (c == '"') quote = ! quote;
        if (! quote && (c == ';' || c == '\n' || c == '\r')) { out.push_back (cur); cur.clear(); }
        else cur += c;
    }
    out.push_back (cur);
    return out;
}

inline bool parseOne (const std::string& raw, Statement& st)
{
    const std::string s = trim (raw);
    if (s.empty()) return false;

    // The first '=' outside quotes and brackets.
    size_t eq = std::string::npos;
    bool quote = false;
    int depth = 0;
    for (size_t i = 0; i < s.size(); ++i)
    {
        const char c = s[i];
        if (c == '"') quote = ! quote;
        else if (! quote)
        {
            if (c == '[' || c == '(') ++depth;
            else if (c == ']' || c == ')') --depth;
            else if (c == '=' && depth == 0) { eq = i; break; }
        }
    }
    if (eq == std::string::npos) return false;

    std::string lhs = s.substr (0, eq);
    const std::string rhs = trim (s.substr (eq + 1));
    st = Statement();
    if (! lhs.empty() && (lhs.back() == '+' || lhs.back() == '-')) { st.op = lhs.back(); lhs.pop_back(); }
    lhs = trim (lhs);

    size_t i = 0;
    while (i < lhs.size() && (std::isalpha ((unsigned char) lhs[i]) || lhs[i] == '_')) st.target += (char) std::tolower ((unsigned char) lhs[i++]);
    if (st.target.empty()) return false;

    if (i < lhs.size() && (lhs[i] == '[' || lhs[i] == '('))
    {
        const char close = lhs[i] == '[' ? ']' : ')';
        const size_t end = lhs.find (close, i + 1);
        if (end == std::string::npos) return false;
        std::string inner = trim (lhs.substr (i + 1, end - i - 1));
        if (st.target == "param")
        {
            if (inner.size() >= 2 && inner.front() == '"' && inner.back() == '"') inner = inner.substr (1, inner.size() - 2);
            st.key = lower (inner);
        }
        else
        {
            if (inner.empty()) return false;
            for (const char c : inner) if (! std::isdigit ((unsigned char) c)) return false;
            if (inner.size() > 4) return false;
            st.index = std::atoi (inner.c_str());
        }
        i = end + 1;
    }
    if (i < lhs.size())
    {
        if (lhs[i] != '.') return false;
        for (size_t k = i + 1; k < lhs.size(); ++k)
            if (! std::isspace ((unsigned char) lhs[k])) st.property += (char) std::tolower ((unsigned char) lhs[k]);
    }
    if (st.target == "param" ? st.key.empty() : st.property.empty()) return false;

    if (rhs.empty()) return false;
    if (rhs.front() == '"')
    {
        const size_t end = rhs.rfind ('"');
        if (end == 0) return false;
        st.isText = true;
        st.text = rhs.substr (1, end - 1);
    }
    else
    {
        const std::string low = lower (rhs);
        if (low == "true" || low == "on")        st.number = 1.0;
        else if (low == "false" || low == "off") st.number = 0.0;
        else
        {
            char* endp = nullptr;
            st.number = std::strtod (rhs.c_str(), &endp);
            if (endp == rhs.c_str() || ! trim (std::string (endp)).empty()) return false;
        }
    }
    return true;
}

/** Hydra bus code for a channel number of the scripts, "" if out of range (see the file comment). */
inline std::string busCodeForIndex (int i)
{
    if (i >= 0 && i <= 4)   return "A" + std::to_string (i + 1);
    if (i >= 5 && i <= 7)   return "B" + std::to_string (i - 4);
    if (i >= 8 && i <= 10)  return "A" + std::to_string (i - 2);
    if (i >= 11 && i <= 15) return "B" + std::to_string (i - 7);
    return {};
}

struct Mapping { const char* property; const char* suffix; double scale; double offset; };

// Voicemeeter name -> Hydra parameter (value = voicemeeter * scale + offset).
inline const Mapping* stripMappings (int& n)
{
    static const Mapping m[] = {
        { "gain", "gain", 1, 0 }, { "mute", "mute", 1, 0 }, { "solo", "solo", 1, 0 }, { "mono", "mono", 1, 0 },
        { "pan_x", "pan", 2, 0 },                                   // -0.5 .. 0.5 -> -1 .. 1
        { "eq.on", "eq.on", 1, 0 },
        { "comp.gainin", "comp.input", 1, 0 }, { "comp.threshold", "comp.thr", 1, 0 }, { "comp.ratio", "comp.ratio", 1, 0 },
        { "comp.attack", "comp.attack", 1, 0 }, { "comp.release", "comp.release", 1, 0 }, { "comp.knee", "comp.knee", 12, 0 },
        { "comp.gainout", "comp.makeup", 1, 0 },
        { "gate.threshold", "gate.thr", 1, 0 }, { "gate.damping", "gate.range", 1, 0 }, { "gate.attack", "gate.attack", 1, 0 },
        { "gate.hold", "gate.hold", 1, 0 }, { "gate.release", "gate.release", 1, 0 },
        { "reverb", "fxs.rev", 6, -60 }, { "delay", "fxs.dly", 6, -60 },   // knob 0..10 -> -60 .. 0 dB
        { "postreverb", "fxs.post", 1, 0 }, { "postdelay", "fxs.post", 1, 0 },
    };
    n = (int) (sizeof (m) / sizeof (m[0]));
    return m;
}

inline const Mapping* busMappings (int& n)
{
    static const Mapping m[] = {
        { "gain", "gain", 1, 0 }, { "mute", "mute", 1, 0 }, { "mono", "mono", 1, 0 }, { "eq.on", "eq.on", 1, 0 },
        { "returnreverb", "fxr.rev", 6, -60 }, { "returndelay", "fxr.dly", 6, -60 },
    };
    n = (int) (sizeof (m) / sizeof (m[0]));
    return m;
}

inline void addParam (std::vector<Action>& out, const std::string& id, double value, char op)
{
    Action a;
    a.kind = Action::Kind::param;
    a.id = lower (id);
    a.value = value;
    a.op = op == '=' ? '=' : '+';
    out.push_back (a);
}
} // namespace detail

/** Parses a script. Statements that are not understood are skipped. */
inline std::vector<Statement> parse (const std::string& script)
{
    std::vector<Statement> out;
    for (const auto& piece : detail::splitStatements (script))
    {
        Statement st;
        if (detail::parseOne (piece, st)) out.push_back (st);
    }
    return out;
}

/** What a statement does in Hydra: parameters to set, a label to rename, a command to run. Empty if it means
    nothing here (unknown channel, unknown command ...); whether a parameter id exists is checked when it is applied. */
inline std::vector<Action> translate (const Statement& st)
{
    using namespace detail;
    std::vector<Action> out;
    const double amount = st.op == '-' ? -st.number : st.number;

    if (st.target == "param")
    {
        if (! st.isText) addParam (out, st.key, amount, st.op);
        return out;
    }
    if (st.target == "scene")
    {
        // Scenes are numbered like in the app (Scene 1 ...), unlike strips and buses.
        if (st.property == "recall" && st.index >= 1 && st.index < 100 && st.number != 0.0)
            addParam (out, "scene." + std::to_string (st.index), 1.0, '=');
        return out;
    }
    if (st.target == "command")
    {
        Action a;
        a.kind = Action::Kind::command;
        a.id = st.property;
        a.value = st.number;
        a.text = st.text;
        out.push_back (a);
        return out;
    }
    if (st.target != "strip" && st.target != "bus") return out;

    const bool isStrip = st.target == "strip";
    std::string prefix;
    std::string code;
    if (isStrip)
    {
        if (st.index < 0 || st.index >= 16) return out;
        prefix = "in" + std::to_string (st.index + 1) + ".";
    }
    else
    {
        code = busCodeForIndex (st.index);
        if (code.empty()) return out;
        prefix = "bus." + code + ".";
    }

    if (st.property == "label")
    {
        if (! st.isText) return out;
        Action a;
        a.kind = Action::Kind::label;
        a.text = st.text;
        a.isInput = isStrip;
        a.index = st.index;
        a.busCode = code;
        out.push_back (a);
        return out;
    }
    if (st.isText) return out;   // everything below takes a number

    if (isStrip)
    {
        // Voicemeeter's knobs that Hydra splits into several parameters.
        if (st.property == "denoiser")   // 0..10
        {
            addParam (out, prefix + "dn.on", st.number > 0.0 ? 1.0 : 0.0, '=');
            addParam (out, prefix + "dn.amount", std::clamp (st.number * 10.0, 0.0, 100.0), '=');
            return out;
        }
        if (st.property == "limit")      // -40..12 dB, 12 = off
        {
            addParam (out, prefix + "lim.on", st.number < 11.95 ? 1.0 : 0.0, '=');
            addParam (out, prefix + "lim.thr", std::clamp (st.number, -40.0, 12.0), '=');
            return out;
        }
        if (st.property.size() == 2 && (st.property[0] == 'a' || st.property[0] == 'b') && st.property[1] >= '1' && st.property[1] <= '8')
        {
            std::string c (1, (char) std::toupper ((unsigned char) st.property[0]));
            c += st.property[1];
            addParam (out, prefix + "route." + c, st.number, '=');
            return out;
        }
    }

    int n = 0;
    const Mapping* table = isStrip ? stripMappings (n) : busMappings (n);
    for (int i = 0; i < n; ++i)
        if (st.property == table[i].property)
        {
            if (st.op == '=') addParam (out, prefix + table[i].suffix, st.number * table[i].scale + table[i].offset, '=');
            else              addParam (out, prefix + table[i].suffix, amount * table[i].scale, '+');
            return out;
        }

    // Not a Voicemeeter name: any Hydra parameter of this channel, by the id without the channel prefix.
    addParam (out, prefix + st.property, st.op == '=' ? st.number : amount, st.op);
    return out;
}

/** parse() + translate() of a whole script. */
inline std::vector<Action> actionsFor (const std::string& script)
{
    std::vector<Action> out;
    for (const auto& st : parse (script))
        for (auto& a : translate (st)) out.push_back (std::move (a));
    return out;
}
} // namespace hydra::remote
