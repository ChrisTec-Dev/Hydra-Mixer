#include "net/RemoteControl.h"

namespace hydra
{
RemoteControl::RemoteControl (Engine& e) : juce::Thread ("Hydra remote control"), engine (e)
{
    for (auto& p : engine.params.all())
        byLowerId[p->id.toLowerCase().toStdString()] = p.get();
}

RemoteControl::~RemoteControl()
{
    apply ({});   // stops the thread
}

juce::String RemoteControl::apply (const Settings& s)
{
    if (isThreadRunning())
    {
        signalThreadShouldExit();
        if (socket != nullptr) socket->shutdown();   // wakes up a read in progress
        stopThread (2000);
    }
    socket.reset();
    error = {};
    active = s;
    received = 0;
    pending = 0;
    if (! s.enabled) return {};

    socket = std::make_unique<juce::DatagramSocket> (false);
    if (! socket->bindToPort (juce::jlimit (1, 65535, s.port), s.allowNetwork ? juce::String() : juce::String ("127.0.0.1")))
    {
        error = "port " + juce::String (s.port) + " is not available (another program may use it)";
        socket.reset();
        return error;
    }
    streamFilter = s.streamName.trim();
    startThread (juce::Thread::Priority::normal);
    return {};
}

juce::String RemoteControl::getStatus() const
{
    if (error.isNotEmpty()) return "Cannot listen: " + error;
    if (! active.enabled) return "Off";
    return "Listening on " + (active.allowNetwork ? juce::String ("all network interfaces") : juce::String ("127.0.0.1 (this PC only)"))
           + ", port " + juce::String (active.port) + "  -  " + juce::String (received.load()) + " scripts received";
}

Param* RemoteControl::findParam (const std::string& lowerId) const
{
    const auto it = byLowerId.find (lowerId);
    return it != byLowerId.end() ? it->second : nullptr;
}

int RemoteControl::runScript (const juce::String& script)
{
    return execute (remote::actionsFor (script.toStdString()));
}

int RemoteControl::execute (const std::vector<remote::Action>& actions)
{
    int changed = 0;
    for (const auto& a : actions)
    {
        switch (a.kind)
        {
            case remote::Action::Kind::param:
                if (auto* p = findParam (a.id))
                {
                    const float v = a.op == '+' ? p->get() + (float) a.value : (float) a.value;
                    p->set (v, true);   // like MIDI: no undo step
                    ++changed;
                }
                break;

            case remote::Action::Kind::label:
            {
                const auto name = juce::String::fromUTF8 (a.text.c_str()).substring (0, 24);
                if (a.isInput)
                {
                    if (juce::isPositiveAndBelow (a.index, kMaxInputs) && engine.isInputActive (a.index))
                    {
                        engine.inputs[(size_t) a.index].name = name;
                        engine.sendChangeMessage();
                        ++changed;
                    }
                }
                else
                {
                    for (int b = 0; b < kMaxBuses; ++b)
                        if (busCode (b).equalsIgnoreCase (juce::String (a.busCode)) && engine.isBusActive (b))
                        {
                            engine.buses[(size_t) b].name = name;
                            engine.sendChangeMessage();
                            ++changed;
                        }
                }
                break;
            }

            case remote::Action::Kind::command:
                if (onCommand) onCommand (juce::String (a.id), a.value);
                ++changed;
                break;
        }
    }
    return changed;
}

void RemoteControl::run()
{
    std::uint8_t buffer[2048];
    while (! threadShouldExit())
    {
        if (socket == nullptr) break;
        const int ready = socket->waitUntilReady (true, 200);
        if (ready < 0) break;
        if (ready == 0) continue;

        juce::String senderIp;
        int senderPort = 0;
        const int n = socket->read (buffer, (int) sizeof (buffer), false, senderIp, senderPort);
        if (n <= 0) continue;

        vban::Header h;
        if (! vban::parseHeader (buffer, n, h) || h.subProtocol != vban::kText) continue;
        if (streamFilter.isNotEmpty() && ! juce::String (h.streamName).equalsIgnoreCase (streamFilter)) continue;

        auto actions = remote::actionsFor (vban::decodeText (buffer, n));
        if (actions.empty()) continue;
        ++received;
        if (pending.load() > 64) continue;   // a flood of packets must not pile up work on the message thread
        ++pending;
        juce::MessageManager::callAsync ([weak = juce::WeakReference<RemoteControl> (this), actions = std::move (actions)]
        {
            if (auto* self = weak.get())
            {
                --self->pending;
                self->execute (actions);
            }
        });
    }
}
} // namespace hydra
