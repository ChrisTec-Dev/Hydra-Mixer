#pragma once
#include "Reverb.h"

namespace hydra::dsp
{
struct DelaySettings
{
    float timeMs = 300.0f;      // 20..1000: time of the first tap
    int taps = 3;               // 1..4: tap k comes k * timeMs after the input
    float stepDb = -4.0f;       // -12..0: level change from one tap to the next
    float feedback = 0.3f;      // 0..0.9: the last tap is fed back into the line (repeats)
    float dampingHz = 5000.0f;  // 500..20000: tone of the repeats (low-pass in the feedback path)
    float spread = 1.0f;        // 0..1: taps alternate left / right (1 = ping-pong, 0 = centred)
};

/** Stereo multi-tap delay, wet only. The input is summed to mono, up to four equally spaced taps are read
    from one line and panned alternately left / right. Changing the time glides (like a tape delay), so there
    are no clicks. Feedback uses the unscaled last tap, so the loop gain is the feedback value itself (< 1). */
class MultiTapDelay
{
public:
    static constexpr int kMaxTaps = 4;
    static constexpr float kMaxTimeMs = 1000.0f, kMinTimeMs = 20.0f, kMaxFeedback = 0.9f;

    void prepare (double sampleRate)
    {
        sr = sampleRate;
        const int size = fxdetail::powerOfTwoAtLeast ((int) std::ceil (sr * kMaxTimeMs * kMaxTaps / 1000.0) + 8);
        buf.assign ((size_t) size, 0.0f);
        mask = size - 1;
        timeCoef = (float) (1.0 - std::exp (-1.0 / (0.08 * sr)));
        timeNow = 0.0f;
        reset();
    }

    void reset() noexcept
    {
        std::fill (buf.begin(), buf.end(), 0.0f);
        write = 0;
        lp = 0.0f;
    }

    bool isPrepared() const noexcept { return ! buf.empty(); }

    void process (const float* inL, const float* inR, float* outL, float* outR, int n, const DelaySettings& s) noexcept
    {
        if (! isPrepared())
        {
            std::fill (outL, outL + n, 0.0f);
            std::fill (outR, outR + n, 0.0f);
            return;
        }

        const float timeTarget = std::clamp (s.timeMs, kMinTimeMs, kMaxTimeMs) * (float) (sr / 1000.0);
        if (timeNow <= 0.0f) timeNow = timeTarget;   // first block: no glide from zero
        const int taps = std::clamp (s.taps, 1, kMaxTaps);
        const float fb = std::clamp (s.feedback, 0.0f, kMaxFeedback);
        const float damp = fxdetail::onePoleCoef (std::clamp (s.dampingHz, 500.0f, 20000.0f), sr);
        const float spread = std::clamp (s.spread, 0.0f, 1.0f);

        float level[kMaxTaps], gl[kMaxTaps], gr[kMaxTaps];
        for (int k = 0; k < kMaxTaps; ++k)
        {
            level[k] = std::pow (10.0f, std::clamp (s.stepDb, -12.0f, 0.0f) * (float) k / 20.0f);
            const float pan = ((k & 1) ? 1.0f : -1.0f) * spread;   // first tap left, second right ...
            gl[k] = std::sqrt (0.5f * (1.0f - pan));
            gr[k] = std::sqrt (0.5f * (1.0f + pan));
        }

        for (int i = 0; i < n; ++i)
        {
            timeNow += (timeTarget - timeNow) * timeCoef;
            float l = 0.0f, r = 0.0f, last = 0.0f;
            for (int k = 0; k < taps; ++k)
            {
                const float v = fxdetail::readFrac (buf.data(), mask, write, timeNow * (float) (k + 1));
                l += v * level[k] * gl[k];
                r += v * level[k] * gr[k];
                last = v;
            }
            lp = (1.0f - damp) * last + damp * lp;
            const float in = 0.5f * (inL[i] + inR[i]);
            const float v = in + fb * lp;
            buf[(size_t) write] = std::abs (v) < 1.0e-20f ? 0.0f : v;
            write = (write + 1) & mask;
            outL[i] = l;
            outR[i] = r;
        }
    }

private:
    double sr = 48000.0;
    std::vector<float> buf;
    int mask = 0, write = 0;
    float lp = 0.0f, timeNow = 0.0f, timeCoef = 0.0003f;
};
} // namespace hydra::dsp
