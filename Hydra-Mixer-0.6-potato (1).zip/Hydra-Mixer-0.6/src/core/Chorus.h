#pragma once
#include "Reverb.h"

namespace hydra::dsp
{
struct ChorusSettings
{
    float amount = 0.0f;   // 0..1 (0 = off, nothing is processed)
    float rateHz = 0.8f;   // 0.1..5
    float depthMs = 3.0f;  // 0.5..8
};

/** "Modulation" of Voicemeeter Potato: a stereo chorus. Two modulated delay voices per side (opposite LFO
    phases, the right side a quarter turn ahead of the left) are mixed with the dry signal. In place, no latency
    for the dry path. While amount is 0 it costs nothing; the delay lines are cleared so it fades in from silence. */
class Chorus
{
public:
    static constexpr float kCentreMs = 14.0f, kMaxDepthMs = 8.0f;

    void prepare (double sampleRate)
    {
        sr = sampleRate;
        const int size = fxdetail::powerOfTwoAtLeast ((int) std::ceil (sr * 0.04) + 8);
        for (auto& b : buf) b.assign ((size_t) size, 0.0f);
        mask = size - 1;
        write = 0;
        phase = 0.0;
        lastAmount = 0.0f;
        idle = true;
    }

    void reset() noexcept
    {
        for (auto& b : buf) std::fill (b.begin(), b.end(), 0.0f);
        write = 0;
        lastAmount = 0.0f;
        idle = true;
    }

    void process (float* l, float* r, int n, const ChorusSettings& s) noexcept
    {
        if (buf[0].empty()) return;
        const float amount = std::clamp (s.amount, 0.0f, 1.0f);
        if (amount <= 0.0f && lastAmount <= 0.0f)
        {
            if (! idle) { reset(); }
            return;
        }
        idle = false;

        const double inc = std::clamp ((double) s.rateHz, 0.1, 5.0) / sr;
        const float depth = std::clamp (s.depthMs, 0.5f, kMaxDepthMs) * (float) (sr / 1000.0);
        const float centre = kCentreMs * (float) (sr / 1000.0);
        const float step = (amount - lastAmount) / (float) std::max (1, n);
        float a = lastAmount;
        float* ch[2] = { l, r };

        for (int i = 0; i < n; ++i)
        {
            buf[0][(size_t) write] = l[i];
            buf[1][(size_t) write] = r[i];
            a += step;
            const float dry = 1.0f - 0.5f * a, wet = 0.75f * a;
            for (int c = 0; c < 2; ++c)
            {
                const double p = phase + 0.25 * (double) c;
                const float s0 = (float) std::sin (6.283185307179586 * p);
                const float s1 = -s0;   // the second voice runs in opposite phase
                const float v0 = fxdetail::readFrac (buf[(size_t) c].data(), mask, write, centre + depth * s0);
                const float v1 = fxdetail::readFrac (buf[(size_t) c].data(), mask, write, centre + depth * s1);
                ch[c][i] = ch[c][i] * dry + 0.5f * (v0 + v1) * wet;
            }
            phase += inc;
            if (phase >= 1.0) phase -= 1.0;
            write = (write + 1) & mask;
        }
        lastAmount = amount;
    }

private:
    double sr = 48000.0, phase = 0.0;
    std::array<std::vector<float>, 2> buf;
    int mask = 0, write = 0;
    float lastAmount = 0.0f;
    bool idle = true;
};
} // namespace hydra::dsp
