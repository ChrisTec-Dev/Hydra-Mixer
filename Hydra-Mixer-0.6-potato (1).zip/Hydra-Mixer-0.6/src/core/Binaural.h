#pragma once
#include "Reverb.h"

namespace hydra::dsp
{
struct Pan3dSettings
{
    float x = 0.0f;   // -1 (left) .. +1 (right)
    float y = 0.0f;   // -1 (behind) .. +1 (in front)
};

/** "3D Panoramic" of Voicemeeter Potato: places a source around the head with a simple binaural model
    (spherical head). The stereo input is summed to mono, then:
    - interaural time difference (Woodworth: up to ~0.66 ms) delays the ear that is further away,
    - head shadow: that ear is also darker (one-pole low-pass, down to ~2.7 kHz at 90 degrees) and up to 5 dB quieter,
    - a source behind the head loses treble (high-shelf cut of up to 7 dB above ~3 kHz).
    In the centre in front, both ears get the unchanged mono signal. Best on headphones. In place, no latency. */
class Binaural
{
public:
    static constexpr double kHeadRadius = 0.0875, kSpeedOfSound = 343.0;

    void prepare (double sampleRate)
    {
        sr = sampleRate;
        const int size = fxdetail::powerOfTwoAtLeast ((int) std::ceil (sr * 0.001) + 8);
        buf.assign ((size_t) size, 0.0f);
        mask = size - 1;
        reset();
        delayCoef = (float) (1.0 - std::exp (-1.0 / (0.01 * sr)));
        backCoef = fxdetail::onePoleCoef (3000.0, sr);
    }

    void reset() noexcept
    {
        std::fill (buf.begin(), buf.end(), 0.0f);
        write = 0;
        dl = dr = 0.0f;
        lpL = lpR = lpB = 0.0f;
    }

    /** Largest delay of one ear for this position, in samples (for tests / display). */
    float itdSamples (float x) const noexcept
    {
        const double lat = std::clamp ((double) std::abs (x), 0.0, 1.0);
        const double theta = std::asin (lat);
        return (float) ((kHeadRadius / kSpeedOfSound) * (theta + std::sin (theta)) * sr);
    }

    void process (float* l, float* r, int n, const Pan3dSettings& s) noexcept
    {
        if (buf.empty()) return;
        const float lat = std::clamp (s.x, -1.0f, 1.0f);
        const float aLat = std::abs (lat);
        const float back = std::clamp (-s.y, 0.0f, 1.0f);

        const float itd = itdSamples (lat);
        const float targetL = lat > 0.0f ? itd : 0.0f;   // source on the right: the left ear is the far one
        const float targetR = lat < 0.0f ? itd : 0.0f;
        const float farCoef = fxdetail::onePoleCoef (16000.0 * std::pow (0.17, (double) aLat), sr);
        const float coefL = lat > 0.0f ? farCoef : 0.0f;
        const float coefR = lat < 0.0f ? farCoef : 0.0f;
        const float farGain = dbToGain (-5.0f * aLat, -200.0f);
        const float gainL = lat > 0.0f ? farGain : 1.0f;
        const float gainR = lat < 0.0f ? farGain : 1.0f;
        const float shelf = dbToGain (-7.0f * back, -200.0f);

        for (int i = 0; i < n; ++i)
        {
            const float m = 0.5f * (l[i] + r[i]);
            lpB = (1.0f - backCoef) * m + backCoef * lpB;
            buf[(size_t) write] = lpB + shelf * (m - lpB);

            dl += (targetL - dl) * delayCoef;
            dr += (targetR - dr) * delayCoef;
            const float vl = fxdetail::readFrac (buf.data(), mask, write, dl);
            const float vr = fxdetail::readFrac (buf.data(), mask, write, dr);
            write = (write + 1) & mask;

            lpL = (1.0f - coefL) * vl + coefL * lpL;
            lpR = (1.0f - coefR) * vr + coefR * lpR;
            l[i] = lpL * gainL;
            r[i] = lpR * gainR;
        }
    }

private:
    double sr = 48000.0;
    std::vector<float> buf;
    int mask = 0, write = 0;
    float dl = 0.0f, dr = 0.0f, lpL = 0.0f, lpR = 0.0f, lpB = 0.0f;
    float delayCoef = 0.002f, backCoef = 0.3f;
};
} // namespace hydra::dsp
