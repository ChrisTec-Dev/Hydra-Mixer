#pragma once
#include "Common.h"

#include <algorithm>
#include <cmath>
#include <vector>

/** Internal effects (Voicemeeter Potato has a reverb and a multi-tap delay with send / return).
    Both are wet-only: the engine feeds them from the inputs' FX sends and mixes the result back
    through the return level of every bus. No allocation after prepare(), no latency of their own. */
namespace hydra::dsp
{
namespace fxdetail
{
/** Reads the sample written `delay` samples ago (delay >= 1, fractional, linear interpolation).
    `write` is the position the next sample goes to. */
inline float readFrac (const float* buf, int mask, int write, float delay) noexcept
{
    const int di = (int) delay;
    const float f = delay - (float) di;
    const float a = buf[(write - di) & mask];
    const float b = buf[(write - di - 1) & mask];
    return a + f * (b - a);
}

inline int powerOfTwoAtLeast (int n) noexcept
{
    int s = 1;
    while (s < n) s <<= 1;
    return s;
}

inline float onePoleCoef (double hz, double sr) noexcept
{
    return (float) std::exp (-2.0 * 3.14159265358979323846 * std::min (hz, sr * 0.49) / sr);
}
} // namespace fxdetail

struct ReverbSettings
{
    float preDelayMs = 12.0f;   // 0..250
    float size = 1.0f;          // 0.3..2: scales the delay lines (room size)
    float decayS = 2.0f;        // 0.1..30: reverberation time (RT60) of the low frequencies
    float dampingHz = 7000.0f;  // 1000..20000: the tail loses everything above this faster
    float width = 1.0f;         // 0..1: stereo width of the wet signal
};

/** Stereo feedback delay network reverb: two input diffusers per side, 8 delay lines mixed by an
    orthogonal Hadamard matrix, one-pole damping and a slow modulation in every line (no metallic ringing).
    Output is wet only. */
class Reverb
{
public:
    static constexpr int kLines = 8;
    static constexpr float kMinSize = 0.3f, kMaxSize = 2.0f;
    static constexpr float kMaxPreDelayMs = 250.0f;

    /** Allocates for this sample rate (never call from the audio thread). */
    void prepare (double sampleRate)
    {
        sr = sampleRate;
        const double scale = sr / 48000.0;
        static constexpr int base[kLines] = { 1087, 1283, 1481, 1699, 1907, 2129, 2347, 2593 };   // 23..54 ms at 48 kHz
        modDepth = (float) (0.0005 * sr);                                                          // 0.5 ms
        for (int i = 0; i < kLines; ++i)
        {
            auto& ln = line[(size_t) i];
            baseLen[(size_t) i] = (float) (base[i] * scale);
            const int maxLen = (int) std::ceil (baseLen[(size_t) i] * kMaxSize + modDepth) + 4;
            const int sz = fxdetail::powerOfTwoAtLeast (maxLen + 2);
            ln.buf.assign ((size_t) sz, 0.0f);
            ln.mask = sz - 1;
            const double phi = 2.0 * 3.14159265358979323846 * (double) i / (double) kLines;
            ln.s = (float) std::sin (phi);
            ln.c = (float) std::cos (phi);
            ln.eps = (float) (2.0 * std::sin (3.14159265358979323846 * (0.21 + 0.067 * i) / sr));   // 0.2 .. 0.7 Hz
        }
        static constexpr int apLen[2][2] = { { 214, 163 }, { 227, 173 } };
        for (int ch = 0; ch < 2; ++ch)
            for (int k = 0; k < 2; ++k)
            {
                auto& ap = diffuser[(size_t) ch][(size_t) k];
                ap.buf.assign ((size_t) std::max (2, (int) std::lround (apLen[ch][k] * scale)), 0.0f);
            }
        const int pdSize = fxdetail::powerOfTwoAtLeast ((int) std::ceil (sr * kMaxPreDelayMs / 1000.0) + 4);
        for (auto& b : preBuf) b.assign ((size_t) pdSize, 0.0f);
        preMask = pdSize - 1;
        fresh = true;
        sizeCoef = (float) (1.0 - std::exp (-1.0 / (0.1 * sr)));
        reset();
    }

    void reset() noexcept
    {
        for (auto& ln : line) { std::fill (ln.buf.begin(), ln.buf.end(), 0.0f); ln.write = 0; ln.lp = 0.0f; }
        for (auto& ch : diffuser) for (auto& ap : ch) { std::fill (ap.buf.begin(), ap.buf.end(), 0.0f); ap.pos = 0; }
        for (auto& b : preBuf) std::fill (b.begin(), b.end(), 0.0f);
        preWrite = 0;
    }

    bool isPrepared() const noexcept { return ! line[0].buf.empty(); }

    /** Overwrites outL / outR with the wet signal of inL / inR (n samples). The input and output arrays
        must be different: outputs are written while the inputs are still being read. */
    void process (const float* inL, const float* inR, float* outL, float* outR, int n, const ReverbSettings& s) noexcept
    {
        if (! isPrepared())
        {
            std::fill (outL, outL + n, 0.0f);
            std::fill (outR, outR + n, 0.0f);
            return;
        }

        const float sizeTarget = std::clamp (s.size, kMinSize, kMaxSize);
        const float decay = std::clamp (s.decayS, 0.1f, 30.0f);
        const float preTarget = std::clamp (s.preDelayMs, 0.0f, kMaxPreDelayMs) * (float) (sr / 1000.0);
        const float width = std::clamp (s.width, 0.0f, 1.0f);
        const float damp = fxdetail::onePoleCoef (std::clamp (s.dampingHz, 1000.0f, 20000.0f), sr);
        if (fresh)   // first block after prepare(): no glide from zero
        {
            sizeNow = sizeTarget;
            preNow = preTarget;
            fresh = false;
        }

        // Loop gain per line for the wanted RT60 (-60 dB after `decay` seconds), at the target size.
        float g[kLines];
        float gMean = 0.0f;
        for (int i = 0; i < kLines; ++i)
        {
            const float seconds = baseLen[(size_t) i] * sizeTarget / (float) sr;
            g[i] = std::pow (10.0f, -3.0f * seconds / decay);
            gMean += g[i];
        }
        gMean /= (float) kLines;
        // Keeps the wet level about the same for short and long tails: the injection follows the loop gain, and an
        // empirical term (measured with noise input) makes up for what damping and interpolation take from long tails.
        const float inject = 0.5f * std::sqrt (std::max (0.0f, 1.0f - gMean * gMean));
        const float outGain = 0.5f * std::pow (decay, 0.2f);
        const float invSqrt8 = 0.35355339059f;
        static constexpr float tapL[kLines] = { 1, -1, 1, -1, 1, -1, 1, -1 };
        static constexpr float tapR[kLines] = { 1, 1, -1, -1, 1, 1, -1, -1 };

        for (int i = 0; i < n; ++i)
        {
            // Pre-delay (glides when changed).
            preNow += (preTarget - preNow) * sizeCoef;
            preBuf[0][(size_t) preWrite] = inL[i];
            preBuf[1][(size_t) preWrite] = inR[i];
            float pl = inL[i], pr = inR[i];
            if (preNow > 1.0f)
            {
                pl = fxdetail::readFrac (preBuf[0].data(), preMask, preWrite, preNow);
                pr = fxdetail::readFrac (preBuf[1].data(), preMask, preWrite, preNow);
            }
            preWrite = (preWrite + 1) & preMask;

            // Input diffusion (Schroeder all-passes, g = 0.6).
            float dl = pl, dr = pr;
            for (int k = 0; k < 2; ++k)
            {
                dl = diffuser[0][(size_t) k].process (dl);
                dr = diffuser[1][(size_t) k].process (dr);
            }

            sizeNow += (sizeTarget - sizeNow) * sizeCoef;

            // Read the lines (modulated), damp, apply the loop gain.
            float x[kLines], y[kLines];
            for (int k = 0; k < kLines; ++k)
            {
                auto& ln = line[(size_t) k];
                ln.s += ln.eps * ln.c;
                ln.c -= ln.eps * ln.s;
                const float len = baseLen[(size_t) k] * sizeNow + modDepth * ln.s;
                x[k] = fxdetail::readFrac (ln.buf.data(), ln.mask, ln.write, std::max (2.0f, len));
                ln.lp = (1.0f - damp) * x[k] + damp * ln.lp;
                y[k] = ln.lp * g[k];
            }

            // Orthogonal mixing (fast Walsh-Hadamard transform of 8 values).
            for (int k = 0; k < kLines; k += 2) hadamard (y[k], y[k + 1]);
            hadamard (y[0], y[2]); hadamard (y[1], y[3]); hadamard (y[4], y[6]); hadamard (y[5], y[7]);
            for (int k = 0; k < 4; ++k) hadamard (y[k], y[k + 4]);

            float l = 0.0f, r = 0.0f;
            for (int k = 0; k < kLines; ++k)
            {
                auto& ln = line[(size_t) k];
                const float in = (k & 1) ? dr : dl;   // left feeds the even lines, right the odd ones
                ln.buf[(size_t) ln.write] = flushDenormal (y[k] * invSqrt8 + in * inject);
                ln.write = (ln.write + 1) & ln.mask;
                l += tapL[k] * x[k];
                r += tapR[k] * x[k];
            }
            l *= outGain;
            r *= outGain;
            const float mid = 0.5f * (l + r), side = 0.5f * (l - r) * width;
            outL[i] = mid + side;
            outR[i] = mid - side;
        }
    }

private:
    static void hadamard (float& a, float& b) noexcept { const float t = a + b; b = a - b; a = t; }
    static float flushDenormal (float v) noexcept { return std::abs (v) < 1.0e-20f ? 0.0f : v; }

    struct Line
    {
        std::vector<float> buf;
        int mask = 0, write = 0;
        float lp = 0.0f;
        float s = 0.0f, c = 1.0f, eps = 0.0f;   // modulation oscillator (a "magic circle": stable, two multiplications)
    };

    struct Allpass
    {
        std::vector<float> buf;
        int pos = 0;
        float process (float x) noexcept
        {
            const float d = buf[(size_t) pos];
            const float v = x + 0.6f * d;
            buf[(size_t) pos] = v;
            if (++pos == (int) buf.size()) pos = 0;
            return d - 0.6f * v;
        }
    };

    double sr = 48000.0;
    std::array<Line, kLines> line;
    std::array<float, kLines> baseLen {};
    std::array<std::array<Allpass, 2>, 2> diffuser;
    std::array<std::vector<float>, 2> preBuf;
    int preMask = 0, preWrite = 0;
    float modDepth = 24.0f, sizeNow = 1.0f, preNow = 0.0f, sizeCoef = 0.0004f;
    bool fresh = true;
};
} // namespace hydra::dsp
