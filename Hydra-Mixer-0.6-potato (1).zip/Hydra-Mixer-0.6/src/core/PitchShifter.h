#pragma once
#include "Reverb.h"

namespace hydra::dsp
{
struct PitchSettings
{
    float semitones = 0.0f;   // -12..+12 (0 = off, nothing is processed)
    float mix = 1.0f;         // 0..1: dry (time aligned) .. shifted
};

/** Pitch shifter / voice changer (Voicemeeter Potato has a "Pitch Shifter / Voice Modeler" next to its denoiser).
    Two read taps move through a delay line at a speed of (1 - ratio) samples per sample and are cross-faded with
    squared-sine windows half a window apart, the classic low-latency "delay line" shifter. Window 36 ms: it
    adds window / 2 = 18 ms of latency while on (the dry path of the mix is delayed by the same amount, so mixing
    does not comb-filter). Good for voices and effects, not for polyphonic music. In place. */
class PitchShifter
{
public:
    static constexpr float kWindowMs = 36.0f;

    void prepare (double sampleRate)
    {
        sr = sampleRate;
        window = std::max (64, (int) std::lround (sr * kWindowMs / 1000.0));
        const int size = fxdetail::powerOfTwoAtLeast (window * 2 + 8);
        for (auto& b : buf) b.assign ((size_t) size, 0.0f);
        mask = size - 1;
        reset();
    }

    void reset() noexcept
    {
        for (auto& b : buf) std::fill (b.begin(), b.end(), 0.0f);
        write = 0;
        sweep = 0.0f;
    }

    /** Latency while the shifter is on, in samples. */
    int getLatencySamples() const noexcept { return window / 2; }

    void process (float* l, float* r, int n, const PitchSettings& s) noexcept
    {
        if (buf[0].empty()) return;
        const float semis = std::clamp (s.semitones, -12.0f, 12.0f);
        if (std::abs (semis) < 0.005f) { wasOn = false; return; }
        if (! wasOn) { reset(); wasOn = true; }

        const float ratio = std::pow (2.0f, semis / 12.0f);
        const float rate = 1.0f - ratio;               // change of the tap delay per sample
        const float mix = std::clamp (s.mix, 0.0f, 1.0f);
        const float w = (float) window, half = 0.5f * w;
        float* ch[2] = { l, r };

        for (int i = 0; i < n; ++i)
        {
            buf[0][(size_t) write] = l[i];
            buf[1][(size_t) write] = r[i];

            sweep += rate;
            if (sweep >= w) sweep -= w;
            else if (sweep < 0.0f) sweep += w;
            float dB = sweep + half;
            if (dB >= w) dB -= w;
            // Squared sine windows: 0 at the point where a tap jumps back, the two always add up to 1.
            const float sa = std::sin (3.14159265f * sweep / w);
            const float wa = sa * sa;
            const float wb = 1.0f - wa;

            for (int c = 0; c < 2; ++c)
            {
                const float* b = buf[(size_t) c].data();
                const float wet = wa * fxdetail::readFrac (b, mask, write, sweep) + wb * fxdetail::readFrac (b, mask, write, dB);
                const float dry = b[(write - window / 2) & mask];
                ch[c][i] = dry + mix * (wet - dry);
            }
            write = (write + 1) & mask;
        }
    }

private:
    double sr = 48000.0;
    int window = 1728, mask = 0, write = 0;
    float sweep = 0.0f;
    bool wasOn = false;
    std::array<std::vector<float>, 2> buf;
};
} // namespace hydra::dsp
