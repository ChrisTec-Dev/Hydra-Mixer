# Windows installer

Two ways to get `HydraMixer-<version>-Setup.exe` and the portable `HydraMixer-<version>-win64.zip`.

## On GitHub (nothing to install on your PC)

1. Use a fork or a clone of the Hydra Mixer repository: the JUCE submodule has to be part of it.
2. Get the workflow into it (`.github/workflows/windows-installer.yml`): with Git, or in the browser with
   **Add file → Create new file**, the name `.github/workflows/build-windows.yml` and the text of the file pasted in.
3. Without Git: upload the zip with the changes (`Hydra-Mixer-0.6-potato.zip`) to the root of the repository
   (**Add file → Upload files**). The workflow adds its files to the sources before it builds.
4. Open **Actions → Windows build and installer → Run workflow**. It takes about 15 to 40 minutes.
5. Open the finished run, **Artifacts → HydraMixer-Windows**: the installer, the zip and the test log.
   (Pushing a tag such as `v0.6.1` also attaches the files to a GitHub release.)

The workflow is `.github/workflows/windows-installer.yml`. If the build step fails, the log shows the compiler errors.

## On your PC

Install Visual Studio Build Tools (C++ workload), CMake, Ninja (see the main README) and
[Inno Setup](https://jrsoftware.org/isdl.php) 6.3 or newer (`winget install JRSoftware.InnoSetup`), then:

```powershell
.\installer\build-installer.ps1
```

The files are written to `installer\Output`. To pack an existing build by hand:
`ISCC.exe /DAppVersion=0.6.0 installer\HydraMixer.iss` (optional: `/DBuildDir=<folder of "Hydra Mixer.exe">`, `/DIconFile=<icon.ico>`).

## What the installer does

- Installs to Program Files (or only for you if you decline administrator rights), adds a Start menu entry and an
  optional desktop icon. Installing a new version over an old one works: it closes the running app first.
- Warns if Windows reports no AVX2 support, because Hydra Mixer is built with AVX2 and would not start.
- The uninstaller removes the "Start with Windows" scheduled task of the app and asks whether to delete your settings,
  sessions and backups in `%APPDATA%\HydraMixer` (they are kept by default).
- It is not code-signed. Windows SmartScreen may show "Windows protected your PC": **More info → Run anyway**.
