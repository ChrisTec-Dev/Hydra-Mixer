// Internal effects (core/Reverb.h, MultiTapDelay.h, Chorus.h, Binaural.h, PitchShifter.h): offline checks of what
// the DSP promises. Only the standard library is used, so the same file also runs without JUCE.
#include "core/Reverb.h"
#include "core/MultiTapDelay.h"
#include "core/Chorus.h"
#include "core/Binaural.h"
#include "core/PitchShifter.h"

#include <cstdio>
#include <cstdlib>
#include <random>

namespace
{
constexpr double kSr = 48000.0;
constexpr double kPi = 3.14159265358979323846;

std::vector<float> noise (int n, float rms, unsigned seed)
{
    std::mt19937 rng (seed);
    std::normal_distribution<float> d (0.0f, rms);
    std::vector<float> v ((size_t) n);
    for (auto& x : v) x = d (rng);
    return v;
}

std::vector<float> sine (int n, double hz, float amp = 0.5f, double sr = kSr)
{
    std::vector<float> v ((size_t) n);
    for (int i = 0; i < n; ++i) v[(size_t) i] = amp * (float) std::sin (2.0 * kPi * hz * i / sr);
    return v;
}

double rms (const std::vector<float>& v, size_t from = 0, size_t to = 0)
{
    if (to == 0 || to > v.size()) to = v.size();
    double s = 0.0;
    for (size_t i = from; i < to; ++i) s += (double) v[i] * v[i];
    return std::sqrt (s / (double) std::max<size_t> (1, to - from));
}

double db (double ratio) { return 20.0 * std::log10 (std::max (1.0e-12, ratio)); }

bool finite (const std::vector<float>& v)
{
    for (float x : v) if (! std::isfinite (x)) return false;
    return true;
}

/** Strongest frequency in [lo, hi] Hz (Goertzel scan, 1 Hz steps) of v[from..]. */
double peakFreq (const std::vector<float>& v, size_t from, size_t count, double lo, double hi)
{
    double best = 0.0, bestMag = -1.0;
    for (double f = lo; f <= hi; f += 1.0)
    {
        const double w = 2.0 * kPi * f / kSr, coef = 2.0 * std::cos (w);
        double s1 = 0.0, s2 = 0.0;
        for (size_t i = 0; i < count; ++i)
        {
            const double win = 0.5 - 0.5 * std::cos (2.0 * kPi * (double) i / (double) count);
            const double s0 = (double) v[from + i] * win + coef * s1 - s2;
            s2 = s1; s1 = s0;
        }
        const double mag = s1 * s1 + s2 * s2 - coef * s1 * s2;
        if (mag > bestMag) { bestMag = mag; best = f; }
    }
    return best;
}

/** Processes `in` through the reverb in blocks of 256; returns left / right. */
void runReverb (hydra::dsp::Reverb& rv, const hydra::dsp::ReverbSettings& s, const std::vector<float>& inL, const std::vector<float>& inR,
                std::vector<float>& outL, std::vector<float>& outR)
{
    outL.assign (inL.size(), 0.0f);
    outR.assign (inL.size(), 0.0f);
    for (size_t pos = 0; pos < inL.size(); pos += 256)
    {
        const int n = (int) std::min<size_t> (256, inL.size() - pos);
        rv.process (inL.data() + pos, inR.data() + pos, outL.data() + pos, outR.data() + pos, n, s);
    }
}

/** Reverberation time from an impulse response: Schroeder backward integration, T20 extrapolated to 60 dB. */
double rt60 (const std::vector<float>& ir)
{
    std::vector<double> edc (ir.size());
    double acc = 0.0;
    for (size_t i = ir.size(); i-- > 0;) { acc += (double) ir[i] * ir[i]; edc[i] = acc; }
    const double total = edc[0];
    auto timeAt = [&] (double levelDb)
    {
        for (size_t i = 0; i < edc.size(); ++i)
            if (10.0 * std::log10 (edc[i] / total + 1.0e-30) <= levelDb) return (double) i / kSr;
        return (double) edc.size() / kSr;
    };
    return 3.0 * (timeAt (-25.0) - timeAt (-5.0));   // T20 x 3
}
} // namespace

int runFxTest()
{
    int fails = 0;
    auto check = [&] (bool c, const char* what) { std::printf ("%s %s\n", c ? "ok:  " : "FAIL:", what); if (! c) ++fails; };
    using namespace hydra::dsp;

    //------------------------------------------------------------------ Reverb
    {   // The reverberation time follows the decay setting (measured on the impulse response, no damping).
        for (float decay : { 1.0f, 3.0f })
        {
            Reverb rv;
            rv.prepare (kSr);
            ReverbSettings s;
            s.decayS = decay; s.dampingHz = 20000.0f; s.preDelayMs = 0.0f;
            const int n = (int) (kSr * (decay * 2.0f + 1.0f));
            std::vector<float> inL ((size_t) n, 0.0f), inR ((size_t) n, 0.0f), oL, oR;
            inL[0] = inR[0] = 1.0f;
            runReverb (rv, s, inL, inR, oL, oR);
            const double t = rt60 (oL);
            char msg[120];
            std::snprintf (msg, sizeof msg, "reverb RT60 for decay %.1f s is %.2f s (within 25 %%)", decay, t);
            check (std::abs (t - decay) < 0.25 * decay, msg);
        }
    }

    {   // Level stays comparable for short and long tails, output is finite and stable at the extremes.
        auto inL = noise (int (kSr * 6), 0.1f, 1), inR = noise (int (kSr * 6), 0.1f, 2);
        double levels[2];
        int k = 0;
        for (float decay : { 0.3f, 5.0f })
        {
            Reverb rv;
            rv.prepare (kSr);
            ReverbSettings s;
            s.decayS = decay;
            std::vector<float> oL, oR;
            runReverb (rv, s, inL, inR, oL, oR);
            levels[k++] = rms (oL, (size_t) (kSr * 3));
            check (finite (oL) && finite (oR), "reverb output is finite");
        }
        char msg[140];
        std::snprintf (msg, sizeof msg, "reverb wet level of short (%.1f dB) and long tail (%.1f dB) within 3 dB",
                       db (levels[0] / 0.1), db (levels[1] / 0.1));
        check (std::abs (db (levels[0] / levels[1])) < 3.0, msg);
        check (db (levels[1] / 0.1) > -20.0 && db (levels[1] / 0.1) < 6.0, "reverb wet level is usable (-20 .. +6 dB re input)");

        Reverb rv;
        rv.prepare (kSr);
        ReverbSettings extreme;
        extreme.decayS = 30.0f; extreme.size = 2.0f; extreme.dampingHz = 20000.0f; extreme.preDelayMs = 250.0f;
        std::vector<float> oL, oR;
        runReverb (rv, extreme, inL, inR, oL, oR);
        float peak = 0.0f;
        for (float x : oL) peak = std::max (peak, std::abs (x));
        check (finite (oL) && peak < 8.0f, "reverb at its extremes (30 s, size 2, no damping) stays bounded");
    }

    {   // Width 0 gives a mono wet signal, width 1 decorrelates the sides; the pre-delay delays the onset.
        auto inL = noise (int (kSr * 2), 0.1f, 5);
        auto inR = inL;
        Reverb rv;
        rv.prepare (kSr);
        ReverbSettings s;
        s.width = 0.0f;
        std::vector<float> oL, oR;
        runReverb (rv, s, inL, inR, oL, oR);
        double maxDiff = 0.0;
        for (size_t i = 0; i < oL.size(); ++i) maxDiff = std::max (maxDiff, (double) std::abs (oL[i] - oR[i]));
        check (maxDiff < 1.0e-6, "reverb width 0: left == right");

        rv.reset();
        s.width = 1.0f;
        runReverb (rv, s, inL, inR, oL, oR);
        double sl = 0, sr2 = 0, slr = 0;
        for (size_t i = (size_t) kSr; i < oL.size(); ++i) { sl += (double) oL[i] * oL[i]; sr2 += (double) oR[i] * oR[i]; slr += (double) oL[i] * oR[i]; }
        const double corr = slr / std::sqrt (sl * sr2 + 1.0e-30);
        check (std::abs (corr) < 0.6, "reverb width 1: the two sides are decorrelated");

        Reverb r2;
        r2.prepare (kSr);
        ReverbSettings pd;
        pd.preDelayMs = 100.0f;
        std::vector<float> iL ((size_t) kSr, 0.0f), iR ((size_t) kSr, 0.0f);
        iL[0] = iR[0] = 1.0f;
        runReverb (r2, pd, iL, iR, oL, oR);
        size_t first = 0;
        while (first < oL.size() && std::abs (oL[first]) < 1.0e-4f && std::abs (oR[first]) < 1.0e-4f) ++first;
        check (first > (size_t) (0.095 * kSr), "reverb pre-delay of 100 ms holds the onset back");
    }

    //------------------------------------------------------------------ Delay
    {   // Taps at 1x, 2x, 3x the time, -6 dB apart, alternating left / right.
        MultiTapDelay d;
        d.prepare (kSr);
        DelaySettings s;
        s.timeMs = 100.0f; s.taps = 3; s.stepDb = -6.0f; s.feedback = 0.0f; s.spread = 1.0f;
        const int n = (int) (kSr * 0.6);
        std::vector<float> inL ((size_t) n, 0.0f), inR ((size_t) n, 0.0f), oL ((size_t) n), oR ((size_t) n);
        inL[100] = inR[100] = 1.0f;
        for (int pos = 0; pos < n; pos += 128)
        {
            const int len = std::min (128, n - pos);
            d.process (inL.data() + pos, inR.data() + pos, oL.data() + pos, oR.data() + pos, len, s);
        }
        const int t1 = 100 + 4800, t2 = 100 + 9600, t3 = 100 + 14400;
        check (std::abs (oL[(size_t) t1] - 1.0f) < 1.0e-3f && std::abs (oR[(size_t) t1]) < 1.0e-3f, "delay tap 1: after 1x time, left only, 0 dB");
        check (std::abs (oR[(size_t) t2] - 0.5012f) < 2.0e-3f && std::abs (oL[(size_t) t2]) < 1.0e-3f, "delay tap 2: after 2x time, right only, -6 dB");
        check (std::abs (oL[(size_t) t3] - 0.2512f) < 2.0e-3f && std::abs (oR[(size_t) t3]) < 1.0e-3f, "delay tap 3: after 3x time, left only, -12 dB");
        double beforeFirst = 0.0;
        for (int i = 0; i < t1 - 1; ++i) beforeFirst = std::max (beforeFirst, (double) std::abs (oL[(size_t) i]));
        check (beforeFirst < 1.0e-6, "delay is silent before the first tap (wet only)");
    }

    {   // Feedback at its maximum stays bounded for a long noise input; time changes do not blow up.
        MultiTapDelay d;
        d.prepare (kSr);
        DelaySettings s;
        s.taps = 4; s.feedback = 0.9f; s.dampingHz = 20000.0f; s.stepDb = 0.0f;
        auto inL = noise (int (kSr * 10), 0.2f, 7), inR = noise (int (kSr * 10), 0.2f, 8);
        std::vector<float> oL (inL.size()), oR (inL.size());
        float peak = 0.0f;
        for (size_t pos = 0; pos < inL.size(); pos += 256)
        {
            const int n = (int) std::min<size_t> (256, inL.size() - pos);
            s.timeMs = 20.0f + 980.0f * (0.5f + 0.5f * (float) std::sin ((double) pos / kSr));   // sweeping the time
            d.process (inL.data() + pos, inR.data() + pos, oL.data() + pos, oR.data() + pos, n, s);
        }
        for (float x : oL) peak = std::max (peak, std::abs (x));
        check (finite (oL) && finite (oR) && peak < 20.0f, "delay with 90 % feedback and a moving time stays bounded");
    }

    //------------------------------------------------------------------ Chorus
    {
        Chorus c;
        c.prepare (kSr);
        auto l = sine (4800, 1000.0), r = l;
        auto l0 = l, r0 = r;
        ChorusSettings s;
        s.amount = 0.0f;
        c.process (l.data(), r.data(), 4800, s);
        check (l == l0 && r == r0, "chorus at 0: the signal passes untouched");

        s.amount = 1.0f;
        std::vector<float> all;
        for (int b = 0; b < 100; ++b)
        {
            auto bl = sine (480, 1000.0), br = bl;
            c.process (bl.data(), br.data(), 480, s);
            all.insert (all.end(), bl.begin(), bl.end());
        }
        const double g = db (rms (all, 24000) / rms (sine (48000, 1000.0)));
        char msg[120];
        std::snprintf (msg, sizeof msg, "chorus at 100 %%: level %.1f dB re input (between -6 and +3)", g);
        check (finite (all) && g > -6.0 && g < 3.0, msg);
    }

    //------------------------------------------------------------------ 3D pan
    {
        Binaural b;
        b.prepare (kSr);
        auto l = noise (48000, 0.2f, 11), r = noise (48000, 0.2f, 12);
        auto l0 = l, r0 = r;
        Pan3dSettings s;   // centre, in front
        b.process (l.data(), r.data(), 48000, s);
        double maxDiff = 0.0;
        for (size_t i = 0; i < l.size(); ++i)
            maxDiff = std::max ({ maxDiff, (double) std::abs (l[i] - 0.5f * (l0[i] + r0[i])), (double) std::abs (r[i] - 0.5f * (l0[i] + r0[i])) });
        check (maxDiff < 1.0e-5, "3D pan in the centre in front: both ears get the mono sum unchanged");
    }

    {   // Source on the right: left ear later (ITD), darker and quieter.
        Binaural b;
        b.prepare (kSr);
        auto mono = noise (48000, 0.2f, 13);
        auto l = mono, r = mono;
        Pan3dSettings s;
        s.x = 1.0f;
        for (size_t pos = 0; pos < l.size(); pos += 256)
            b.process (l.data() + pos, r.data() + pos, (int) std::min<size_t> (256, l.size() - pos), s);
        // Lag of the left channel relative to the right (best cross-correlation) in the settled second half.
        int bestLag = 0;
        double bestC = -1e30;
        for (int lag = 0; lag <= 60; ++lag)
        {
            double c = 0.0;
            for (size_t i = 24000; i < 47000; ++i) c += (double) l[i + (size_t) lag - (size_t) 0] * r[i];
            // l is delayed: l[i + lag] ~ r[i]
            if (c > bestC) { bestC = c; bestLag = lag; }
        }
        const double itd = b.itdSamples (1.0f);
        char msg[140];
        std::snprintf (msg, sizeof msg, "3D pan x=+1: left ear lags by %d samples (model: %.1f, about 0.66 ms)", bestLag, itd);
        check (std::abs ((double) bestLag - itd) <= 3.0, msg);
        check (rms (l, 24000, 47000) < rms (r, 24000, 47000) * 0.8, "3D pan x=+1: the far (left) ear is quieter");
    }

    {   // Behind the head the treble drops, the bass stays.
        auto run = [] (float y, std::vector<float>& out)
        {
            Binaural b;
            b.prepare (kSr);
            out = noise (48000, 0.2f, 14);
            auto r = out;
            Pan3dSettings s;
            s.y = y;
            b.process (out.data(), r.data(), 48000, s);
        };
        std::vector<float> front, back;
        run (1.0f, front);
        run (-1.0f, back);
        auto band = [] (const std::vector<float>& v, double hz)
        {
            double re = 0, im = 0;
            for (size_t i = 0; i < v.size(); ++i) { re += v[i] * std::cos (2 * kPi * hz * (double) i / kSr); im += v[i] * std::sin (2 * kPi * hz * (double) i / kSr); }
            return std::sqrt (re * re + im * im);
        };
        const double hiDrop = db (band (back, 9000.0) / band (front, 9000.0));
        const double loDrop = db (band (back, 300.0) / band (front, 300.0));
        char msg[140];
        std::snprintf (msg, sizeof msg, "3D pan behind: 9 kHz %.1f dB, 300 Hz %.1f dB re front", hiDrop, loDrop);
        check (hiDrop < -4.0 && std::abs (loDrop) < 1.0, msg);
    }

    //------------------------------------------------------------------ Pitch shifter
    {
        struct Case { float semis; double wanted; };
        for (auto c : { Case { 12.0f, 880.0 }, Case { -12.0f, 220.0 }, Case { 7.0f, 440.0 * std::pow (2.0, 7.0 / 12.0) } })
        {
            PitchShifter p;
            p.prepare (kSr);
            PitchSettings s;
            s.semitones = c.semis; s.mix = 1.0f;
            auto l = sine (96000, 440.0), r = l;
            for (size_t pos = 0; pos < l.size(); pos += 256)
                p.process (l.data() + pos, r.data() + pos, (int) std::min<size_t> (256, l.size() - pos), s);
            const double f = peakFreq (l, 24000, 48000, 100.0, 2000.0);
            const double level = db (rms (l, 24000) / rms (sine (48000, 440.0)));
            char msg[160];
            std::snprintf (msg, sizeof msg, "pitch %+.0f semitones: %.0f Hz (wanted %.0f), level %.1f dB", c.semis, f, c.wanted, level);
            check (std::abs (f - c.wanted) < 0.02 * c.wanted && std::abs (level) < 4.0 && finite (l), msg);
        }

        PitchShifter p;   // mix 0: the input, delayed by the reported latency, exactly
        p.prepare (kSr);
        PitchSettings s;
        s.semitones = 5.0f; s.mix = 0.0f;
        auto in = noise (9600, 0.3f, 21);
        auto l = in, r = in;
        for (size_t pos = 0; pos < l.size(); pos += 100)
            p.process (l.data() + pos, r.data() + pos, 100, s);
        const int lat = p.getLatencySamples();
        double maxDiff = 0.0;
        for (size_t i = (size_t) lat; i < in.size(); ++i) maxDiff = std::max (maxDiff, (double) std::abs (l[i] - in[i - (size_t) lat]));
        check (lat > 0 && maxDiff < 1.0e-6, "pitch mix 0: input delayed by exactly the reported latency");

        PitchShifter q;
        q.prepare (kSr);
        PitchSettings off;
        auto a = noise (1000, 0.3f, 22), b = a;
        auto a0 = a;
        q.process (a.data(), b.data(), 1000, off);
        check (a == a0, "pitch at 0 semitones: signal untouched, no latency");
    }

    std::printf (fails == 0 ? "FX tests passed\n" : "FX tests FAILED (%d)\n", fails);
    return fails;
}
