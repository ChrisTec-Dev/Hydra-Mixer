// VBAN packets (net/VbanProtocol.h) and Voicemeeter style remote scripts (net/RemoteScript.h): offline checks.
// Only the standard library is used, so the same file also runs without JUCE.
#include "net/VbanProtocol.h"
#include "net/RemoteScript.h"

#include <cstdio>
#include <cstdlib>

namespace
{
const hydra::remote::Action* findParam (const std::vector<hydra::remote::Action>& v, const std::string& id)
{
    for (auto& a : v) if (a.kind == hydra::remote::Action::Kind::param && a.id == id) return &a;
    return nullptr;
}
} // namespace

int runRemoteTest()
{
    int fails = 0;
    auto check = [&] (bool c, const char* what) { std::printf ("%s %s\n", c ? "ok:  " : "FAIL:", what); if (! c) ++fails; };
    using namespace hydra;
    namespace R = hydra::remote;

    std::printf ("\n--- VBAN packets ---\n");
    {   // A packet laid out byte by byte as the VBAN specification says (48 kHz, 64 samples, stereo, int16, "Stream1", frame 42).
        std::uint8_t pkt[vban::kMaxPacketSize] = { 'V', 'B', 'A', 'N', 0x03, 0x3F, 0x01, 0x01, 'S', 't', 'r', 'e', 'a', 'm', '1' };
        pkt[24] = 42;
        for (int i = 0; i < 64 * 2; ++i) { pkt[28 + 2 * i] = 0x00; pkt[29 + 2 * i] = 0x40; }   // 0x4000 = 0.5
        vban::Header h;
        check (vban::parseHeader (pkt, 28 + 256, h), "a spec-conform header is accepted");
        check (h.subProtocol == vban::kAudio && vban::sampleRateFromIndex (h.rateIndex) == 48000 && h.samplesPerFrame == 64
               && h.channels == 2 && h.format == vban::kInt16 && h.streamName == "Stream1" && h.frame == 42u,
               "fields: audio, 48000 Hz, 64 samples, 2 channels, int16, \"Stream1\", frame 42");
        float out[128];
        check (vban::decodeSamples (pkt + 28, 256, h.format, 128, out) && std::abs (out[0] - 0.5f) < 1.0e-6f && std::abs (out[127] - 0.5f) < 1.0e-6f,
               "int16 0x4000 decodes to 0.5");
    }
    {
        std::uint8_t bad[40] = { 'V', 'B', 'A', 'X' };
        vban::Header h;
        check (! vban::parseHeader (bad, 40, h), "wrong magic is rejected");
        std::uint8_t ok[28] = { 'V', 'B', 'A', 'N' };
        check (! vban::parseHeader (ok, 27, h) && vban::parseHeader (ok, 28, h), "a packet shorter than the header is rejected");
        float tmp[8];
        std::uint8_t data[8] = {};
        check (! vban::decodeSamples (data, 8, vban::kInt12, 4, tmp), "12 bit packed samples are not supported");
        check (! vban::decodeSamples (data, 6, vban::kInt16, 4, tmp), "a payload shorter than announced is rejected");
    }
    {   // Every format survives a round trip within its resolution.
        std::vector<float> in (64);
        for (size_t i = 0; i < in.size(); ++i) in[i] = 0.9f * (float) std::sin (0.37 * (double) i);
        in[0] = 1.0f; in[1] = -1.0f; in[2] = 0.0f;
        struct Case { int format; double tol; const char* name; };
        for (auto c : { Case { vban::kUint8, 1.0 / 80, "uint8" }, Case { vban::kInt16, 1.0 / 16000, "int16" }, Case { vban::kInt24, 2.0e-7, "int24" },
                        Case { vban::kInt32, 1.0e-7, "int32" }, Case { vban::kFloat32, 0.0, "float32" }, Case { vban::kFloat64, 1.0e-7, "float64" } })
        {
            std::vector<std::uint8_t> bytes (64 * 8);
            const int n = vban::encodeSamples (in.data(), 64, c.format, bytes.data());
            std::vector<float> back (64);
            const bool ok = vban::decodeSamples (bytes.data(), n, c.format, 64, back.data());
            double err = 0;
            for (size_t i = 0; i < in.size(); ++i) err = std::max (err, (double) std::abs (in[i] - back[i]));
            char msg[100];
            std::snprintf (msg, sizeof msg, "%s round trip: %d bytes, max error %.2e", c.name, n, err);
            check (ok && n == 64 * vban::bytesPerSample (c.format) && err <= c.tol, msg);
        }
        float loud[2] = { 3.0f, -3.0f }, back[2];
        std::uint8_t b[8];
        vban::encodeSamples (loud, 2, vban::kInt16, b);
        vban::decodeSamples (b, 4, vban::kInt16, 2, back);
        check (back[0] > 0.999f && back[1] < -0.999f, "samples above full scale are clipped, not wrapped");
    }
    {
        check (vban::maxSamplesPerPacket (2, vban::kInt16) == 256 && vban::maxSamplesPerPacket (8, vban::kFloat32) == 44
               && vban::maxSamplesPerPacket (1, vban::kInt16) == 256, "samples per packet: 256 (stereo int16), 44 (8 x float32)");
        vban::Header h;
        h.channels = 2; h.format = vban::kInt16; h.rateIndex = vban::indexFromSampleRate (44100); h.streamName = "ABCDEFGHIJKLMNOPQRS"; h.frame = 7;
        std::vector<float> audio (2 * 100, 0.25f);
        std::uint8_t pkt[vban::kMaxPacketSize];
        const int size = vban::buildAudioPacket (h, audio.data(), 100, pkt);
        vban::Header back;
        check (size == 28 + 100 * 4 && vban::parseHeader (pkt, size, back) && back.samplesPerFrame == 100 && back.channels == 2
               && vban::sampleRateFromIndex (back.rateIndex) == 44100 && back.frame == 7u, "audio packet: size and header fields");
        check (back.streamName == "ABCDEFGHIJKLMNOP", "a stream name longer than 16 characters is cut");
        check (vban::buildAudioPacket (h, audio.data(), 300, pkt) == 0, "more samples than fit one packet: refused");
        check (vban::indexFromSampleRate (12345) == -1 && vban::indexFromSampleRate (96000) == 4, "sample rate table");
    }
    {
        std::uint8_t pkt[vban::kMaxPacketSize];
        const std::string text = "Strip[0].Gain = -6;";
        const int size = vban::buildTextPacket ("Command1", 3, text, pkt);
        vban::Header h;
        check (vban::parseHeader (pkt, size, h) && h.subProtocol == vban::kText && h.streamName == "Command1" && vban::decodeText (pkt, size) == text,
               "VBAN-TEXT packet round trip");
        pkt[size] = 0;
        check (vban::decodeText (pkt, size + 1) == text, "trailing zero bytes of a text are dropped");
    }

    std::printf ("\n--- remote scripts ---\n");
    {
        auto a = R::actionsFor ("Strip[0].Gain = -6; Strip[1].Mute=1;\nBus[2].Gain=0");
        const auto* g = findParam (a, "in1.gain");
        const auto* m = findParam (a, "in2.mute");
        const auto* b = findParam (a, "bus.a3.gain");
        check (a.size() == 3 && g && g->value == -6.0 && g->op == '=' && m && m->value == 1.0 && b && b->value == 0.0, "gain, mute and bus gain; ';' and new lines separate");
        check (findParam (R::actionsFor ("strip(2).GAIN=3"), "in3.gain") != nullptr, "case does not matter, (n) works like [n]");
        check (findParam (R::actionsFor ("Strip[0].Mute = on; Strip[1].Solo = false"), "in1.mute")->value == 1.0, "on / off / true / false are numbers");
    }
    {
        auto bus = [] (int i) { auto a = R::actionsFor ("Bus[" + std::to_string (i) + "].Mute=1"); return a.empty() ? std::string() : a[0].id; };
        check (bus (0) == "bus.a1.mute" && bus (4) == "bus.a5.mute" && bus (5) == "bus.b1.mute" && bus (7) == "bus.b3.mute",
               "buses 0..4 are A1..A5 and 5..7 are B1..B3 as in Voicemeeter Potato");
        check (bus (8) == "bus.a6.mute" && bus (10) == "bus.a8.mute" && bus (11) == "bus.b4.mute" && bus (15) == "bus.b8.mute" && bus (16).empty(),
               "buses 8..15 are the extra Hydra outputs, 16 does not exist");
        check (R::actionsFor ("Strip[16].Mute=1").empty() && findParam (R::actionsFor ("Strip[15].Mute=1"), "in16.mute"), "strips 0..15");
        check (findParam (R::actionsFor ("Strip[0].A1 = 1"), "in1.route.a1") && findParam (R::actionsFor ("Strip[3].B2 = 0"), "in4.route.b2"),
               "Strip[n].A1 / B2 are the routing switches");
    }
    {
        auto a = R::actionsFor ("Strip[0].Pan_x = 0.25; Strip[0].Reverb = 5; Strip[1].Delay = 10; Bus[0].ReturnReverb = 10; Bus[1].ReturnDelay = 0");
        check (std::abs (findParam (a, "in1.pan")->value - 0.5) < 1.0e-9, "Pan_x -0.5..0.5 becomes pan -1..1");
        check (std::abs (findParam (a, "in1.fxs.rev")->value + 30.0) < 1.0e-9 && std::abs (findParam (a, "in2.fxs.dly")->value) < 1.0e-9,
               "FX send knobs 0..10 become -60..0 dB");
        check (std::abs (findParam (a, "bus.a1.fxr.rev")->value) < 1.0e-9 && std::abs (findParam (a, "bus.a2.fxr.dly")->value + 60.0) < 1.0e-9,
               "FX return knobs 0..10 become -60..0 dB");

        auto lim = R::actionsFor ("Strip[0].Limit = -12; Strip[1].Limit = 12; Strip[2].Denoiser = 5; Strip[3].Denoiser = 0");
        check (findParam (lim, "in1.lim.on")->value == 1.0 && findParam (lim, "in1.lim.thr")->value == -12.0
               && findParam (lim, "in2.lim.on")->value == 0.0 && findParam (lim, "in2.lim.thr")->value == 12.0, "Limit -40..12: 12 means off");
        check (findParam (lim, "in3.dn.on")->value == 1.0 && findParam (lim, "in3.dn.amount")->value == 50.0
               && findParam (lim, "in4.dn.on")->value == 0.0, "Denoiser knob 0..10: on above 0, amount x 10 %");
        check (std::abs (findParam (R::actionsFor ("Strip[0].Comp.Knee = 0.5"), "in1.comp.knee")->value - 6.0) < 1.0e-9
               && findParam (R::actionsFor ("Strip[0].Gate.Damping = -70"), "in1.gate.range") != nullptr, "compressor and gate detail names");
    }
    {
        auto rel = R::actionsFor ("Strip[0].Gain -= 3; Strip[0].Pan_x += 0.1");
        check (rel.size() == 2 && rel[0].op == '+' && rel[0].value == -3.0 && rel[1].op == '+' && std::abs (rel[1].value - 0.2) < 1.0e-9,
               "-= and += are relative (scaled like the value)");
    }
    {
        auto a = R::actionsFor ("Strip[3].Label = \"My Mic\"; Bus[1].Label=\"Cans\"; Command.Restart = 1; Scene[2].Recall = 1; Scene[0].Recall=1");
        check (a.size() == 4 && a[0].kind == R::Action::Kind::label && a[0].isInput && a[0].index == 3 && a[0].text == "My Mic", "Strip label");
        check (a[1].kind == R::Action::Kind::label && ! a[1].isInput && a[1].busCode == "A2" && a[1].text == "Cans", "Bus label");
        check (a[2].kind == R::Action::Kind::command && a[2].id == "restart" && a[2].value == 1.0, "Command.Restart");
        check (a[3].kind == R::Action::Kind::param && a[3].id == "scene.2", "Scene[2].Recall triggers scene 2 (Scene[0] does not exist)");
        auto q = R::actionsFor ("Strip[0].Label=\"a;b\"; Strip[1].Mute=1");
        check (q.size() == 2 && q[0].text == "a;b", "a ';' inside quotes does not end the statement");
    }
    {
        check (findParam (R::actionsFor ("Param[in1.pitch.semi] = 3"), "in1.pitch.semi")->value == 3.0
               && findParam (R::actionsFor ("Param[Bus.A1.fxr.rev] = -9"), "bus.a1.fxr.rev") != nullptr, "Param[id] reaches any parameter (id is not case sensitive)");
        check (findParam (R::actionsFor ("Strip[0].pan3d.x = 0.5"), "in1.pan3d.x") != nullptr
               && findParam (R::actionsFor ("Bus[5].eq.b2.gain = 3"), "bus.b1.eq.b2.gain") != nullptr,
               "other Hydra parameters by their id without the channel prefix");
        check (R::actionsFor ("hello; Strip[0]=1; Strip[x].Gain=1; Strip[0].Gain=abc; Strip[0].Gain; =5; Strip[0].Gain=").empty(),
               "garbage is skipped without effect");
        check (R::actionsFor ("Strip[0].Mute=1;;;  ;Strip[1].Mute=1;").size() == 2, "empty statements are ignored");
        check (R::actionsFor ("Strip[0].Mute = \"on\"").empty(), "a text where a number belongs does nothing");
    }

    std::printf (fails == 0 ? "Remote tests passed\n" : "Remote tests FAILED (%d)\n", fails);
    return fails;
}
