int runFxTest();
int main() { return runFxTest() == 0 ? 0 : 1; }
