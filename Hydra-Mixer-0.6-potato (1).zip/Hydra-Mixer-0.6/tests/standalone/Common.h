// Minimal stand-in for src/Common.h, only for compiling the pure DSP / protocol code with g++ in a sandbox
// without JUCE. It provides the small part of juce:: that core/Dsp.h and the new headers touch.
#pragma once
#include <algorithm>
#include <array>
#include <atomic>
#include <cmath>
#include <complex>
#include <cstdint>
#include <cstring>
#include <memory>
#include <string>
#include <vector>

namespace juce
{
template <class T> constexpr T jmax (T a, T b) { return a > b ? a : b; }
template <class T> constexpr T jmin (T a, T b) { return a < b ? a : b; }
template <class T> constexpr T jlimit (T lo, T hi, T v) { return v < lo ? lo : (v > hi ? hi : v); }
template <class T> struct MathConstants { static constexpr T pi = (T) 3.14159265358979323846L; static constexpr T twoPi = (T) 2 * pi; };
template <class T> struct Range { T s, e; T getStart() const { return s; } T getEnd() const { return e; } };
struct FloatVectorOperations
{
    static void multiply (float* x, float g, int n) { for (int i = 0; i < n; ++i) x[i] *= g; }
    static void addWithMultiply (float* d, const float* s, float g, int n) { for (int i = 0; i < n; ++i) d[i] += s[i] * g; }
    static Range<float> findMinAndMax (const float* x, int n)
    {
        float lo = 0, hi = 0;
        for (int i = 0; i < n; ++i) { lo = std::min (lo, x[i]); hi = std::max (hi, x[i]); }
        return { lo, hi };
    }
};
} // namespace juce

namespace hydra
{
inline float dbToGain (float db, float floorDb = -60.0f) noexcept { return db <= floorDb ? 0.0f : std::pow (10.0f, db * 0.05f); }
inline float gainToDb (float g) noexcept { return g > 1.0e-6f ? 20.0f * std::log10 (g) : -120.0f; }
} // namespace hydra
