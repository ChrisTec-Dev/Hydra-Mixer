int runRemoteTest();
int main() { return runRemoteTest() == 0 ? 0 : 1; }
