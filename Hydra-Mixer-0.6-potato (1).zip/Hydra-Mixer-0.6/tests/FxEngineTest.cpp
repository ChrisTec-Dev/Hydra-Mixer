// Internal FX and strip extras (Voicemeeter Potato features): the parameters exist with their defaults, follow their
// channel when channels are reordered and are reset when a channel is removed.
#include "engine/Engine.h"
#include <cstdio>

int runFxEngineTest()
{
    juce::ScopedJuceInitialiser_GUI juceInit;
    int fails = 0;
    auto check = [&] (bool c, const char* what) { std::printf ("%s %s\n", c ? "ok:  " : "FAIL:", what); if (! c) ++fails; };
    using G = hydra::Engine::Group;

    std::printf ("\n--- internal FX and strip extras ---\n");
    hydra::Engine engine;
    auto& p = engine.params;

    check (p.find ("in1.fxs.rev") != nullptr && p.find ("in1.fxs.dly") != nullptr && p.find ("in8.fxs.post") != nullptr, "FX send parameters exist on the inputs");
    check (p.get ("in1.fxs.rev").get() == -60.0f && p.get ("in1.fxs.dly").get() == -60.0f, "FX sends are off by default (-60 dB)");
    check (p.get ("in1.fxs.post").isOn(), "FX sends are post-fader by default");
    check (p.get ("bus.A1.fxr.rev").get() == 0.0f && p.get ("bus.B1.fxr.dly").get() == 0.0f, "FX returns default to 0 dB on every bus");
    check (! p.get ("in1.lim.on").isOn() && p.get ("in1.lim.thr").get() == 0.0f, "strip limiter off, threshold 0 dB");
    check (p.get ("in1.mod.amount").get() == 0.0f && ! p.get ("in1.pan3d.on").isOn() && ! p.get ("in1.pitch.on").isOn(),
           "modulation, 3D pan and pitch shifter are off by default");
    check (std::abs (engine.reverbSettings().decayS - 2.0f) < 1.0e-6f && std::abs (engine.reverbSettings().size - 1.0f) < 1.0e-6f,
           "reverb defaults: 2 s decay, size 100 %");
    check (engine.delaySettings().taps == 3 && std::abs (engine.delaySettings().timeMs - 300.0f) < 1.0e-3f, "delay defaults: 3 taps, 300 ms");
    p.get ("fx.dly.taps").set (3.0f);
    check (engine.delaySettings().taps == 4, "the taps choice (index 3) means four taps");
    p.get ("fx.dly.taps").reset();

    // The extras move with their channel when channels are reordered.
    p.get ("in1.pitch.semi").set (5.0f);
    p.get ("in1.fxs.dly").set (-12.0f);
    p.get ("in1.pan3d.x").set (0.5f);
    p.get ("bus.A1.fxr.rev").set (-9.0f);
    check (engine.reorderChannels (G::inputs, { 1, 0, 2, 3, 4, 5, 6, 7 }), "inputs reordered");
    check (p.get ("in2.pitch.semi").get() == 5.0f && p.get ("in2.fxs.dly").get() == -12.0f && p.get ("in2.pan3d.x").get() == 0.5f,
           "pitch, FX send and 3D pan moved to IN 2");
    check (p.get ("in1.pitch.semi").get() == 0.0f && p.get ("in1.fxs.dly").get() == -60.0f, "IN 1 got the settings of the other channel");
    check (engine.reorderChannels (G::hwBuses, { 1, 0, 2, 3, 4 }), "hardware buses reordered");
    check (p.get ("bus.A2.fxr.rev").get() == -9.0f && p.get ("bus.A1.fxr.rev").get() == 0.0f, "FX return moved with its bus");

    // Removing a channel resets its extras.
    const auto reset = engine.removeInput (1);
    check (! reset.empty() && p.get ("in2.pitch.semi").get() == 0.0f && p.get ("in2.fxs.dly").get() == -60.0f && p.get ("in2.pan3d.x").get() == 0.0f,
           "removing IN 2 resets its pitch, FX send and 3D pan");

    std::printf (fails == 0 ? "FX engine tests passed\n" : "FX engine tests FAILED (%d)\n", fails);
    return fails;
}
