int runSectionsTest();
int main() { return runSectionsTest() == 0 ? 0 : 1; }
