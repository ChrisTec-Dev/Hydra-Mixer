// FAKE of the few Win32 calls used by midi/Hotkeys.cpp, for tests/standalone/hotkeys_fake_test.cpp only (never part of the real build).
// The test drives the hooks and the window procedure through the `fakewin` namespace.
#pragma once
#include <cstdint>
#include <cstdlib>
#include <map>
#include <set>
#include <utility>
#include <vector>

typedef unsigned int UINT;
typedef unsigned long DWORD;
typedef short SHORT;
typedef unsigned char BYTE;
typedef wchar_t WCHAR;
typedef uintptr_t WPARAM;
typedef intptr_t LPARAM;
typedef intptr_t LRESULT;
typedef intptr_t LONG_PTR;
typedef struct HWND__* HWND;
typedef struct HINSTANCE__* HINSTANCE;
typedef struct HHOOK__* HHOOK;
typedef HINSTANCE HMODULE;
#define CALLBACK
#define WM_APP 0x8000
#define WM_HOTKEY 0x0312
#define WM_MBUTTONDOWN 0x0207
#define WM_XBUTTONDOWN 0x020B
#define WM_KEYDOWN 0x0100
#define WM_KEYUP 0x0101
#define WM_SYSKEYDOWN 0x0104
#define HC_ACTION 0
#define XBUTTON2 2
#define HIWORD(x) ((unsigned short) (((unsigned long) (x) >> 16) & 0xffff))
#define LOBYTE(x) ((BYTE) ((x) & 0xff))
#define MOD_ALT 1
#define MOD_CONTROL 2
#define MOD_SHIFT 4
#define MOD_NOREPEAT 0x4000
#define VK_SHIFT 0x10
#define VK_CONTROL 0x11
#define VK_MENU 0x12
#define HWND_MESSAGE ((HWND) -3)
#define GWLP_USERDATA (-21)
#define WH_MOUSE_LL 14
#define WH_KEYBOARD_LL 13
typedef LRESULT (*WNDPROC) (HWND, UINT, WPARAM, LPARAM);
typedef LRESULT (*HOOKPROC) (int, WPARAM, LPARAM);
struct WNDCLASSEXW
{
    UINT cbSize; UINT style; WNDPROC lpfnWndProc; int cbClsExtra; int cbWndExtra; HINSTANCE hInstance;
    void* hIcon; void* hCursor; void* hbrBackground; const wchar_t* lpszMenuName; const wchar_t* lpszClassName; void* hIconSm;
};
struct MSLLHOOKSTRUCT { long x, y; DWORD mouseData; DWORD flags; DWORD time; uintptr_t dwExtraInfo; };
struct KBDLLHOOKSTRUCT { DWORD vkCode; DWORD scanCode; DWORD flags; DWORD time; uintptr_t dwExtraInfo; };

namespace fakewin
{
struct Posted { HWND h; UINT msg; WPARAM wp; LPARAM lp; };
inline std::vector<Posted> posted;
inline WNDPROC windowProc = nullptr;
inline HWND theWindow = nullptr;
inline LONG_PTR userData = 0;
inline HOOKPROC keyboardHook = nullptr, mouseHook = nullptr;
inline std::map<int, std::pair<UINT, UINT>> registered;   // id -> (modifiers, virtual key)
inline std::set<UINT> refusedKeys;                        // RegisterHotKey fails for these (another app owns them)
inline std::set<int> down;                                // virtual keys held (modifiers)
inline int registerCalls = 0;

inline void pump()
{
    auto q = posted;
    posted.clear();
    for (auto& m : q) windowProc (m.h, m.msg, m.wp, m.lp);
}
}

typedef unsigned short ATOM;
inline ATOM RegisterClassExW (const WNDCLASSEXW* wc) { fakewin::windowProc = wc->lpfnWndProc; return 1; }
inline HWND CreateWindowExW (DWORD, const wchar_t*, const wchar_t*, DWORD, int, int, int, int, HWND, void*, HINSTANCE, void*)
{ fakewin::theWindow = (HWND) 0x1234; return fakewin::theWindow; }
inline LONG_PTR SetWindowLongPtrW (HWND, int, LONG_PTR v) { fakewin::userData = v; return 0; }
inline LONG_PTR GetWindowLongPtrW (HWND, int) { return fakewin::userData; }
inline bool DestroyWindow (HWND) { fakewin::theWindow = nullptr; return true; }
inline LRESULT DefWindowProcW (HWND, UINT, WPARAM, LPARAM) { return 0; }
inline bool PostMessageW (HWND h, UINT m, WPARAM w, LPARAM l) { fakewin::posted.push_back ({ h, m, w, l }); return true; }
inline HINSTANCE GetModuleHandleW (const wchar_t*) { return nullptr; }
inline SHORT GetAsyncKeyState (int vk) { return fakewin::down.count (vk) ? (SHORT) 0x8000 : (SHORT) 0; }
inline SHORT VkKeyScanW (WCHAR c) { return (c >= L'a' && c <= L'z') ? (SHORT) (c - L'a' + 'A') : (c >= L'A' && c <= L'Z') || (c >= L'0' && c <= L'9') ? (SHORT) c : (SHORT) -1; }
inline HHOOK SetWindowsHookExW (int id, HOOKPROC proc, HINSTANCE, DWORD)
{
    (id == WH_KEYBOARD_LL ? fakewin::keyboardHook : fakewin::mouseHook) = proc;
    return (HHOOK) (uintptr_t) (id == WH_KEYBOARD_LL ? 0x11 : 0x22);
}
inline bool UnhookWindowsHookEx (HHOOK h) { ((uintptr_t) h == 0x11 ? fakewin::keyboardHook : fakewin::mouseHook) = nullptr; return true; }
inline LRESULT CallNextHookEx (HHOOK, int, WPARAM, LPARAM) { return 0; }
inline bool RegisterHotKey (HWND, int id, UINT mods, UINT vk)
{
    ++fakewin::registerCalls;
    if (fakewin::refusedKeys.count (vk)) return false;
    fakewin::registered[id] = { mods, vk };
    return true;
}
inline bool UnregisterHotKey (HWND, int id) { return fakewin::registered.erase (id) > 0; }
