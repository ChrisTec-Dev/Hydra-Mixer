// FAKE of the few JUCE classes used by midi/Hotkeys.{h,cpp} (String, KeyPress, ModifierKeys, XmlElement, ...), for
// tests/standalone/hotkeys_fake_test.cpp only (never part of the real build). Mirrors the real signatures that matter.
#pragma once
#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <functional>
#include <map>
#include <memory>
#include <string>
#include <vector>

namespace juce
{
using juce_wchar = unsigned int;

template <class T> T jlimit (T lo, T hi, T v) { return v < lo ? lo : (v > hi ? hi : v); }
inline int roundToInt (float v) { return (int) std::lround (v); }
inline int roundToInt (double v) { return (int) std::lround (v); }
inline bool isPositiveAndBelow (int v, int hi) { return v >= 0 && v < hi; }

class String
{
public:
    String() = default;
    String (const char* t) : s (t != nullptr ? t : "") {}
    String (int v) : s (std::to_string (v)) {}
    String (float v, int decimals) { char b[64]; std::snprintf (b, sizeof b, "%.*f", decimals, (double) v); s = b; }
    bool isEmpty() const { return s.empty(); }
    bool isNotEmpty() const { return ! s.empty(); }
    bool operator== (const String& o) const { return s == o.s; }
    bool operator== (const char* o) const { return s == o; }
    bool operator!= (const String& o) const { return s != o.s; }
    bool operator< (const String& o) const { return s < o.s; }
    String& operator<< (const char* t) { s += t; return *this; }
    String& operator<< (const String& t) { s += t.s; return *this; }
    String& operator+= (const String& t) { s += t.s; return *this; }
    std::string s;
};
inline String operator+ (const String& a, const String& b) { String r; r.s = a.s + b.s; return r; }
inline String operator+ (const char* a, const String& b) { String r; r.s = std::string (a) + b.s; return r; }
inline String operator+ (const String& a, const char* b) { String r; r.s = a.s + b; return r; }

class StringArray
{
public:
    bool isEmpty() const { return items.empty(); }
    int size() const { return (int) items.size(); }
    void add (const String& s) { items.push_back (s); }
    std::vector<String> items;
};

template <class T>
struct NormalisableRange
{
    NormalisableRange() = default;
    NormalisableRange (T s, T e, T skewFactor = (T) 1) : start (s), end (e), skew (skewFactor) {}
    T start {}, end {}, skew = (T) 1;
    T convertTo0to1 (T v) const { return (T) std::pow ((double) ((v - start) / (end - start)), (double) skew); }
    T convertFrom0to1 (T n) const { return (T) (start + (end - start) * std::pow ((double) n, 1.0 / (double) skew)); }
};

class ModifierKeys
{
public:
    enum Flags { shiftModifier = 1, ctrlModifier = 2, altModifier = 4 };
    ModifierKeys() = default;
    ModifierKeys (int f) : flags (f) {}
    bool isShiftDown() const { return (flags & shiftModifier) != 0; }
    bool isCtrlDown() const { return (flags & ctrlModifier) != 0; }
    bool isAltDown() const { return (flags & altModifier) != 0; }
    int getRawFlags() const { return flags; }
    int flags = 0;
};

class KeyPress
{
public:
    // NOTE: the real JUCE does not export its "extended key" flag (0x10000) as a member of KeyPress; do not add it here.
    static constexpr int F1Key = 0x10000 | 0x70, F24Key = 0x10000 | 0x87, escapeKey = 27;
    KeyPress() = default;
    KeyPress (int code, ModifierKeys m, juce_wchar c) : keyCode (code), mods (m), textChar (c) {}
    int getKeyCode() const { return keyCode; }
    ModifierKeys getModifiers() const { return mods; }
    bool isValid() const { return keyCode != 0; }
    bool operator== (const KeyPress& o) const
    {
        return mods.getRawFlags() == o.mods.getRawFlags() && (textChar == o.textChar || textChar == 0 || o.textChar == 0)
               && (keyCode == o.keyCode || (keyCode < 128 && o.keyCode < 128 && std::tolower (keyCode) == std::tolower (o.keyCode)));
    }
    String getTextDescription() const
    {
        char b[64]; std::snprintf (b, sizeof b, "%d:#%x", mods.getRawFlags(), keyCode);
        return b;
    }
    String getTextDescriptionWithIcons() const { return getTextDescription(); }
    static KeyPress createFromDescription (const String& d)
    {
        int m = 0, c = 0;
        if (std::sscanf (d.s.c_str(), "%d:#%x", &m, &c) != 2) return {};
        return KeyPress (c, ModifierKeys (m), 0);
    }
    int keyCode = 0;
    ModifierKeys mods;
    juce_wchar textChar = 0;
};

class XmlElement
{
public:
    explicit XmlElement (const char* n) : name (n) {}
    XmlElement* createNewChildElement (const char* n) { children.push_back (std::make_unique<XmlElement> (n)); return children.back().get(); }
    void setAttribute (const char* n, const String& v) { attrs[n] = v.s; }
    void setAttribute (const char* n, const char* v) { attrs[n] = v; }
    void setAttribute (const char* n, int v) { attrs[n] = std::to_string (v); }
    void setAttribute (const char* n, double v) { char b[64]; std::snprintf (b, sizeof b, "%.9g", v); attrs[n] = b; }
    bool hasAttribute (const char* n) const { return attrs.count (n) > 0; }
    String getStringAttribute (const char* n, const char* def = "") const { auto it = attrs.find (n); return it == attrs.end() ? String (def) : String (it->second.c_str()); }
    int getIntAttribute (const char* n, int def = 0) const { auto it = attrs.find (n); return it == attrs.end() ? def : std::atoi (it->second.c_str()); }
    double getDoubleAttribute (const char* n, double def = 0.0) const { auto it = attrs.find (n); return it == attrs.end() ? def : std::atof (it->second.c_str()); }
    std::vector<XmlElement*> getChildWithTagNameIterator (const char* tag) const
    {
        std::vector<XmlElement*> out;
        for (auto& c : children) if (c->name == tag) out.push_back (c.get());
        return out;
    }
    std::string name;
    std::map<std::string, std::string> attrs;
    std::vector<std::unique_ptr<XmlElement>> children;
};

struct MessageManager
{
    static MessageManager* getInstanceWithoutCreating() { static MessageManager m; return &m; }
};
} // namespace juce
