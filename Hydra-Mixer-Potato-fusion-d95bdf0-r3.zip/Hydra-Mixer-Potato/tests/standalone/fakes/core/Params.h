// Fake of core/Params.h for the Hotkeys test: the same members and behaviour as the real Param that Hotkeys uses.
#pragma once
#include "juce_stub.h"

namespace hydra
{
enum class ParamType { Continuous, Toggle };

class Param
{
public:
    Param (juce::String paramId, juce::String displayName, ParamType t, juce::NormalisableRange<float> r, float def, juce::String unitSuffix = {})
        : id (std::move (paramId)), name (std::move (displayName)), type (t), range (r), defaultValue (def), unit (std::move (unitSuffix)), value (def) {}
    const juce::String id, name;
    const ParamType type;
    const juce::NormalisableRange<float> range;
    const float defaultValue;
    const juce::String unit;
    juce::StringArray choices;
    float get() const noexcept { return value.load(); }
    bool isOn() const noexcept { return get() >= 0.5f; }
    float getNormalised() const noexcept { return range.convertTo0to1 (get()); }
    void set (float v, bool = false) noexcept
    {
        v = juce::jlimit (range.start, range.end, v);
        if (type == ParamType::Toggle) v = v >= 0.5f ? 1.0f : 0.0f;
        else if (! choices.isEmpty()) v = (float) juce::roundToInt (v);
        value.store (v);
    }
    void setNormalised (float n, bool = false) noexcept { set (range.convertFrom0to1 (juce::jlimit (0.0f, 1.0f, n))); }
    void toggle (bool = false) noexcept { set (isOn() ? 0.0f : 1.0f); }
private:
    std::atomic<float> value;
};

class ParamRegistry
{
public:
    Param& addLevel (const char* id, float lo, float hi, float def, const char* unit = "", float skew = 1.0f)
    { params.push_back (std::make_unique<Param> (id, id, ParamType::Continuous, juce::NormalisableRange<float> (lo, hi, skew), def, unit)); return *params.back(); }
    Param& addSwitch (const char* id)
    { params.push_back (std::make_unique<Param> (id, id, ParamType::Toggle, juce::NormalisableRange<float> (0.0f, 1.0f), 0.0f)); return *params.back(); }
    Param& addChoice (const char* id, int n)
    { auto& p = addLevel (id, 0.0f, (float) (n - 1), 0.0f); for (int i = 0; i < n; ++i) p.choices.add (juce::String (i)); return p; }
    Param* find (const juce::String& id) const { for (auto& p : params) if (p->id == id) return p.get(); return nullptr; }
    std::vector<std::unique_ptr<Param>> params;
};
} // namespace hydra
