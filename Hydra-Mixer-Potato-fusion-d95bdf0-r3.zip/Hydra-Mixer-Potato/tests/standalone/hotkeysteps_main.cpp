int runHotkeyStepsTest();
int main() { return runHotkeyStepsTest() == 0 ? 0 : 1; }
