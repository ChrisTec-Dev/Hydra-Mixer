// Sections of a channel (core/Sections.h): parsing of parameter ids, copy / paste of a section, scope of a scene.
// Only the standard library is used, so the same file also runs without JUCE (tests/standalone/run.sh).
#include "core/Sections.h"

#include <cstdio>
#include <cstdlib>

namespace
{
struct P { std::string id; float value; };

/** The parameter ids of the engine for the channels the tests use (names as registered in Engine::createParams). */
std::vector<P> makeParams()
{
    static const char* inputNames[] = {
        "active", "gain", "trim", "pan", "mute", "solo", "mono", "phase",
        "corr.on", "gate.on", "gate.thr", "gate.range", "gate.attack", "gate.hold", "gate.release", "gate.sc.on", "gate.sc.freq", "gate.voice", "gate.voice.thr",
        "comp.on", "comp.input", "comp.thr", "comp.ratio", "comp.knee", "comp.attack", "comp.release", "comp.makeup", "comp.auto",
        "dn.on", "dn.amount", "dn.mode", "fx.bypass", "sync", "delay",
        "fxs.rev", "fxs.dly", "fxs.post", "lim.on", "lim.thr", "mod.amount", "mod.rate", "mod.depth",
        "pan3d.on", "pan3d.x", "pan3d.y", "pitch.on", "pitch.semi", "pitch.mix",
        "eq.on", "eq.b1.on", "eq.b1.type", "eq.b1.gain", "eq.b1.freq", "eq.b1.q", "eq.b8.gain",
        "route.A1", "route.B1", "send.A1", "send.B1" };
    static const char* busNames[] = {
        "active", "gain", "mute", "mono", "lim.on", "lim.ceiling", "fx.bypass", "sel", "sync", "delay",
        "fxr.rev", "fxr.dly", "eq.on", "eq.b1.on", "eq.b1.gain", "corr.on" };
    std::vector<P> v;
    float x = 1.0f;
    for (const char* ch : { "in1", "in2", "in3" })
        for (auto* n : inputNames) v.push_back ({ std::string (ch) + "." + n, x++ });
    for (const char* ch : { "bus.A1", "bus.B1" })
        for (auto* n : busNames) v.push_back ({ std::string (ch) + "." + n, x++ });
    for (const char* g : { "fx.rev.size", "fx.rev.decay", "fx.dly.time", "mon.on", "mon.bus", "scene.1", "scene.next" })
        v.push_back ({ g, x++ });
    return v;
}

float valueOf (const std::vector<P>& v, const std::string& id)
{
    for (auto& p : v) if (p.id == id) return p.value;
    return -1.0f;
}
} // namespace

int runSectionsTest()
{
    int fails = 0;
    auto check = [&] (bool c, const char* what) { std::printf ("%s %s\n", c ? "ok:  " : "FAIL:", what); if (! c) ++fails; };
    using namespace hydra::sections;

    std::printf ("\n--- Parameter ids ---\n");
    {
        auto r = parse ("in3.gate.thr");
        check (r.kind == Kind::input && r.channel == "in3" && r.name == "gate.thr" && r.section == "gate", "in3.gate.thr: input 3, gate");
        r = parse ("in12.eq.b3.gain");
        check (r.channel == "in12" && r.name == "eq.b3.gain" && r.section == "eq", "in12.eq.b3.gain: equalizer of input 12");
        check (parse ("in1.route.A2").section == "routing" && parse ("in1.send.B1").section == "routing", "route / send ids are the routing section");
        check (parse ("in2.pan3d.x").section == "pan3d" && parse ("in2.pan").section == "mix", "pan3d is not mistaken for pan");
        check (parse ("in2.gate.voice.thr").section == "gate" && parse ("in2.gate.sc.freq").section == "gate", "nested names stay in their section");
        check (parse ("in2.delay").section == "sync" && parse ("in2.sync").section == "sync", "sync delay and its auto switch");
        check (parse ("in1.fx.bypass").section.empty() && parse ("in1.active").section.empty(), "plugin bypass and slot in use belong to no section");
        r = parse ("bus.A1.lim.on");
        check (r.kind == Kind::bus && r.channel == "bus.A1" && r.name == "lim.on" && r.section == "lim", "bus.A1.lim.on: bus A1, limiter");
        check (parse ("in3.corr.on").section == "corr" && parse ("bus.A1.corr.on").section == "corr" && parse ("in3.corr.state").section == "corr",
               "Correction: its switch and its state belong to the corr section, on inputs and on buses");
        check (parse ("bus.B3.fxr.rev").section == "fxr" && parse ("bus.A1.gain").section == "mix" && parse ("bus.A1.eq.b2.freq").section == "eq", "bus sections");
        check (parse ("bus.A1.sel").section.empty(), "SEL of a bus belongs to no section");
        r = parse ("fx.rev.size");
        check (r.kind == Kind::global && r.channel.empty() && r.name == "fx.rev.size" && r.section == "fx", "fx.rev.size: global, internal FX settings");
        check (parse ("mon.on").section == "monitor" && parse ("scene.1").section.empty() && parse ("scene.next").section.empty(), "monitor, scene triggers");
        check (parse ("in").kind == Kind::global && parse ("in.gain").kind == Kind::global && parse ("inx.gain").kind == Kind::global
               && parse ("in3").kind == Kind::global && parse ("in3.").kind == Kind::global, "malformed input ids are global");
        check (parse ("bus").kind == Kind::global && parse ("bus.A1").kind == Kind::global && parse ("bus..gain").kind == Kind::global
               && parse ("bus.A1.").kind == Kind::global && parse ("").kind == Kind::global, "malformed bus ids are global");
        check (parse ("in1.gate.thr").section == "gate" && parse ("IN1.gate.thr").kind == Kind::global, "ids are case sensitive, like the registry");
        check (inputKey (0) == "in1" && inputKey (15) == "in16" && busKey ("A2") == "bus.A2", "channel keys");
    }
    {
        // every name the engine registers is in a section, except the three that are not settings of the sound
        const auto params = makeParams();
        std::set<std::string> unassigned;
        for (auto& p : params)
        {
            auto r = parse (p.id);
            if (r.kind != Kind::global && r.section.empty()) unassigned.insert (r.name);
        }
        check (unassigned == std::set<std::string> { "active", "fx.bypass", "sel" }, "only active, fx.bypass and sel belong to no section");
        const auto all = allSections();
        std::set<std::string> ids;
        bool titles = true;
        for (auto& [id, title] : all) { ids.insert (id); titles = titles && ! title.empty(); }
        check (all.size() == ids.size() && titles && all.size() == 16, "allSections lists each id once with a title");
        bool every = true;
        for (auto& d : defs()) every = every && ids.count (d.id) > 0;
        check (every, "every definition is reachable by its id");
        check (titleOf ("eq") == "Equalizer" && titleOf ("corr") == "Correction" && titleOf ("nope") == "nope", "titleOf");
        check (allSections()[2].first == "corr" && allSections()[3].first == "eq", "Correction comes right before the equalizer in the lists");
    }

    std::printf ("\n--- Copy and paste of a section ---\n");
    {
        auto params = makeParams();
        auto idOf = [] (const P& p) { return p.id; };
        auto valOf = [] (const P& p) { return p.value; };

        const auto gate = copyFrom (params, idOf, valOf, Kind::input, "in1", "gate");
        check (gate.valid() && gate.section == "gate" && gate.kind == Kind::input, "copy: a gate clip");
        check (gate.values.size() == 10 && gate.values.count ("thr") == 0 && gate.values.count ("gate.thr") == 1, "copy: the 10 gate parameters, by name");
        check (gate.values.at ("gate.thr") == valueOf (params, "in1.gate.thr"), "copy: the values of the source channel");
        check (gate.values.count ("comp.thr") == 0 && gate.values.count ("gain") == 0, "copy: nothing from other sections");

        auto pasted = valuesFor (gate, Kind::input, "gate");
        check (pasted.size() == gate.values.size(), "paste into a gate: all values");
        check (valuesFor (gate, Kind::input, "comp").empty(), "paste of a gate clip into a compressor: nothing");
        check (valuesFor (gate, Kind::bus, "gate").empty(), "paste of an input clip into a bus: nothing");

        // Writing the pasted values into another channel changes exactly the section.
        auto target = params;
        for (auto& [name, v] : pasted)
            for (auto& p : target) if (p.id == "in2." + name) p.value = v;
        int changed = 0;
        bool onlyGate = true;
        for (size_t i = 0; i < params.size(); ++i)
            if (params[i].value != target[i].value)
            {
                ++changed;
                onlyGate = onlyGate && parse (params[i].id).channel == "in2" && parse (params[i].id).section == "gate";
            }
        check (changed == 10 && onlyGate, "paste into input 2: the 10 gate values change, nothing else");
        check (valueOf (target, "in2.gate.thr") == valueOf (params, "in1.gate.thr") && valueOf (target, "in3.gate.thr") == valueOf (params, "in3.gate.thr"),
               "input 2 got the gate of input 1, input 3 is untouched");

        const auto eqClip = copyFrom (params, idOf, valOf, Kind::input, "in3", "eq");
        check (eqClip.values.size() == 7 && eqClip.values.count ("eq.on") == 1 && eqClip.values.count ("eq.b8.gain") == 1, "copy: the equalizer (on switch and bands)");

        const auto busLim = copyFrom (params, idOf, valOf, Kind::bus, "bus.A1", "lim");
        check (busLim.values.size() == 2 && busLim.values.count ("lim.ceiling") == 1, "copy: limiter of a bus");
        check (valuesFor (busLim, Kind::bus, "lim").size() == 2 && valuesFor (busLim, Kind::input, "lim").empty(), "a bus limiter does not go into an input");

        const auto proc = copyFrom (params, idOf, valOf, Kind::input, "in1", kAllProcessing);
        check (proc.values.count ("corr.on") && proc.values.count ("gate.thr") && proc.values.count ("comp.thr") && proc.values.count ("eq.b1.gain") && proc.values.count ("fxs.rev")
               && proc.values.count ("lim.thr") && proc.values.count ("mod.rate") && proc.values.count ("pitch.semi") && proc.values.count ("pan3d.x")
               && proc.values.count ("dn.amount"), "copy all: every processing section");
        check (! proc.values.count ("gain") && ! proc.values.count ("mute") && ! proc.values.count ("route.A1") && ! proc.values.count ("send.B1")
               && ! proc.values.count ("delay") && ! proc.values.count ("sync") && ! proc.values.count ("active") && ! proc.values.count ("fx.bypass"),
               "copy all: not the fader, mute, routing, sync delay, slot or plugin bypass");
        check (valuesFor (proc, Kind::input).size() == proc.values.size() && valuesFor (proc, Kind::input, kAllProcessing).size() == proc.values.size(),
               "paste all: everything in the clip");
        const auto fromAll = valuesFor (proc, Kind::input, "comp");
        bool allComp = ! fromAll.empty();
        for (auto& [n, v] : fromAll) allComp = allComp && sectionOf (Kind::input, n) == "comp";
        check (allComp && fromAll.size() == 9, "one section can be taken out of a copy-all clip (the 9 compressor parameters)");
        check (valuesFor (gate, Kind::input, kAllProcessing).size() == gate.values.size(), "a section clip pasted with 'all' still only holds its own section");

        const auto none = copyFrom (params, idOf, valOf, Kind::input, "in9", "gate");
        check (! none.valid(), "copy from a channel that does not exist: empty clip");
        check (! copyFrom (params, idOf, valOf, Kind::bus, "in1", "gate").valid(), "copy asking for the wrong kind: empty clip");

        // Pasting must work between channels whose ids differ in the middle only (route / send names carry bus codes).
        const auto routing = copyFrom (params, idOf, valOf, Kind::input, "in1", "routing");
        check (routing.values.size() == 4 && routing.values.count ("route.B1") == 1 && routing.values.count ("send.A1") == 1, "routing clip holds route.* and send.*");
    }

    std::printf ("\n--- Settings that are not parameters (the Correction profile) ---\n");
    {
        auto params = makeParams();
        auto idOf = [] (const P& p) { return p.id; };
        auto valOf = [] (const P& p) { return p.value; };
        check (hasState ("corr") && ! hasState ("eq") && ! hasState ("") && stateSections().size() == 1 && stateSections()[0] == "corr", "only Correction has state of its own");
        check (stateId ("in3", "corr") == "in3.corr.state" && stateId ("bus.A1", "corr") == "bus.A1.corr.state", "ids that a scope can be asked about");
        check (isProcessingSection ("corr"), "Correction is part of 'all sections'");

        auto clip = copyFrom (params, idOf, valOf, Kind::input, "in1", "corr");
        check (clip.values.size() == 1 && clip.values.count ("corr.on") == 1, "the switch is copied as a value");
        clip.states["corr"] = "<CORRECTION name=\"Room\"/>";
        check (clip.valid(), "a clip with state is valid");
        Clip onlyState;
        onlyState.states["corr"] = "";
        check (onlyState.valid() && ! Clip {}.valid(), "an empty profile still counts: pasting it clears the target");

        auto st = statesFor (clip, Kind::input, "corr");
        check (st.size() == 1 && st[0].first == "corr" && st[0].second.find ("Room") != std::string::npos, "pasting Correction brings the profile");
        check (statesFor (clip, Kind::input, "eq").empty() && statesFor (clip, Kind::bus, "corr").empty(), "not into another section, not into another kind of channel");
        check (statesFor (clip, Kind::input).size() == 1 && statesFor (clip, Kind::input, kAllProcessing).size() == 1, "'paste all' brings it as well");

        auto all = copyFrom (params, idOf, valOf, Kind::input, "in1", kAllProcessing);
        all.states["corr"] = "x";
        check (statesFor (all, Kind::input, "corr").size() == 1 && statesFor (all, Kind::input, "gate").empty(), "from a copy-all clip: the profile goes with Correction only");
        check (all.values.count ("corr.on") == 1, "and the copy-all clip holds the switch");

        Scope corr;
        corr.sections = { "corr" };
        check (corr.covers (stateId ("in3", "corr")) && corr.covers (stateId ("bus.A1", "corr")) && corr.covers ("in2.corr.on"), "a Correction scope covers the profile of every channel");
        check (! corr.covers (stateId ("in3", "eq")) && ! Scope { { "eq" }, {} }.covers (stateId ("in3", "corr")), "and no other scope covers it");
        Scope oneIn;
        oneIn.sections = { "corr" };
        oneIn.channels = { "in2" };
        check (oneIn.covers (stateId ("in2", "corr")) && ! oneIn.covers (stateId ("in1", "corr")) && ! oneIn.covers (stateId ("bus.A1", "corr")), "of input 2 only");
        check (Scope {}.covers (stateId ("in1", "corr")) && Scope { {}, { "in1" } }.covers (stateId ("in1", "corr")) && ! Scope { {}, { "in2" } }.covers (stateId ("in1", "corr")),
               "everything covers it, a channel scope covers that channel's");
        check (describeSections (Scope { { "corr", "eq" }, {} }) == "Correction, Equalizer", "described in the order of the lists");
    }

    std::printf ("\n--- Scope of a scene ---\n");
    {
        const auto params = makeParams();
        Scope all;
        check (all.isAll(), "the default scope covers everything");
        bool everything = true;
        for (auto& p : params) everything = everything && all.covers (p.id);
        check (everything, "default scope: every parameter, also unknown ones");
        check (all.covers ("whatever") && all.covers (parse ("scene.1")), "default scope: also ids that mean nothing");

        Scope eq;
        eq.sections = { "eq" };
        check (eq.covers ("in1.eq.b1.gain") && eq.covers ("in16.eq.on") && eq.covers ("bus.A2.eq.b3.freq"), "equalizer scope: the equalizer of every input and bus");
        check (! eq.covers ("in1.gate.thr") && ! eq.covers ("in1.gain") && ! eq.covers ("bus.A1.gain"), "equalizer scope: nothing else");
        check (! eq.covers ("fx.rev.size") && ! eq.covers ("scene.1") && ! eq.covers ("in1.fx.bypass"), "equalizer scope: not the global parameters, not unassigned ones");

        Scope eqOne = eq;
        eqOne.channels = { "in2" };
        check (eqOne.covers ("in2.eq.b1.gain") && ! eqOne.covers ("in1.eq.b1.gain") && ! eqOne.covers ("bus.A1.eq.on") && ! eqOne.covers ("in2.gate.on"),
               "equalizer of input 2 only");

        Scope chan;
        chan.channels = { "in2", "bus.A1" };
        check (chan.covers ("in2.gate.thr") && chan.covers ("in2.fx.bypass") && chan.covers ("bus.A1.gain") && ! chan.covers ("in1.gain") && ! chan.covers ("bus.B1.gain"),
               "channel scope: everything of those channels (also parameters without a section)");
        check (! chan.covers ("fx.rev.size") && ! chan.covers ("mon.on") && ! chan.covers ("scene.1"), "channel scope: not the global parameters");

        Scope fx;
        fx.sections = { "fx", "monitor" };
        check (fx.covers ("fx.rev.size") && fx.covers ("fx.dly.time") && fx.covers ("mon.bus") && ! fx.covers ("in1.eq.on") && ! fx.covers ("scene.next"),
               "internal FX settings scope covers the global fx.* and mon.* only");

        Scope mixed;
        mixed.sections = { "gate", "fx" };
        mixed.channels = { "in1" };
        check (mixed.covers ("in1.gate.on") && mixed.covers ("fx.rev.size") && ! mixed.covers ("in2.gate.on") && ! mixed.covers ("in1.eq.on"),
               "a global section named in the scope is covered whatever the channels are");

        // Counting: how many of the 3 inputs' parameters an equalizer scope covers.
        int n = 0;
        for (auto& p : params) if (eq.covers (p.id)) ++n;
        check (n == 3 * 7 + 2 * 3, "equalizer scope on the test parameters: 21 input + 6 bus values");

        check (all == Scope {} && ! (all == eq) && eq == Scope { { "eq" }, {} }, "scopes compare");
    }
    {
        Scope s;
        s.sections = { "gate", "eq", "lim" };
        s.channels = { "in1", "bus.A1" };
        check (join (s.sections) == "eq,gate,lim" && join (s.channels) == "bus.A1,in1", "join: sorted, comma separated");
        Scope back;
        back.sections = split (join (s.sections));
        back.channels = split (join (s.channels));
        check (back == s, "text round trip");
        check (split ("").empty() && split (" , ,").empty() && split (" eq , gate ").size() == 2 && split ("eq,eq,eq").size() == 1, "split: blanks, duplicates");
        check (describeSections (s) == "Equalizer, Gate, Limiter", "describeSections follows the order of the sections");
        check (describeSections (Scope {}).empty(), "describeSections of everything is empty");
    }

    std::printf (fails == 0 ? "Sections tests passed\n" : "Sections tests FAILED (%d)\n", fails);
    return fails;
}
