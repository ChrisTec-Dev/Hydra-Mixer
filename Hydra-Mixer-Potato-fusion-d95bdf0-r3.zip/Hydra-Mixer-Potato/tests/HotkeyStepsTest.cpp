// Steps of the level shortcuts and media keys (core/HotkeySteps.h). Standard library only (tests/standalone/run.sh).
#include "core/HotkeySteps.h"

#include <cstdio>
#include <set>
#include <string>

int runHotkeyStepsTest()
{
    int fails = 0;
    auto check = [&] (bool c, const char* what) { std::printf ("%s %s\n", c ? "ok:  " : "FAIL:", what); if (! c) ++fails; };
    using namespace hydra::hotkeysteps;
    auto near = [] (double a, double b) { return std::abs (a - b) < 1.0e-9; };

    std::printf ("\n--- Media keys ---\n");
    check (isMediaVk (0xAF) && isMediaVk (0xAE) && isMediaVk (0xAD), "Volume Up, Down and Mute are media keys");
    check (isMediaVk (0xA6) && isMediaVk (0xB7) && ! isMediaVk (0xA5) && ! isMediaVk (0xB8), "the range is 0xA6 to 0xB7");
    check (! isMediaVk ('A') && ! isMediaVk (0x70) && ! isMediaVk (0) && ! isMediaVk (0x11), "letters, F1, nothing and Ctrl are not");
    check (std::string (mediaKeyName (0xAF)) == "Volume Up" && std::string (mediaKeyName (0xAE)) == "Volume Down" && std::string (mediaKeyName (0xAD)) == "Volume Mute",
           "the names of the G610 roller keys");
    bool named = true;
    std::set<std::string> names;
    for (unsigned vk = 0xA6; vk <= 0xB7; ++vk) { named = named && mediaKeyName (vk) != nullptr; if (mediaKeyName (vk)) names.insert (mediaKeyName (vk)); }
    check (named && names.size() == 18, "every media key has its own name");
    check (mediaKeyName (0xA5) == nullptr && mediaKeyName (0xB8) == nullptr && mediaKeyName ('A') == nullptr, "no name outside the range");

    std::printf ("\n--- Steps ---\n");
    check (near (defaultAmount (true), 1.0) && near (defaultAmount (false), 0.02), "default: 1 dB, or 2 % of the range");
    check (amountChoices (true).size() == 5 && amountChoices (false).size() == 4, "the menu offers 5 steps in dB, 4 in percent");
    bool containsDefault = false;
    for (double a : amountChoices (true)) containsDefault = containsDefault || near (a, defaultAmount (true));
    bool containsDefaultPct = false;
    for (double a : amountChoices (false)) containsDefaultPct = containsDefaultPct || near (a, defaultAmount (false));
    check (containsDefault && containsDefaultPct, "the default is one of the choices (so it shows ticked)");
    const auto dbChoices = amountChoices (true), pctChoices = amountChoices (false);
    check (std::is_sorted (dbChoices.begin(), dbChoices.end()) && std::is_sorted (pctChoices.begin(), pctChoices.end()), "the choices are in increasing order");

    check (near (steppedNative (-10.0, -60.0, 12.0, +1, 1.0), -9.0), "a fader at -10 dB goes to -9 dB");
    check (near (steppedNative (-10.0, -60.0, 12.0, -1, 1.0), -11.0), "and to -11 dB");
    check (near (steppedNative (-10.0, -60.0, 12.0, +1, 0.5), -9.5), "half a dB");
    check (near (steppedNative (11.5, -60.0, 12.0, +1, 1.0), 12.0), "stops at the top of the fader");
    check (near (steppedNative (-59.5, -60.0, 12.0, -1, 1.0), -60.0), "stops at the bottom");
    check (near (steppedNative (12.0, -60.0, 12.0, +1, 6.0), 12.0) && near (steppedNative (-60.0, -60.0, 12.0, -1, 6.0), -60.0), "no overshoot with a big step");
    check (near (steppedNative (0.0, 12.0, -60.0, +1, 1.0), 1.0), "a reversed range works the same");
    check (near (steppedNative (0.0, -60.0, 12.0, 0, 1.0), 1.0), "direction 0 counts as up");
    double v = -30.0;
    for (int i = 0; i < 10; ++i) v = steppedNative (v, -60.0, 12.0, +1, 1.0);
    check (near (v, -20.0), "ten presses of 1 dB add 10 dB");
    for (int i = 0; i < 100; ++i) v = steppedNative (v, -60.0, 12.0, -1, 1.0);
    check (near (v, -60.0), "a hundred presses down stop at -60 dB");

    check (near (steppedNormalised (0.5, +1, 0.02), 0.52) && near (steppedNormalised (0.5, -1, 0.02), 0.48), "knob: 2 % of the range");
    check (near (steppedNormalised (0.99, +1, 0.05), 1.0) && near (steppedNormalised (0.01, -1, 0.05), 0.0), "knob: kept between 0 and 1");
    check (near (steppedNormalised (0.0, -1, 0.1), 0.0) && near (steppedNormalised (1.0, +1, 0.1), 1.0), "knob: already at the end stays there");

    std::printf (fails == 0 ? "Hotkey step tests passed\n" : "Hotkey step tests FAILED (%d)\n", fails);
    return fails;
}
