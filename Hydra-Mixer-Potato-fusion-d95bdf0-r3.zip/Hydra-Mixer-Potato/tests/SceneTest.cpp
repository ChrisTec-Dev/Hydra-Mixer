// Scenes (state/Scenes): store / recall, unsaved-change detection, triggers, remove / move, persistence.
#include "state/Session.h"
#include "state/SectionState.h"
#include <cstdio>

int runSceneTest()
{
    juce::ScopedJuceInitialiser_GUI juceInit;
    hydra::ParamPoller poller;
    int fails = 0;
    auto check = [&] (bool c, const char* what) { std::printf ("%s %s\n", c ? "ok:  " : "FAIL:", what); if (! c) ++fails; };

    hydra::Engine engine;
    hydra::SceneBank bank (engine);
    auto& fader = engine.params.get ("in1.gain");
    auto& mute = engine.params.get ("in2.mute");
    auto& active = engine.params.get ("in3.active");

    fader.set (-6.0f);
    const int a = bank.addFromMixer ("Talk");
    fader.set (-20.0f);
    mute.set (1.0f);
    const int b = bank.addFromMixer ("Music");
    check (a == 0 && b == 1 && bank.size() == 2 && bank.getCurrent() == 1, "two scenes added, the last is current");

    active.set (0.0f);
    bank.recall (a);
    check (fader.get() == -6.0f && ! mute.isOn(), "recall restores the stored values (defaults included)");
    check (! active.isOn(), "recall does not add or remove channels");
    active.set (1.0f);
    check (! bank.differsFromMixer (a), "no unsaved changes right after recall");

    fader.set (-3.0f);
    check (bank.differsFromMixer (a) && bank.countDifferences (a) == 1, "an edit shows as unsaved change");
    bank.recall (b);   // switching scenes never asks
    check (fader.get() == -20.0f && mute.isOn(), "switching discards the unsaved edit");
    bank.recall (a);
    check (fader.get() == -6.0f, "the edit was not stored in the scene");
    fader.set (-9.0f);
    bank.store (a);
    bank.recall (b);
    bank.recall (a);
    check (fader.get() == -9.0f, "store saves the edit");

    // Triggers (MIDI / shortcuts): the parameter is switched on, the timer recalls and resets it.
    engine.sceneRecall[1]->set (1.0f, true);
    juce::MessageManager::getInstance()->runDispatchLoopUntil (120);
    check (bank.getCurrent() == 1 && mute.isOn() && ! engine.sceneRecall[1]->isOn(), "trigger parameter recalls the scene");
    engine.sceneNext->set (1.0f, true);
    juce::MessageManager::getInstance()->runDispatchLoopUntil (120);
    check (bank.getCurrent() == 0 && ! mute.isOn(), "next scene wraps around");
    engine.sceneRecall[5]->set (1.0f, true);
    juce::MessageManager::getInstance()->runDispatchLoopUntil (120);
    check (bank.getCurrent() == 0 && ! engine.sceneRecall[5]->isOn(), "trigger of an empty slot is ignored");

    // Remove / move: the triggers of the following scenes move with them.
    bank.addFromMixer ("Third");
    hydra::Param* removed = nullptr;
    auto moves = bank.remove (0, removed);
    check (bank.size() == 2 && bank.get (0).name == "Music" && removed == engine.sceneRecall[0], "remove shifts the scenes up");
    check (moves.size() == 2 && moves[0].first == engine.sceneRecall[1] && moves[0].second == engine.sceneRecall[0],
           "remove returns the trigger moves");
    moves = bank.move (1, 0);
    check (bank.get (0).name == "Third" && bank.get (1).name == "Music" && moves.size() == 2, "move reorders the scenes");

    // Persistence: with the session, and as an export file.
    auto xml = bank.toXml();
    hydra::SceneBank loaded (engine);
    loaded.fromXml (*xml, false);
    check (loaded.size() == 2 && loaded.get (1).name == "Music" && loaded.get (1).values.at ("in2.mute") == 1.0f,
           "scenes survive save / load");
    auto file = juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("hydra_scene_test.hydrascenes");
    check (bank.exportTo (file, { 1 }), "export writes a file");
    juce::String err;
    check (loaded.importFrom (file, err) == 1 && loaded.size() == 3 && loaded.get (2).name == "Music", "import appends");
    file.deleteFile();

    // Session round trip
    {
        auto dir = juce::File::getSpecialLocation (juce::File::tempDirectory).getChildFile ("hydra_scene_session");
        dir.deleteRecursively();
        dir.createDirectory();
        hydra::MidiMapper midi (engine.params);
        hydra::Session session (engine, midi, dir);
        session.scenes.addFromMixer ("Saved");
        check (session.save (dir.getChildFile ("s.xml")), "session with scenes saved");
        hydra::Session other (engine, midi, dir);
        other.load (dir.getChildFile ("s.xml"));
        check (other.scenes.size() == 1 && other.scenes.get (0).name == "Saved", "session load restores the scenes");
        dir.deleteRecursively();
    }

    // Scope: a scene that covers some sections / channels leaves the rest of the mixer alone.
    {
        namespace S = hydra::sections;
        hydra::SceneBank part (engine);
        auto& fader1 = engine.params.get ("in1.gain");
        auto& gate1 = engine.params.get ("in1.gate.thr");
        auto& gate2 = engine.params.get ("in2.gate.thr");
        auto& eq1 = engine.params.get ("in1.eq.b1.gain");
        auto& busCeil = engine.params.get ("bus.A1.lim.ceiling");
        fader1.set (-4.0f); gate1.set (-40.0f); gate2.set (-45.0f); eq1.set (5.0f); busCeil.set (-3.0f);

        S::Scope gateScope;
        gateScope.sections = { "gate" };
        const int g = part.addFromMixer ("Gate only", gateScope);
        check (part.get (g).values.count ("in1.gate.thr") == 1 && part.get (g).values.count ("in2.gate.thr") == 1
               && part.get (g).values.count ("in1.gain") == 0 && part.get (g).values.count ("in1.eq.b1.gain") == 0
               && part.get (g).values.count ("bus.A1.lim.ceiling") == 0, "a gate scene stores the gates and nothing else");

        fader1.set (-10.0f); gate1.set (-20.0f); gate2.set (-25.0f); eq1.set (-2.0f);
        part.recall (g);
        check (gate1.get() == -40.0f && gate2.get() == -45.0f, "recall restores the gates of every input");
        check (fader1.get() == -10.0f && eq1.get() == -2.0f && busCeil.get() == -3.0f, "recall leaves the fader, the equalizer and the bus alone");

        check (! part.differsFromMixer (g), "no difference right after recall");
        gate1.set (-30.0f);
        fader1.set (-11.0f);
        check (part.countDifferences (g) == 1, "only the covered parameters count as differences");
        part.store (g);
        gate1.set (-35.0f);
        part.recall (g);
        check (gate1.get() == -30.0f && fader1.get() == -11.0f && part.get (g).values.count ("in1.gain") == 0, "store keeps the scope");

        // A section that was at its default is restored to the default, not skipped.
        gate2.reset();
        part.store (g);
        gate2.set (-12.0f);
        part.recall (g);
        check (gate2.get() == gate2.defaultValue, "a covered parameter at its default is reset by the recall");

        S::Scope oneInput;
        oneInput.channels = { "in2" };
        engine.params.get ("in2.pan").set (0.5f);
        const int c = part.addFromMixer ("Input 2", oneInput);
        check (part.get (c).values.count ("in2.pan") == 1 && part.get (c).values.count ("in1.pan") == 0 && part.get (c).values.count ("bus.A1.gain") == 0,
               "a channel scene stores that channel only");
        engine.params.get ("in2.pan").set (-0.5f);
        fader1.set (-15.0f);
        part.recall (c);
        check (engine.params.get ("in2.pan").get() == 0.5f && fader1.get() == -15.0f, "a channel scene changes that channel only");

        // Widening takes the mixer as it is; narrowing drops the values.
        eq1.set (7.0f);
        S::Scope both = gateScope;
        both.sections.insert ("eq");
        part.setScope (g, both);
        check (part.get (g).values.count ("in1.eq.b1.gain") == 1 && part.get (g).values.at ("in1.eq.b1.gain") == 7.0f, "widening a scene stores the current mixer values");
        eq1.set (0.0f);
        part.recall (g);
        check (eq1.get() == 7.0f, "the widened scene restores them");
        part.setScope (g, gateScope);
        check (part.get (g).values.count ("in1.eq.b1.gain") == 0 && part.get (g).scope == gateScope, "narrowing a scene drops the values it no longer covers");
        part.setScope (g, S::Scope {});
        check (part.get (g).scope.isAll() && part.get (g).values.count ("in1.gain") == 1, "back to everything: the whole mixer is stored");

        // Persistence and older files.
        part.setScope (g, gateScope);
        auto xml = part.toXml();
        hydra::SceneBank again (engine);
        again.fromXml (*xml, false);
        check (again.size() == part.size() && again.get (g).scope == gateScope && again.get (c).scope == oneInput, "the scope survives save / load");
        check (again.get (g).values == part.get (g).values && again.get (c).values == part.get (c).values, "so do the values");
        check (loaded.get (0).scope.isAll(), "scenes of older sessions cover everything");
        auto copy = again.duplicate (g);
        check (copy >= 0 && again.get (copy).scope == gateScope, "a duplicate keeps the scope");

        // Values outside the scope in a file are ignored, not applied.
        auto crafted = part.toXml();
        if (auto* first = crafted->getChildByName ("SCENE"))
            if (auto* params = first->getChildByName ("PARAMS"))
                params->setAttribute ("in1_gain", -33.0);
        hydra::SceneBank strict (engine);
        strict.fromXml (*crafted, false);
        check (strict.get (0).values.count ("in1.gain") == 0, "a value outside the scope is ignored when reading");
    }

    // The Correction profile is not a parameter: it travels in a scene only when the scope names Correction.
    {
        namespace S = hydra::sections;
        hydra::CorrectionProfile room;
        room.name = "Room";
        room.kind = hydra::CorrectionProfile::Kind::room;
        room.preampDb = -2.0f;
        room.bands.push_back ({ 0, 100.0f, -3.0f, 1.0f });
        room.bands.push_back ({ 0, 2000.0f, 2.5f, 2.0f });
        hydra::CorrectionProfile other;
        other.name = "Other";
        other.bands.push_back ({ 0, 500.0f, 1.0f, 1.0f });
        engine.setCorrection (0, room);
        engine.params.get ("in1.corr.on").set (1.0f);

        hydra::SceneBank cs (engine);
        S::Scope corrScope;
        corrScope.sections = { "corr" };
        const int c = cs.addFromMixer ("Correction", corrScope);
        check (cs.get (c).states.count ("in1/corr") == 1 && cs.get (c).values.count ("in1.corr.on") == 1, "a Correction scene stores the profile and the switch");
        check (cs.get (c).states.size() == 1, "only the channels that have a profile");

        engine.setCorrection (0, other);
        engine.params.get ("in1.corr.on").set (0.0f);
        check (cs.countDifferences (c) == 2, "another profile and the switch off are two differences");
        cs.recall (c);
        check (engine.correctionFor (0).getProfile().name == "Room" && engine.correctionFor (0).getProfile().bands.size() == 2, "recall brings the profile back");
        check (engine.params.get ("in1.corr.on").isOn() && ! cs.differsFromMixer (c), "and the switch; then nothing differs");

        engine.setCorrection (1, other);   // input 2 had no profile when the scene was stored, and a Correction scene covers every channel
        cs.recall (c);
        check (engine.correctionFor (1).getProfile().isEmpty(), "a channel without a profile in the scene is cleared by the recall");

        // a scene that covers everything keeps profiles as they are
        engine.setCorrection (0, other);
        const int all = cs.addFromMixer ("Everything");
        check (cs.get (all).states.empty(), "a scene that covers everything does not carry profiles");
        engine.setCorrection (0, room);
        cs.recall (all);
        check (engine.correctionFor (0).getProfile().name == "Room", "and recalling it leaves the profile alone");

        // one channel only
        S::Scope oneIn = corrScope;
        oneIn.channels = { "in1" };
        engine.setCorrection (0, room);
        engine.setCorrection (1, other);
        const int one = cs.addFromMixer ("Input 1 Correction", oneIn);
        check (cs.get (one).states.size() == 1 && cs.get (one).states.count ("in1/corr") == 1, "a channel scene stores that channel's profile only");
        engine.setCorrection (0, other);
        engine.setCorrection (1, room);
        cs.recall (one);
        check (engine.correctionFor (0).getProfile().name == "Room" && engine.correctionFor (1).getProfile().name == "Room", "and recalling it leaves the other channel alone");

        // widening takes the current profile, narrowing drops it
        const int w = cs.addFromMixer ("Gate only", [] { S::Scope g; g.sections = { "gate" }; return g; }());
        check (cs.get (w).states.empty(), "a gate scene has no profile");
        engine.setCorrection (0, room);
        S::Scope both;
        both.sections = { "gate", "corr" };
        cs.setScope (w, both);
        check (cs.get (w).states.count ("in1/corr") == 1, "widening to Correction stores the current profile");
        cs.setScope (w, [] { S::Scope g; g.sections = { "gate" }; return g; }());
        check (cs.get (w).states.empty(), "narrowing drops it");

        // persistence: the profile is saved as text; the same profile comes back (the layout of the text may change)
        engine.setCorrection (0, room);
        cs.store (c);
        auto xml = cs.toXml();
        hydra::SceneBank again (engine);
        again.fromXml (*xml, false);
        check (again.get (c).states.count ("in1/corr") == 1
               && hydra::sectionstate::same ("corr", again.get (c).states.at ("in1/corr"), cs.get (c).states.at ("in1/corr")), "the profile survives save / load");
        check (again.get (all).states.empty() && again.get (one).states.size() == 1, "so do the other scenes");

        // a state in a file that the scope does not cover is ignored
        auto crafted = cs.toXml();
        if (auto* first = crafted->getChildByName ("SCENE"))
            if (auto* extra = first->createNewChildElement ("STATE"))
            {
                extra->setAttribute ("key", "in5/corr");
                extra->addTextElement ("<CORRECTION/>");
            }
        hydra::SceneBank strict (engine);
        strict.fromXml (*crafted, false);
        check (strict.get (c).states.count ("in5/corr") == 0, "a profile for a channel the scope does not cover is ignored when reading");

        // clean up the engine for what follows
        for (int i = 0; i < 2; ++i) engine.setCorrection (i, {});
        engine.params.get ("in1.corr.on").set (0.0f);
    }

    // Every parameter of a channel belongs to a section except the three that are not settings of the sound.
    {
        std::set<std::string> unassigned;
        for (auto& p : engine.params.all())
        {
            const auto r = hydra::sections::parse (p->id.toStdString());
            if (r.kind != hydra::sections::Kind::global && r.section.empty()) unassigned.insert (r.name);
        }
        check (unassigned == std::set<std::string> { "active", "fx.bypass", "sel" }, "sections cover every channel parameter of the engine");
        const auto fxId = hydra::sections::parse ("fx.rev.size");
        check (engine.params.find ("fx.rev.size") != nullptr && fxId.section == "fx" && engine.params.find ("mon.on") != nullptr, "the global ids the sections name exist");
    }
    return fails;
}
