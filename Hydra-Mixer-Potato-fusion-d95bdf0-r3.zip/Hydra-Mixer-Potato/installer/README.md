# Windows installer

Two ways to get `HydraMixerPotato-<version>-Setup.exe` and the portable `HydraMixerPotato-<version>-win64.zip`.

## On GitHub (nothing to install on your PC)

1. Use a fork or a clone of the Hydra Mixer repository: the JUCE submodule has to be part of it.
2. Get the workflow into it (`.github/workflows/build-windows.yml`): with Git, or in the browser with
   **Add file → Create new file**, the name `.github/workflows/build-windows.yml` and the text of the file pasted in.
3. Without Git: upload the zip with the **complete sources** (`Hydra-Mixer-....zip`) to the root of the repository
   (**Add file → Upload files**). The workflow *replaces* the sources with it before it builds: files of the zip are
   copied over the repository and files that the zip does not have are removed (`.git`, `.github` and the JUCE
   folder are never touched). If the zip would remove files, the step stops and changes nothing: the zip is then older
   than the repository (for example a fork with newer upstream files). Update the zip from the current sources, or
   tick *Replace even if files are removed* in **Run workflow** if the removal is meant. Keep only one such zip.
4. Open **Actions → Windows build and installer → Run workflow**. It takes about 15 to 40 minutes.
5. Open the finished run, **Artifacts → HydraMixerPotato-Windows**: the installer, the zip and the test log.
   (Pushing a tag such as `v0.6.1` also attaches the files to a GitHub release.)

The workflow is `.github/workflows/build-windows.yml`. If the build step fails, the log shows the compiler errors.

The repository may also have the upstream workflow `build.yml` (it builds what is committed, on every push). It is not
used for the uploaded zip; the copy in this tree only differs by the new name of the program.

## On your PC

Install Visual Studio Build Tools (C++ workload), CMake, Ninja (see the main README) and
[Inno Setup](https://jrsoftware.org/isdl.php) 6.3 or newer (`winget install JRSoftware.InnoSetup`), then:

```powershell
.\installer\build-installer.ps1
```

The files are written to `installer\Output`. To pack an existing build by hand:
`ISCC.exe /DAppVersion=0.6.0 installer\HydraMixer.iss` (optional: `/DBuildDir=<folder of "Hydra Mixer Potato.exe">`, `/DIconFile=<icon.ico>`).

## What the installer does

- Installs to Program Files (or only for you if you decline administrator rights), adds a Start menu entry and an
  optional desktop icon. Installing a new version over an old one works: it closes the running app first. The program
  used to be called `Hydra Mixer.exe`; an upgrade removes that file, and the "Start with Windows" entry is pointed at the
  new one the first time the app starts.
- Warns if Windows reports no AVX2 support, because Hydra Mixer Potato is built with AVX2 and would not start.
- The uninstaller removes the "Start with Windows" scheduled task of the app and asks whether to delete your settings,
  sessions and backups in `%APPDATA%\HydraMixer` (they are kept by default).
- It is not code-signed. Windows SmartScreen may show "Windows protected your PC": **More info → Run anyway**.
