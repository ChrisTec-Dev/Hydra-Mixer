# Builds Hydra Mixer Potato (Release) and packs it: a portable zip and the Windows installer.
#
# Needs what the README lists for building (Visual Studio Build Tools with the C++ workload, CMake, Ninja, the
# JUCE submodule) plus Inno Setup 6.3 or newer: https://jrsoftware.org/isdl.php   (or: winget install JRSoftware.InnoSetup)
#
#   .\installer\build-installer.ps1
#
# Result in installer\Output:  HydraMixerPotato-<version>-Setup.exe  and  HydraMixerPotato-<version>-win64.zip
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

# 1. Build (build.ps1 sets up the Visual Studio tools itself)
& "$root\build.ps1" -Config Release
if ($LASTEXITCODE -ne 0) { throw "The build failed (see the messages above)." }

$exe = Join-Path $root "build\Release\HydraMixer_artefacts\Release\Hydra Mixer Potato.exe"
if (-not (Test-Path $exe)) { throw "Hydra Mixer Potato.exe was not built: $exe" }

# Version of the project
$version = "0.6.0"
if ((Get-Content "$root\CMakeLists.txt" -Raw) -match 'project\(HydraMixer VERSION ([0-9][0-9.]*)') { $version = $Matches[1] }

$out = Join-Path $root "installer\Output"
New-Item -ItemType Directory -Force $out | Out-Null

# 2. Portable zip (no installer needed, same content as the releases)
$zip = Join-Path $out "HydraMixerPotato-$version-win64.zip"
if (Test-Path $zip) { Remove-Item $zip }
Compress-Archive -Path $exe, (Join-Path $root "LICENSE"), (Join-Path $root "README.md") -DestinationPath $zip
Write-Host "Portable zip: $zip"

# 3. Installer (Inno Setup)
$iscc = $null
$found = Get-Command iscc.exe -ErrorAction SilentlyContinue
if ($found) { $iscc = $found.Source }
if (-not $iscc)
{
    $candidates = @("${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe", "$env:ProgramFiles\Inno Setup 6\ISCC.exe",
                    "$env:LOCALAPPDATA\Programs\Inno Setup 6\ISCC.exe")
    foreach ($c in $candidates) { if (Test-Path $c) { $iscc = $c; break } }
}
if (-not $iscc) { throw "Inno Setup 6 was not found. Install it (winget install JRSoftware.InnoSetup) and run this script again. The portable zip is ready: $zip" }

$isccArgs = @("/DAppVersion=$version", "/DBuildDir=$(Split-Path -Parent $exe)")
$ico = Join-Path $root "build\Release\HydraMixer_artefacts\JuceLibraryCode\icon.ico"
if (Test-Path $ico) { $isccArgs += "/DIconFile=$ico" }
& $iscc @isccArgs (Join-Path $root "installer\HydraMixer.iss")
if ($LASTEXITCODE -ne 0) { throw "Inno Setup failed (see the messages above)." }
Write-Host "Installer: $out\HydraMixerPotato-$version-Setup.exe"
