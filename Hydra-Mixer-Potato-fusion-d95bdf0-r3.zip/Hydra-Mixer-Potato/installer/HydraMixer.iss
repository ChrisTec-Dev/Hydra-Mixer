; Hydra Mixer Potato installer, for Inno Setup 6.3 or newer (https://jrsoftware.org/isdl.php).
; Build it with installer\build-installer.ps1, or by hand after build.ps1:
;   ISCC.exe /DAppVersion=0.6.0 installer\HydraMixer.iss
; Optional defines: /DBuildDir=<folder with "Hydra Mixer Potato.exe">  /DIconFile=<icon.ico>
; Output: installer\Output\HydraMixerPotato-<version>-Setup.exe

#ifndef AppVersion
  #define AppVersion "0.6.0"
#endif
#ifndef BuildDir
  #define BuildDir "..\build\Release\HydraMixer_artefacts\Release"
#endif
#define AppName "Hydra Mixer Potato"
#define AppExe "Hydra Mixer Potato.exe"

[Setup]
AppId={{81181D59-0503-4A4B-B431-B0C9BCFB4A3F}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=Hydra
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
UninstallDisplayIcon={app}\{#AppExe}
OutputDir=Output
OutputBaseFilename=HydraMixerPotato-{#AppVersion}-Setup
Compression=lzma2/max
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
PrivilegesRequired=admin
PrivilegesRequiredOverridesAllowed=dialog
LicenseFile=..\LICENSE
CloseApplications=yes
RestartApplications=no
#ifdef IconFile
SetupIconFile={#IconFile}
#endif

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
Source: "{#BuildDir}\{#AppExe}"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\LICENSE"; DestDir: "{app}"; DestName: "LICENSE.txt"; Flags: ignoreversion
Source: "..\README.md"; DestDir: "{app}"; DestName: "README.md"; Flags: ignoreversion

[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\{#AppExe}"
Name: "{group}\Uninstall {#AppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExe}"; Tasks: desktopicon

[InstallDelete]
; Before the rename the program was called "Hydra Mixer.exe": an upgrade in the same folder must not leave the old one.
; (The "Start with Windows" task keeps the name "Hydra Mixer"; the app points it at the new file by itself.)
Type: files; Name: "{app}\Hydra Mixer.exe"

[Run]
Filename: "{app}\{#AppExe}"; Description: "{cm:LaunchProgram,{#AppName}}"; Flags: nowait postinstall skipifsilent

[UninstallRun]
; The app can register itself to start with Windows (scheduled task "Hydra Mixer"): remove it, it would point to nothing.
Filename: "{sys}\schtasks.exe"; Parameters: "/Delete /F /TN ""Hydra Mixer"""; Flags: runhidden; RunOnceId: "RemoveHydraMixerTask"

[Code]
function IsProcessorFeaturePresent(Feature: Cardinal): Boolean;
  external 'IsProcessorFeaturePresent@kernel32.dll stdcall';

function InitializeSetup(): Boolean;
begin
  Result := True;
  // Hydra Mixer Potato is built with AVX2 instructions (see the README) and does not start on a CPU without them.
  // 40 = PF_AVX2_INSTRUCTIONS_AVAILABLE
  if not IsProcessorFeaturePresent(40) then
    Result := MsgBox('Windows reports that the processor of this PC has no AVX2 support, which Hydra Mixer Potato needs. ' +
                     'It will probably not start. Install it anyway?',
                     mbConfirmation, MB_YESNO or MB_DEFBUTTON2) = IDYES;
end;

procedure CurUninstallStepChanged(CurUninstallStep: TUninstallStep);
var
  DataDir: String;
begin
  if CurUninstallStep = usPostUninstall then
  begin
    // Fallback entry of "Start with Windows" (the app uses a scheduled task, or this key if that fails).
    RegDeleteValue(HKEY_CURRENT_USER, 'Software\Microsoft\Windows\CurrentVersion\Run', 'Hydra Mixer');
    DataDir := ExpandConstant('{userappdata}\HydraMixer');
    if DirExists(DataDir) then
      if MsgBox('Also delete your Hydra Mixer Potato settings, sessions and backups?' + #13#10 + DataDir,
                mbConfirmation, MB_YESNO or MB_DEFBUTTON2) = IDYES then
        DelTree(DataDir, True, True, True);
  end;
end;
