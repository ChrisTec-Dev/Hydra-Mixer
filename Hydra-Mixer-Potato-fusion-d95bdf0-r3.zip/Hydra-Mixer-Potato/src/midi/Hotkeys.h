#pragma once
#include "core/HotkeySteps.h"
#include "core/Params.h"

namespace hydra
{
/** Keyboard shortcuts for switch-like parameters (mute, solo, routing, on/off, choices).

    Shortcuts with Ctrl or Alt, and F-keys, are registered system-wide (RegisterHotKey), so they
    work while a game or another app has focus. Plain keys only act while Hydra has focus,
    so they never steal typing from other programs. If Windows refuses a global registration
    (another app owns the combination), the shortcut still works while Hydra is focused.

    Mouse buttons (middle, thumb buttons 4/5, optionally with Ctrl/Alt/Shift) are always global.
    Windows has no hotkey registration for them, so a low-level mouse hook watches them; it is
    only installed while a mouse binding exists or a new shortcut is being captured. The click
    itself is passed on to the other app.

    Levels (faders, knobs) can have two shortcuts, one that increases and one that decreases them by a step. The
    media keys of a keyboard (Volume Up / Down / Mute, e.g. the roller of a Logitech G610) are global as well: a
    low-level keyboard hook watches them, only while one is bound or a new shortcut is being captured, and swallows
    the ones that are bound so Windows does not also change its own volume. */
class Hotkeys
{
public:
    /** What a shortcut does: switch the parameter (toggles, choices), or move a level up / down by a step. */
    enum class Action { toggle, increase, decrease };

    struct Binding
    {
        juce::String paramId;
        Param* param = nullptr;
        juce::KeyPress key;
        Action action = Action::toggle;
        float amount = 0.0f;      // step of increase / decrease: dB for a level in dB, else a fraction of the range; 0 = default
        bool global = false;      // registered with Windows (or watched by a hook)
    };

    explicit Hotkeys (ParamRegistry& registry);
    ~Hotkeys();

    /** Assigns key to p (replacing p's previous key for that action and any other parameter using the same key).
        amount = 0 keeps the step p already has (or the default). */
    void assign (Param& p, const juce::KeyPress& key, Action action = Action::toggle, float amount = 0.0f);
    void remove (const Param* p);   // all the shortcuts of p
    void clearAll();
    /** Channels were reordered: shortcuts of the parameters in moves (first) now trigger the parameter
        that holds their value (second). */
    void remapParams (const std::vector<std::pair<Param*, Param*>>& moves);
    int countBindings (const std::vector<std::pair<Param*, Param*>>& moves) const;
    juce::KeyPress getKeyFor (const Param* p, Action action = Action::toggle) const;
    /** Step of one key press of p's increase / decrease shortcuts: the chosen one, or the default. */
    float stepOf (const Param& p) const;
    void setStep (const Param& p, float amount);
    std::vector<Binding> getBindings() const { return bindings; }

    /** Key press while a Hydra window has focus. Returns true if it triggered something. */
    bool handleLocalKey (const juce::KeyPress& key);

    /** While suspended (assigning a new key) no global shortcuts are registered. */
    void setSuspended (bool shouldBeSuspended);

    static bool canAssign (const Param& p) noexcept { return p.type == ParamType::Toggle || ! p.choices.isEmpty(); }
    /** Levels: continuous parameters (not choices) can have increase / decrease shortcuts. */
    static bool canAssignStep (const Param& p) noexcept { return p.type == ParamType::Continuous && p.choices.isEmpty(); }
    static bool wantsGlobal (const juce::KeyPress& key) noexcept;
    static void trigger (Param& p) noexcept;
    static juce::String describe (const juce::KeyPress& key);

    /** Moves a level by one key press (direction > 0 = up). amount <= 0 = the default step. */
    static void step (Param& p, int direction, float amount) noexcept;
    static bool isDecibels (const Param& p) noexcept { return p.unit == " dB"; }
    static float defaultStep (const Param& p) noexcept { return (float) hotkeysteps::defaultAmount (isDecibels (p)); }
    /** The steps the menu offers for p, and how one is written ("1.0 dB", "2 %"). */
    static std::vector<float> stepChoices (const Param& p);
    static juce::String stepText (const Param& p, float amount);

    /** JUCE's own flag on the key code of a key without a character (F-keys, arrows, numpad, and the Windows virtual keys it
        passes through). JUCE does not export it, so it is repeated here. */
    static constexpr int kExtendedKey = 0x10000;

    /** Media keys (volume, tracks, browser, launch): Windows virtual keys with that flag. */
    static bool isMediaKey (const juce::KeyPress& key) noexcept
    {
        const int code = key.getKeyCode();
        return (code & kExtendedKey) != 0 && hotkeysteps::isMediaVk ((unsigned) (code & 0xffff));
    }
    /** Asked by the keyboard hook for every media key: true to swallow it (a shortcut uses it, or one is being captured). */
    bool wantsMediaKey (unsigned virtualKey, int modifierFlags) const;

    /** Mouse buttons as KeyPress codes (outside JUCE's key code range): 3 = middle, 4/5 = thumb buttons. */
    static constexpr int kMouseCodeBase = 0x7ff00000;
    static bool isMouseButton (const juce::KeyPress& key) noexcept { return (key.getKeyCode() & 0x7fffff00) == kMouseCodeBase; }

    /** While set (capturing a new shortcut), mouse buttons 3-5 and media keys are passed here instead of triggering. */
    void setMouseCapture (std::function<void (const juce::KeyPress&)> callback);

    std::unique_ptr<juce::XmlElement> toXml() const;
    void fromXml (const juce::XmlElement& xml);

    /** Bumped on every change (UI refresh, autosave). */
    std::atomic<uint32_t> version { 0 };

private:
    void registerAll();
    void unregisterAll();
    void onGlobalHotkey (int id);
    void onMouseButton (const juce::KeyPress& key);
    void onMediaKey (const juce::KeyPress& key);
    void updateMouseHook();
    void updateKeyboardHook();
    static void trigger (const Binding& b) noexcept;

    struct Window;
    ParamRegistry& params;
    std::vector<Binding> bindings;
    std::unique_ptr<Window> window;
    bool suspended = false;
    std::function<void (const juce::KeyPress&)> mouseCapture;
    void* mouseHook = nullptr; // HHOOK
    void* keyboardHook = nullptr; // HHOOK
};
} // namespace hydra
