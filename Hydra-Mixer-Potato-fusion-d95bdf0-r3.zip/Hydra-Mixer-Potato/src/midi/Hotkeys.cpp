#include "Hotkeys.h"
#include <windows.h>

namespace hydra
{
namespace
{
constexpr int kFirstId = 0x4800;
constexpr UINT kMouseMsg = WM_APP + 0x48;   // posted by the mouse hook: wParam = button (3..5), lParam = JUCE modifier flags
HWND hookTarget = nullptr;                  // window that receives kMouseMsg (one Hotkeys instance per app)
constexpr UINT kKeyMsg = WM_APP + 0x49;     // posted by the keyboard hook: wParam = virtual key, lParam = JUCE modifier flags
HWND keyTarget = nullptr;                   // window that receives kKeyMsg
Hotkeys* keyboardOwner = nullptr;           // the hook asks it which media keys to swallow

int currentModifiers()
{
    int mods = 0;
    if (GetAsyncKeyState (VK_CONTROL) & 0x8000) mods |= juce::ModifierKeys::ctrlModifier;
    if (GetAsyncKeyState (VK_MENU) & 0x8000)    mods |= juce::ModifierKeys::altModifier;
    if (GetAsyncKeyState (VK_SHIFT) & 0x8000)   mods |= juce::ModifierKeys::shiftModifier;
    return mods;
}

LRESULT CALLBACK mouseHookProc (int code, WPARAM wp, LPARAM lp)
{
    if (code == HC_ACTION && hookTarget != nullptr && (wp == WM_MBUTTONDOWN || wp == WM_XBUTTONDOWN))
    {
        int button = 3;
        if (wp == WM_XBUTTONDOWN)
            button = HIWORD (((const MSLLHOOKSTRUCT*) lp)->mouseData) == XBUTTON2 ? 5 : 4;
        // Keep the hook fast (Windows drops slow hooks): handle it later on the message thread.
        PostMessageW (hookTarget, kMouseMsg, (WPARAM) button, (LPARAM) currentModifiers());
    }
    return CallNextHookEx (nullptr, code, wp, lp);
}

/** Watches the media keys (volume roller, ...). A key a shortcut uses is swallowed, so Windows does not also act on it. */
LRESULT CALLBACK keyboardHookProc (int code, WPARAM wp, LPARAM lp)
{
    if (code == HC_ACTION && keyTarget != nullptr && keyboardOwner != nullptr)
    {
        const auto* k = (const KBDLLHOOKSTRUCT*) lp;
        if (hotkeysteps::isMediaVk ((unsigned) k->vkCode))
        {
            const int mods = currentModifiers();
            if (keyboardOwner->wantsMediaKey ((unsigned) k->vkCode, mods))
            {
                if (wp == WM_KEYDOWN || wp == WM_SYSKEYDOWN)   // auto-repeat sends more of them: holding the key keeps stepping
                    PostMessageW (keyTarget, kKeyMsg, (WPARAM) k->vkCode, (LPARAM) mods);
                return 1;
            }
        }
    }
    return CallNextHookEx (nullptr, code, wp, lp);
}

/** JUCE key code -> Windows virtual key (0 = not representable). */
UINT toVirtualKey (const juce::KeyPress& k)
{
    const int code = k.getKeyCode();
    if ((code & Hotkeys::kExtendedKey) != 0) return (UINT) (code & 0xffff);  // JUCE's extended flag (F-keys, arrows, numpad...)
    if ((code >= 'A' && code <= 'Z') || (code >= '0' && code <= '9')) return (UINT) code;
    if (code >= 'a' && code <= 'z') return (UINT) (code - 'a' + 'A');
    const SHORT vk = VkKeyScanW ((WCHAR) code);
    return vk == -1 ? 0u : (UINT) LOBYTE (vk);
}

UINT toWinModifiers (const juce::KeyPress& k)
{
    const auto m = k.getModifiers();
    UINT r = MOD_NOREPEAT;
    if (m.isCtrlDown())  r |= MOD_CONTROL;
    if (m.isAltDown())   r |= MOD_ALT;
    if (m.isShiftDown()) r |= MOD_SHIFT;
    return r;
}

bool isFunctionKey (const juce::KeyPress& k)
{
    const int code = k.getKeyCode();
    return code >= juce::KeyPress::F1Key && code <= juce::KeyPress::F24Key;
}
} // namespace

//==============================================================================
/** Hidden message-only window that receives WM_HOTKEY on the message thread. */
struct Hotkeys::Window
{
    explicit Window (Hotkeys& o) : owner (o)
    {
        WNDCLASSEXW wc {};
        wc.cbSize = sizeof (wc);
        wc.lpfnWndProc = &Window::proc;
        wc.hInstance = GetModuleHandleW (nullptr);
        wc.lpszClassName = L"HydraMixerHotkeys";
        RegisterClassExW (&wc); // fails harmlessly if already registered
        hwnd = CreateWindowExW (0, wc.lpszClassName, L"", 0, 0, 0, 0, 0, HWND_MESSAGE, nullptr, wc.hInstance, nullptr);
        if (hwnd != nullptr)
            SetWindowLongPtrW (hwnd, GWLP_USERDATA, (LONG_PTR) this);
    }

    ~Window()
    {
        if (hwnd != nullptr) DestroyWindow (hwnd);
    }

    static LRESULT CALLBACK proc (HWND h, UINT msg, WPARAM wp, LPARAM lp)
    {
        if (msg == WM_HOTKEY)
            if (auto* self = (Window*) GetWindowLongPtrW (h, GWLP_USERDATA))
            {
                self->owner.onGlobalHotkey ((int) wp);
                return 0;
            }
        if (msg == kMouseMsg)
            if (auto* self = (Window*) GetWindowLongPtrW (h, GWLP_USERDATA))
            {
                self->owner.onMouseButton (juce::KeyPress (Hotkeys::kMouseCodeBase + (int) wp, juce::ModifierKeys ((int) lp), 0));
                return 0;
            }
        if (msg == kKeyMsg)
            if (auto* self = (Window*) GetWindowLongPtrW (h, GWLP_USERDATA))
            {
                self->owner.onMediaKey (juce::KeyPress (Hotkeys::kExtendedKey | (int) wp, juce::ModifierKeys ((int) lp), 0));
                return 0;
            }
        return DefWindowProcW (h, msg, wp, lp);
    }

    Hotkeys& owner;
    HWND hwnd = nullptr;
};

//==============================================================================
Hotkeys::Hotkeys (ParamRegistry& registry) : params (registry)
{
    if (juce::MessageManager::getInstanceWithoutCreating() != nullptr)
        window = std::make_unique<Window> (*this);
}

Hotkeys::~Hotkeys()
{
    unregisterAll();
    mouseCapture = nullptr;
    bindings.clear();
    updateMouseHook();
    updateKeyboardHook();
}

juce::String Hotkeys::describe (const juce::KeyPress& key)
{
    if (isMediaKey (key))
    {
        juce::String s;
        const auto m = key.getModifiers();
        if (m.isCtrlDown())  s << "Ctrl + ";
        if (m.isAltDown())   s << "Alt + ";
        if (m.isShiftDown()) s << "Shift + ";
        const char* name = hotkeysteps::mediaKeyName ((unsigned) (key.getKeyCode() & 0xffff));
        return s + juce::String (name != nullptr ? name : "Media key");
    }
    if (! isMouseButton (key)) return key.getTextDescriptionWithIcons();
    juce::String s;
    const auto m = key.getModifiers();
    if (m.isCtrlDown())  s << "Ctrl + ";
    if (m.isAltDown())   s << "Alt + ";
    if (m.isShiftDown()) s << "Shift + ";
    return s + "Mouse " + juce::String (key.getKeyCode() - kMouseCodeBase);
}

void Hotkeys::setMouseCapture (std::function<void (const juce::KeyPress&)> callback)
{
    mouseCapture = std::move (callback);
    updateMouseHook();
    updateKeyboardHook();
}

void Hotkeys::updateMouseHook()
{
    bool needed = mouseCapture != nullptr;
    for (auto& b : bindings) needed |= b.param != nullptr && isMouseButton (b.key);
    needed &= window != nullptr && window->hwnd != nullptr;

    if (needed && mouseHook == nullptr)
    {
        hookTarget = window->hwnd;
        mouseHook = SetWindowsHookExW (WH_MOUSE_LL, &mouseHookProc, GetModuleHandleW (nullptr), 0);
    }
    else if (! needed && mouseHook != nullptr)
    {
        UnhookWindowsHookEx ((HHOOK) mouseHook);
        mouseHook = nullptr;
        hookTarget = nullptr;
    }
}

void Hotkeys::onMouseButton (const juce::KeyPress& key)
{
    if (mouseCapture != nullptr)
    {
        auto cb = mouseCapture; // the callback may clear the capture
        cb (key);
        return;
    }
    if (suspended) return;
    for (auto& b : bindings)
        if (b.param != nullptr && b.key == key)
        {
            trigger (b);
            return;
        }
}

void Hotkeys::updateKeyboardHook()
{
    bool needed = mouseCapture != nullptr;
    for (auto& b : bindings) needed |= b.param != nullptr && isMediaKey (b.key);
    needed &= window != nullptr && window->hwnd != nullptr;

    if (needed && keyboardHook == nullptr)
    {
        keyTarget = window->hwnd;
        keyboardOwner = this;
        keyboardHook = SetWindowsHookExW (WH_KEYBOARD_LL, &keyboardHookProc, GetModuleHandleW (nullptr), 0);
        if (keyboardHook == nullptr)
        {
            keyTarget = nullptr;
            keyboardOwner = nullptr;
        }
    }
    else if (! needed && keyboardHook != nullptr)
    {
        UnhookWindowsHookEx ((HHOOK) keyboardHook);
        keyboardHook = nullptr;
        keyTarget = nullptr;
        keyboardOwner = nullptr;
    }
}

bool Hotkeys::wantsMediaKey (unsigned virtualKey, int modifierFlags) const
{
    if (mouseCapture != nullptr) return true;   // capturing a new shortcut: every media key is caught
    if (suspended) return false;
    const juce::KeyPress pressed (kExtendedKey | (int) virtualKey, juce::ModifierKeys (modifierFlags), 0);
    for (auto& b : bindings)
        if (b.param != nullptr && isMediaKey (b.key) && b.key == pressed)
            return true;
    return false;
}

void Hotkeys::onMediaKey (const juce::KeyPress& key)
{
    if (mouseCapture != nullptr)
    {
        auto cb = mouseCapture; // the callback may clear the capture
        cb (key);
        return;
    }
    if (suspended) return;
    for (auto& b : bindings)
        if (b.param != nullptr && b.key == key)
        {
            trigger (b);
            return;
        }
}

bool Hotkeys::wantsGlobal (const juce::KeyPress& key) noexcept
{
    if (isMouseButton (key) || isMediaKey (key)) return true;
    const auto m = key.getModifiers();
    return m.isCtrlDown() || m.isAltDown() || isFunctionKey (key);
}

void Hotkeys::trigger (Param& p) noexcept
{
    if (! p.choices.isEmpty())
        p.set ((float) ((juce::roundToInt (p.get()) + 1) % p.choices.size()));
    else
        p.toggle();
}

void Hotkeys::trigger (const Binding& b) noexcept
{
    if (b.param == nullptr) return;
    if (b.action == Action::toggle)
        trigger (*b.param);
    else
        step (*b.param, b.action == Action::increase ? 1 : -1, b.amount);
}

void Hotkeys::step (Param& p, int direction, float amount) noexcept
{
    if (! canAssignStep (p)) return;
    if (amount <= 0.0f) amount = defaultStep (p);
    if (isDecibels (p))
        p.set ((float) hotkeysteps::steppedNative (p.get(), p.range.start, p.range.end, direction, amount));
    else
        p.setNormalised ((float) hotkeysteps::steppedNormalised (p.getNormalised(), direction, amount));
}

std::vector<float> Hotkeys::stepChoices (const Param& p)
{
    std::vector<float> out;
    for (double a : hotkeysteps::amountChoices (isDecibels (p))) out.push_back ((float) a);
    return out;
}

juce::String Hotkeys::stepText (const Param& p, float amount)
{
    return isDecibels (p) ? juce::String (amount, 1) + " dB" : juce::String (juce::roundToInt (amount * 100.0f)) + " %";
}

void Hotkeys::assign (Param& p, const juce::KeyPress& key, Action action, float amount)
{
    unregisterAll();
    float kept = 0.0f;   // the step is shared by the increase and the decrease shortcut of a parameter
    for (auto& b : bindings)
        if (b.param == &p && b.action != Action::toggle) kept = b.amount;
    bindings.erase (std::remove_if (bindings.begin(), bindings.end(),
                                    [&] (const Binding& b) { return (b.param == &p && b.action == action) || b.key == key; }),
                    bindings.end());
    Binding b;
    b.paramId = p.id;
    b.param = &p;
    b.key = key;
    b.action = action;
    b.amount = action == Action::toggle ? 0.0f : (amount > 0.0f ? amount : kept);
    bindings.push_back (b);
    if (action != Action::toggle && amount > 0.0f)
        for (auto& o : bindings)
            if (o.param == &p && o.action != Action::toggle) o.amount = amount;
    registerAll();
    updateMouseHook();
    updateKeyboardHook();
    ++version;
}

float Hotkeys::stepOf (const Param& p) const
{
    for (auto& b : bindings)
        if (b.param == &p && b.action != Action::toggle && b.amount > 0.0f) return b.amount;
    return defaultStep (p);
}

void Hotkeys::setStep (const Param& p, float amount)
{
    for (auto& b : bindings)
        if (b.param == &p && b.action != Action::toggle) b.amount = amount;
    ++version;
}

void Hotkeys::remove (const Param* p)
{
    unregisterAll();
    bindings.erase (std::remove_if (bindings.begin(), bindings.end(), [p] (const Binding& b) { return b.param == p; }),
                    bindings.end());
    registerAll();
    updateMouseHook();
    updateKeyboardHook();
    ++version;
}

void Hotkeys::clearAll()
{
    unregisterAll();
    bindings.clear();
    updateMouseHook();
    updateKeyboardHook();
    ++version;
}

void Hotkeys::remapParams (const std::vector<std::pair<Param*, Param*>>& moves)
{
    unregisterAll();
    for (auto& b : bindings)
        for (auto& [from, to] : moves)
            if (b.param == from)
            {
                b.param = to;
                b.paramId = to->id;
                break;
            }
    registerAll();
    ++version;
}

int Hotkeys::countBindings (const std::vector<std::pair<Param*, Param*>>& moves) const
{
    int n = 0;
    for (auto& b : bindings)
        for (auto& m : moves)
            if (b.param == m.first) { ++n; break; }
    return n;
}

juce::KeyPress Hotkeys::getKeyFor (const Param* p, Action action) const
{
    for (auto& b : bindings)
        if (b.param == p && b.action == action) return b.key;
    return {};
}

bool Hotkeys::handleLocalKey (const juce::KeyPress& key)
{
    for (auto& b : bindings)
        if (b.param != nullptr && ! b.global && b.key == key)
        {
            trigger (b);
            return true;
        }
    return false;
}

void Hotkeys::setSuspended (bool s)
{
    if (s == suspended) return;
    suspended = s;
    if (s) unregisterAll();
    else   registerAll();
}

void Hotkeys::registerAll()
{
    if (suspended || window == nullptr || window->hwnd == nullptr) return;
    for (size_t i = 0; i < bindings.size(); ++i)
    {
        auto& b = bindings[i];
        if (isMouseButton (b.key) || isMediaKey (b.key)) { b.global = b.param != nullptr; continue; } // handled by the mouse / keyboard hook
        const UINT vk = toVirtualKey (b.key);
        UINT mods = toWinModifiers (b.key);
        if (b.action != Action::toggle) mods &= ~(UINT) MOD_NOREPEAT;   // holding the key keeps stepping
        b.global = b.param != nullptr && vk != 0 && wantsGlobal (b.key)
                   && RegisterHotKey (window->hwnd, kFirstId + (int) i, mods, vk);
    }
}

void Hotkeys::unregisterAll()
{
    for (size_t i = 0; i < bindings.size(); ++i)
        if (bindings[i].global && ! isMouseButton (bindings[i].key) && ! isMediaKey (bindings[i].key))
        {
            if (window != nullptr) UnregisterHotKey (window->hwnd, kFirstId + (int) i);
            bindings[i].global = false;
        }
}

void Hotkeys::onGlobalHotkey (int id)
{
    const int i = id - kFirstId;
    if (juce::isPositiveAndBelow (i, (int) bindings.size()) && bindings[(size_t) i].param != nullptr)
        trigger (bindings[(size_t) i]);
}

//==============================================================================
std::unique_ptr<juce::XmlElement> Hotkeys::toXml() const
{
    auto xml = std::make_unique<juce::XmlElement> ("HOTKEYS");
    for (auto& b : bindings)
    {
        auto* e = xml->createNewChildElement ("KEY");
        e->setAttribute ("param", b.paramId);
        if (isMediaKey (b.key))
        {
            e->setAttribute ("media", b.key.getKeyCode() & 0xffff);
            e->setAttribute ("mods", b.key.getModifiers().getRawFlags());
        }
        else
            e->setAttribute ("key", b.key.getTextDescription());
        if (b.action != Action::toggle) e->setAttribute ("action", b.action == Action::increase ? "up" : "down");
        if (b.amount > 0.0f) e->setAttribute ("amount", (double) b.amount);
    }
    return xml;
}

void Hotkeys::fromXml (const juce::XmlElement& xml)
{
    unregisterAll();
    bindings.clear();
    for (auto* e : xml.getChildWithTagNameIterator ("KEY"))
    {
        Binding b;
        b.paramId = e->getStringAttribute ("param");
        b.param = params.find (b.paramId);
        if (e->hasAttribute ("media"))
            b.key = juce::KeyPress (kExtendedKey | e->getIntAttribute ("media"), juce::ModifierKeys (e->getIntAttribute ("mods")), 0);
        else
            b.key = juce::KeyPress::createFromDescription (e->getStringAttribute ("key"));
        const auto action = e->getStringAttribute ("action");
        b.action = action == "up" ? Action::increase : action == "down" ? Action::decrease : Action::toggle;
        b.amount = (float) e->getDoubleAttribute ("amount", 0.0);
        if (b.param != nullptr && b.key.isValid() && (b.action == Action::toggle || canAssignStep (*b.param)))
            bindings.push_back (b);
    }
    registerAll();
    updateMouseHook();
    updateKeyboardHook();
    ++version;
}
} // namespace hydra
