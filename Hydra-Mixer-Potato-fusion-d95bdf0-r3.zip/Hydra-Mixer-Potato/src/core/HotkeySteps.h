// Pure helpers of the keyboard shortcuts that move a level up or down (and of the media / volume keys).
// Only the standard library is used: tests/HotkeyStepsTest.cpp also runs without JUCE.
#pragma once
#include <algorithm>
#include <cmath>
#include <vector>

namespace hydra::hotkeysteps
{
/** Windows virtual keys that no program gets as typing: browser (0xA6..0xAC), volume (0xAD..0xAF), media (0xB0..0xB3)
    and launch keys (0xB4..0xB7). A keyboard's volume roller (Logitech G610: Volume Up / Down, and Mute above it) sends them. */
inline bool isMediaVk (unsigned vk) noexcept { return vk >= 0xA6 && vk <= 0xB7; }

/** Name of such a key, nullptr for any other. */
inline const char* mediaKeyName (unsigned vk) noexcept
{
    switch (vk)
    {
        case 0xA6: return "Browser Back";
        case 0xA7: return "Browser Forward";
        case 0xA8: return "Browser Refresh";
        case 0xA9: return "Browser Stop";
        case 0xAA: return "Browser Search";
        case 0xAB: return "Browser Favorites";
        case 0xAC: return "Browser Home";
        case 0xAD: return "Volume Mute";
        case 0xAE: return "Volume Down";
        case 0xAF: return "Volume Up";
        case 0xB0: return "Next Track";
        case 0xB1: return "Previous Track";
        case 0xB2: return "Media Stop";
        case 0xB3: return "Play / Pause";
        case 0xB4: return "Launch Mail";
        case 0xB5: return "Launch Media";
        case 0xB6: return "Launch App 1";
        case 0xB7: return "Launch App 2";
        default:   return nullptr;
    }
}

/** What one key press moves: dB for a level in dB (stepped in its own units), otherwise a fraction of the range
    (stepped on the normalised 0..1 position, so a frequency knob moves by the same part of the knob at any frequency). */
inline double defaultAmount (bool inDecibels) noexcept { return inDecibels ? 1.0 : 0.02; }

/** The amounts offered in the menu. */
inline std::vector<double> amountChoices (bool inDecibels)
{
    return inDecibels ? std::vector<double> { 0.5, 1.0, 2.0, 3.0, 6.0 } : std::vector<double> { 0.01, 0.02, 0.05, 0.10 };
}

/** Value after one key press: current +/- amount, kept inside the range. direction < 0 = down, otherwise up. */
inline double steppedNative (double current, double rangeStart, double rangeEnd, int direction, double amount) noexcept
{
    const double lo = std::min (rangeStart, rangeEnd), hi = std::max (rangeStart, rangeEnd);
    return std::clamp (current + (direction < 0 ? -amount : amount), lo, hi);
}

/** Same on the normalised position (0..1). */
inline double steppedNormalised (double position, int direction, double fraction) noexcept
{
    return std::clamp (position + (direction < 0 ? -fraction : fraction), 0.0, 1.0);
}
} // namespace hydra::hotkeysteps
