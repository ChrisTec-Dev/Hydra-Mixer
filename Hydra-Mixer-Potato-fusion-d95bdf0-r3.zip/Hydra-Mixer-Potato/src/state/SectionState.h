#pragma once
#include "engine/Engine.h"
#include "core/Sections.h"

namespace hydra::sectionstate
{
/** Settings of a section that are not parameters, read and written as text for one channel, so that copy / paste of
    a section and scenes can carry them. Today: the Correction profile (its filter bands) of core/Correction.h.
    `selectIndex` is Engine's scheme: inputs 0..kMaxInputs-1, then the buses. Message thread. */

/** The settings of the section for the channel ("" = nothing: the default). */
std::string capture (Engine& e, const std::string& section, int selectIndex);

/** Puts them back ("" = back to the default). */
void apply (Engine& e, const std::string& section, int selectIndex, const std::string& text);

/** Whether two texts mean the same settings (a different layout of the same profile is not a difference). */
bool same (const std::string& section, const std::string& a, const std::string& b);
} // namespace hydra::sectionstate
