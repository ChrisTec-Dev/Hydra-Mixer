#include "SectionState.h"

namespace hydra::sectionstate
{
namespace
{
CorrectionProfile profileFromText (const std::string& text)
{
    if (text.empty()) return {};
    const auto xml = juce::parseXML (juce::String::fromUTF8 (text.c_str()));
    return CorrectionProfile::fromXml (xml.get());   // an empty profile if the text is not one
}
} // namespace

std::string capture (Engine& e, const std::string& section, int selectIndex)
{
    if (section == "corr" && juce::isPositiveAndBelow (selectIndex, kMaxInputs + kMaxBuses))
    {
        const auto& profile = e.correctionFor (selectIndex).getProfile();
        if (profile.isEmpty()) return {};
        if (const auto xml = profile.toXml())
            return xml->toString().toStdString();
    }
    return {};
}

void apply (Engine& e, const std::string& section, int selectIndex, const std::string& text)
{
    if (section == "corr" && juce::isPositiveAndBelow (selectIndex, kMaxInputs + kMaxBuses))
        e.setCorrection (selectIndex, profileFromText (text));
}

bool same (const std::string& section, const std::string& a, const std::string& b)
{
    if (a == b) return true;
    if (section == "corr")
    {
        const auto pa = profileFromText (a), pb = profileFromText (b);
        if (pa.isEmpty() && pb.isEmpty()) return true;
        return pa.name == pb.name && pa.kind == pb.kind && pa.preampDb == pb.preampDb && pa.bands == pb.bands;
    }
    return false;
}
} // namespace hydra::sectionstate
